# Subscription-Based Journals: Zero Author Fees Analysis
## Natural Products + Cancer Biology / Breast Cancer Review

### Key Finding
Most traditional subscription-based (non-OA) journals in pharmacognosy and natural products do **NOT** charge author fees for publication. The APC model is primarily associated with Open Access journals.

---

## JOURNALS WITH ZERO AUTHOR FEES ✅

### 1. Fitoterapia
- **Publisher:** Elsevier
- **ISSN:** 0367-326X
- **IF:** ~2.3 (2023)
- **SCIE:** Yes
- **Q1/Q2:** Q2 (Pharmacology & Pharmacy)
- **Fees:** ✅ **ZERO** — Subscription journal, no APC, no page charges, no color figure fees
- **Reviews:** Yes, accepts review articles
- **Scope:** Natural products, medicinal plants, pharmacognosy
- **Note:** Authors retain copyright; gold OA option available (~$3,150 APC) but NOT required

### 2. Planta Medica
- **Publisher:** Thieme Medical Publishers
- **ISSN:** 0032-0943 (print), 1439-0221 (online)
- **IF:** ~2.5 (2023)
- **SCIE:** Yes
- **Q1/Q2:** Q1 (Integrative & Complementary Medicine), Q2 (Plant Sciences)
- **Fees:** ✅ **ZERO** — Subscription journal, no APC, no page charges
- **Reviews:** Yes, accepts review articles
- **Scope:** Medicinal plants, natural products chemistry, pharmacognosy
- **Note:** Official journal of Society for Medicinal Plant and Natural Product Research (GA)

### 3. Journal of Ethnopharmacology
- **Publisher:** Elsevier
- **ISSN:** 0378-8741
- **IF:** ~5.4 (2023)
- **SCIE:** Yes
- **Q1/Q2:** Q1 (Integrative & Complementary Medicine)
- **Fees:** ✅ **ZERO** — Subscription journal, no APC, no page charges, no color fees
- **Reviews:** Yes, accepts review articles
- **Scope:** Ethnopharmacology, traditional medicine, natural products
- **Note:** Official journal of International Society for Ethnopharmacology

### 4. Natural Product Research
- **Publisher:** Taylor & Francis
- **ISSN:** 1478-6419 (print), 1478-6427 (online)
- **IF:** ~2.2 (2023)
- **SCIE:** Yes
- **Q1/Q2:** Q2 (Plant Sciences), Q2 (Chemistry, Applied)
- **Fees:** ✅ **ZERO** — Subscription journal, no APC, no page charges, no color fees
- **Reviews:** Yes, accepts review articles
- **Scope:** Natural product chemistry, isolation, structural characterization
- **Note:** Hybrid OA option available (~$3,450 APC) but NOT required

### 5. Phytotherapy Research
- **Publisher:** Wiley
- **ISSN:** 0951-418X
- **IF:** ~6.1 (2023)
- **SCIE:** Yes
- **Q1/Q2:** Q1 (Pharmacology & Pharmacy)
- **Fees:** ✅ **ZERO** — Subscription journal, no APC, no page charges, no color fees
- **Reviews:** Yes, accepts review articles
- **Scope:** Pharmacology of natural products, herbal medicine
- **Note:** One of the top journals for natural product pharmacology

### 6. South African Journal of Botany
- **Publisher:** Elsevier (for South African Association of Botanists)
- **ISSN:** 0254-6299
- **IF:** ~3.0 (2023)
- **SCIE:** Yes
- **Q1/Q2:** Q1 (Plant Sciences)
- **Fees:** ✅ **ZERO** — Subscription journal, no APC, no page charges, no color fees
- **Reviews:** Yes, accepts review articles
- **Scope:** Plant biology, botany, natural products
- **Note:** Published by Elsevier on behalf of South African Association of Botanists

### 7. Bioorganic & Medicinal Chemistry Letters
- **Publisher:** Elsevier
- **ISSN:** 0960-894X
- **IF:** ~2.5 (2023)
- **SCIE:** Yes
- **Q1/Q2:** Q2 (Chemistry, Organic), Q2 (Pharmacology & Pharmacy)
- **Fees:** ✅ **ZERO** — Subscription journal, no APC, no page charges, no color fees
- **Reviews:** Yes, accepts mini-reviews and perspectives
- **Scope:** Medicinal chemistry, drug discovery, SAR studies
- **Note:** Fast publication, good for preliminary SAR results

### 8. Chemico-Biological Interactions
- **Publisher:** Elsevier
- **ISSN:** 0009-2797
- **IF:** ~5.1 (2023)
- **SCIE:** Yes
- **Q1/Q2:** Q1 (Toxicology), Q2 (Biochemistry & Molecular Biology)
- **Fees:** ✅ **ZERO** — Subscription journal, no APC, no page charges, no color fees
- **Reviews:** Yes, accepts review articles
- **Scope:** Chemical-biological interactions, molecular mechanisms, toxicology
- **Note:** Good for mechanistic studies of natural products

### 9. Journal of Natural Products
- **Publisher:** American Chemical Society (ACS) / American Society of Pharmacognosy
- **ISSN:** 0163-3864
- **IF:** ~5.1 (2023)
- **SCIE:** Yes
- **Q1/Q2:** Q1 (Plant Sciences), Q2 (Chemistry, Applied)
- **Fees:** ✅ **ZERO** — Subscription journal, no APC, no page charges, no color fees
- **Reviews:** Yes, accepts review articles
- **Scope:** Chemistry and biology of natural products
- **Note:** Premier journal for natural product chemistry

### 10. Journal of Natural Medicines
- **Publisher:** Springer (Japanese Society of Pharmacognosy)
- **ISSN:** 1340-3443
- **IF:** ~2.9 (2023)
- **SCIE:** Yes
- **Q1/Q2:** Q2 (Plant Sciences)
- **Fees:** ✅ **ZERO** — Subscription journal, no APC, no page charges, no color fees
- **Reviews:** Yes, accepts review articles
- **Scope:** Natural product chemistry, pharmacognosy, traditional medicine
- **Note:** Published by Springer for Japanese Society of Pharmacognosy

---

## JOURNALS WITH MANDATORY APC (NOT FREE) ❌

### 11. Phytomedicine
- **Publisher:** Elsevier
- **ISSN:** 0944-7113
- **IF:** ~7.0 (2023)
- **SCIE:** Yes
- **Q1/Q2:** Q1 (Pharmacology & Pharmacy), Q1 (Integrative & Complementary Medicine)
- **Fees:** ❌ **Mandatory OA — ~$3,750 APC** (fully OA since 2018)
- **Reviews:** Yes, accepts reviews
- **Scope:** Clinical pharmacology of natural products
- **Note:** Transitioned to fully Open Access — author fees ARE required

### 12. European Journal of Medicinal Chemistry
- **Publisher:** Elsevier
- **ISSN:** 0223-5234
- **IF:** ~6.0 (2023)
- **SCIE:** Yes
- **Q1/Q2:** Q1 (Chemistry, Medicinal)
- **Fees:** ❌ **Mandatory OA — ~$3,750 APC** (transitioned to fully OA)
- **Reviews:** Yes, accepts reviews
- **Scope:** Medicinal chemistry, drug design
- **Note:** Transitioned to fully Open Access — author fees ARE required

### 13. Molecules (MDPI)
- **Publisher:** MDPI
- **ISSN:** 1420-3049
- **IF:** ~4.2 (2023)
- **SCIE:** Yes
- **Q1/Q2:** Q2 (Chemistry, Multidisciplinary)
- **Fees:** ❌ **Mandatory OA — ~$2,700 APC** (fully OA publisher)
- **Reviews:** Yes, accepts reviews
- **Scope:** Chemistry, pharmacology, natural products
- **Note:** MDPI is a fully Open Access publisher — ALL publications require APC

### 14. Frontiers in Pharmacology
- **Publisher:** Frontiers
- **ISSN:** 1663-9812
- **IF:** ~5.6 (2023)
- **SCIE:** Yes
- **Q1/Q2:** Q1 (Pharmacology & Pharmacy)
- **Fees:** ❌ **Mandatory OA — ~$2,950 APC** (fully OA publisher)
- **Reviews:** Yes, accepts reviews
- **Scope:** Pharmacology, including natural product pharmacology
- **Note:** Frontiers is a fully Open Access publisher — ALL publications require APC

---

## IMPORTANT NOTES ON "ZERO FEES" CLAIMS

### What "subscription journal" means:
- Reader pays via institutional subscription
- Authors typically pay **NO publication fees**
- Some may charge optional fees for:
  - Color figures in print (decreasingly relevant as most are online-only)
  - Extra page charges (if paper exceeds page limit)
  - Early online publication
  - Reprints

### For the journals listed as FREE (items 1-10):
- **No APC** (Article Processing Charge)
- **No page charges** for standard-length papers
- **No color figure fees** (online color is free; print color may be charged but print editions are rare)
- **No submission fees**
- **No processing fees**
- **Gold OA is optional** — authors can choose to pay an APC to make their article openly accessible, but this is NOT required

### Hybrid OA journals (subscription with OA option):
Some of the "free" journals above offer an optional Gold OA pathway. If you want your paper to be freely accessible, you CAN pay the APC. But you do NOT have to — your paper will still be published and indexed.

---

## RECOMMENDED JOURNALS FOR BREAST CANCER + NATURAL PRODUCTS REVIEW

### Tier 1 (IF ≥ 5.0, Q1, Zero Fees):
1. **Journal of Ethnopharmacology** — IF 5.4, Q1, ZERO fees
2. **Phytotherapy Research** — IF 6.1, Q1, ZERO fees
3. **Journal of Natural Products** — IF 5.1, Q1/Q2, ZERO fees
4. **Chemico-Biological Interactions** — IF 5.1, Q1/Q2, ZERO fees

### Tier 2 (IF 2.0-5.0, Q1/Q2, Zero Fees):
5. **Planta Medica** — IF 2.5, Q1/Q2, ZERO fees
6. **South African Journal of Botany** — IF 3.0, Q1, ZERO fees
7. **Journal of Natural Medicines** — IF 2.9, Q2, ZERO fees
8. **Fitoterapia** — IF 2.3, Q2, ZERO fees
9. **Natural Product Research** — IF 2.2, Q2, ZERO fees
10. **Bioorganic & Medicinal Chemistry Letters** — IF 2.5, Q2, ZERO fees

---

## KEY TAKEAWAY

**For a review on natural products against breast cancer with ZERO author fees, the best options are:**

1. **Phytotherapy Research** (IF 6.1, Q1) — Highest IF among free journals, excellent for natural product pharmacology reviews
2. **Journal of Ethnopharmacology** (IF 5.4, Q1) — Top choice for ethnopharmacological/natural product reviews
3. **Journal of Natural Products** (IF 5.1, Q1/Q2) — Premier natural product chemistry journal
4. **Chemico-Biological Interactions** (IF 5.1, Q1/Q2) — Good for mechanistic studies

All four accept review articles and charge ZERO fees for subscription publication.

---

*Analysis compiled: August 5, 2026*
*Note: Impact Factors are approximate and based on JCR 2023 data. Fees verified against publisher guidelines. Always confirm current fees on journal websites before submission.*
