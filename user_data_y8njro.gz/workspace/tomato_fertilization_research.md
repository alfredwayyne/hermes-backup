# Tomato Fertilization Research — Comprehensive Source Document
## For SEO Article: "Best fertilizer for tomatoes | Complete fertilization program from seedling to harvest"

---

## 1. BEST FERTILIZERS FOR TOMATOES (NPK Ratios)

### Overview of NPK Requirements
Tomatoes are heavy feeders requiring significant amounts of all three primary macronutrients: Nitrogen (N), Phosphorus (P), and Potassium (K).

**Source: UMN Extension (extension.umn.edu)**
- Tomatoes need NPK to fuel leaf, root, and fruit development
- Apply phosphorus (P) and potassium (K) according to soil test recommendations
- Many soils have enough phosphorus — use low- or no-phosphorus fertilizer unless soil test recommends otherwise
- Too much nitrogen leads to bushy, leafy plants slow to bear fruit

**Recommended NPK Ratios by Growth Stage:**
- **Seedling/Transplanting:** Higher phosphorus ratios like 10-20-10 or 5-10-5 to promote root development
- **Vegetative Growth:** Balanced ratios like 10-10-10 or slightly higher nitrogen 20-10-10
- **Flowering/Fruiting:** Lower nitrogen, higher potassium ratios like 5-10-10 or 8-32-16
- **General Tomato Fertilizer:** Many commercial tomato-specific fertilizers use ratios like 4-7-10, 3-4-6, or 5-10-10

**Specific Fertilizer Recommendations:**
- **Espoma Tomato-Tone:** 4-7-10 or 3-4-6 (organic)
- **46-0-0 (Urea):** Pure nitrogen source — ½ cup per 100 feet of row (UMN Extension)
- **27-3-3:** 1 cup per 100 feet of row (UMN Extension)
- **10-3-1:** 3½ cups per 100 feet of row (UMN Extension)
- **Bone meal:** Excellent phosphorus source, add to planting hole at transplanting (Almanac)
- **Fish emulsion:** 5-1-1 or similar, good liquid organic option
- **Blood meal:** High nitrogen (12-0-0), for nitrogen-deficient soils

### Source References:
1. UMN Extension — "Growing tomatoes in home gardens" (extension.umn.edu/vegetables/growing-tomatoes-home-gardens)
2. The Old Farmer's Almanac — "How to Grow Tomatoes" (almanac.com/plant/tomatoes)
3. Gardening Know How — "The Ultimate Tomato Fertilizer Guide" (gardeningknowhow.com/edible/vegetables/tomato/tomato-fertilizer.htm)

---

## 2. FERTILIZATION SCHEDULE: SEEDLING TO HARVEST

### Phase 1: Seedling/Starting (6-8 weeks before transplant)
- Use a balanced seed-starting mix with mild nutrients
- Avoid heavy fertilization — seedlings need minimal nutrients
- If using soilless mix, begin light liquid fertilizer (¼ strength) when first true leaves appear

### Phase 2: Transplanting (Planting Day)
**Source: The Almanac (almanac.com)**
- Work compost into the soil before planting
- Add a handful of organic tomato fertilizer or bone meal (phosphorus source) to the planting hole
- Do NOT apply high-nitrogen fertilizers — this promotes foliage, delays flowering and fruiting

**Source: UMN Extension**
- Have soil tested to determine pH (ideal: 5.5 to 7)
- Apply P and K according to soil test recommendations
- Improve soil with composted manure or compost in spring or fall

### Phase 3: Early Vegetative Growth (2-4 weeks after transplant)
- Allow plant to establish root system before heavy feeding
- Monitor leaf color — deep green indicates adequate nitrogen
- Light side-dressing may be needed if soil is poor

### Phase 4: Flowering & Fruiting (First flowers appear)
**Source: UMN Extension**
- When the first fruits start to enlarge, apply fertilizer alongside the row
- Use ½ cup of 46-0-0, or 1 cup of 27-3-3, or 3½ cups 10-3-1 for every 100 feet of row
- Spread in a six-inch wide band and scratch into surface soil

**Source: The Almanac**
- Side-dress plants with liquid seaweed, fish emulsion, or organic fertilizer every 2 weeks, starting when tomatoes are about 1 inch in diameter (golf ball size)
- If using granular organic formula (like Espoma Tomato-Tone 4-7-10 or 3-4-6): scratch 2-3 tablespoons around the drip line of each plant

### Phase 5: Active Fruiting (Continued production)
- Continue fertilizing every 3-4 weeks until frost
- Use potassium-rich fertilizer to support fruit development
- Monitor for calcium deficiency (blossom end rot)
- Avoid excess nitrogen which reduces fruit production

**Source: The Almanac**
- Continue fertilizing every 3 to 4 weeks until frost
- Avoid fast-release fertilizers
- Avoid high-nitrogen fertilizers

### Key Schedule Summary:
| Growth Stage | Timing | Fertilizer Type | NPK Focus |
|---|---|---|---|
| Seedling | 6-8 weeks pre-transplant | Light liquid (¼ strength) | Balanced (10-10-10 diluted) |
| Transplanting | Day 0 | Bone meal + compost in hole | High P (0-10-0, 4-12-0) |
| Vegetative | 2-4 weeks post-transplant | Light side-dress or none | Balanced or none |
| First fruit | When fruits ~1 inch | Side-dress granular | Low N, high K (5-10-10) |
| Active fruiting | Every 3-4 weeks | Liquid or granular | High K (4-7-10, 3-4-6) |
| Late season | Until frost | Continue same | High K |

### Source References:
1. UMN Extension — Tomato fertilization rates (extension.umn.edu)
2. The Almanac — Tomato fertilizing schedule (almanac.com)
3. RHS (Royal Horticultural Society) — Growing tomatoes (rhs.org.uk)

---

## 3. MICRONUTRIENTS NEEDED FOR TOMATOES

### Essential Micronutrients:
Tomatoes require several micronutrients in addition to the primary macronutrients (NPK):

**Calcium (Ca)**
- Critical for cell wall development
- Deficiency causes Blossom End Rot (BER) — the most common calcium-related disorder
- Not truly a soil deficiency in most cases — usually caused by inconsistent watering
- Calcium is present in most soils but uptake is disrupted by water stress
- Foliar calcium sprays can help prevent BER
- Sources: gypsum, lime, calcium nitrate, bone meal

**Magnesium (Mg)**
- Central component of chlorophyll — essential for photosynthesis
- Deficiency causes interveinal chlorosis (yellowing between leaf veins)
- Common in acidic soils and heavily leached soils
- Sources: Epsom salt (magnesium sulfate), dolomitic lime, magnesium-rich fertilizers

**Iron (Fe)**
- Essential for chlorophyll synthesis and enzyme function
- Deficiency causes interveinal chlorosis in young leaves (similar to magnesium but in new growth)
- Usually only available in high-pH soils (>7.5)
- Sources: iron sulfate, chelated iron, compost

**Manganese (Mn)**
- Important for enzyme activation and photosynthesis
- Deficiency causes yellowing between veins with green veins remaining
- Sources: manganese sulfate, chelated manganese

**Boron (B)**
- Essential for cell wall formation and sugar transport
- Deficiency causes blossom drop and hollow fruit
- Important for fruit set
- Sources: borax, boron-containing fertilizers
- Caution: Boron toxicity can occur easily — apply sparingly

**Zinc (Zn)**
- Important for enzyme function and growth hormones
- Deficiency causes small, distorted leaves
- Sources: zinc sulfate, zinc chelates

**Copper (Cu)**
- Important for lignin synthesis and photosynthesis
- Deficiency causes wilting and dieback of growing tips

**Molybdenum (Mo)**
- Essential for nitrogen metabolism
- Deficiency causes marginal chlorosis similar to nitrogen deficiency but on older leaves

**Chlorine (Cl)**
- Important for osmosis and photosynthesis
- Deficiency causes wilting and bronzing of leaves

### Micronutrient Management Tips:
- Soil pH is the primary controller of micronutrient availability
- Optimal pH for tomatoes: 6.0-6.8 (slightly acidic to neutral)
- Below pH 6.0: manganese, iron, zinc, copper, boron become more available (potentially toxic)
- Above pH 7.0: iron, manganese, zinc, boron become less available (deficiency risk)
- Compost generally provides a good balance of micronutrients
- Complete fertilizers with micronutrients can address multiple deficiencies

---

## 4. ORGANIC VS SYNTHETIC FERTILIZERS FOR TOMATOES

### Organic Fertilizers:
**Advantages:**
- Slow-release nutrients that feed plants gradually
- Improve soil structure and microbial life
- Lower risk of burning plants
- Environmentally sustainable
- Build long-term soil health

**Common Organic Options for Tomatoes:**
- **Compost:** Balanced nutrients, improves soil structure (apply 2-4 inches before planting)
- **Composted manure:** Rich in NPK, improves soil biology (never use fresh manure — may contain harmful bacteria)
- **Bone meal:** High phosphorus (3-15-0), excellent for root development at transplanting
- **Blood meal:** High nitrogen (12-0-0), for nitrogen-deficient soils
- **Fish emulsion:** 5-1-1, good liquid organic nitrogen source
- **Fish/seaweed emulsion:** Balanced micronutrients plus NPK
- **Worm castings:** Gentle, balanced nutrients, improves soil biology
- **Kelp meal/seaweed:** Rich in micronutrients and growth hormones
- **Rock phosphate:** Slow-release phosphorus
- **Greensand:** Source of potassium and iron
- **Espoma Tomato-Tone (4-7-10 or 3-4-6):** Popular commercial organic tomato fertilizer

### Synthetic (Chemical) Fertilizers:
**Advantages:**
- Fast-acting, immediate nutrient availability
- Precise nutrient ratios
- Cost-effective for large areas
- Easy to store and apply
- Predictable results

**Common Synthetic Options:**
- **10-10-10 or 20-20-20:** General purpose balanced
- **5-10-10 or 10-30-20:** High P/K for fruiting
- **Urea (46-0-0):** Pure nitrogen
- **Ammonium nitrate (34-0-0):** Fast nitrogen
- **Superphosphate (0-20-0):** Phosphorus source
- **Muriate of potash (0-0-60):** Potassium source
- **Calcium nitrate (15.5-0-0 + 19% Ca):** Nitrogen + calcium

### Comparison Table:
| Factor | Organic | Synthetic |
|---|---|---|
| Release speed | Slow (weeks-months) | Fast (days) |
| Burn risk | Low | Moderate-High |
| Soil health | Improves over time | No soil improvement |
| Nutrient precision | Less precise | Very precise |
| Cost | Generally higher | Generally lower |
| Environmental impact | Low | Can cause runoff/pollution |
| Micronutrients | Usually included | Often need separate addition |
| Shelf life | Limited | Long |

### Source References:
1. UMN Extension — Recommends composted manure or compost, warns against fresh manure
2. The Almanac — Recommends organic tomato fertilizer or bone meal, fish emulsion, seaweed
3. Gardening Know How — Discusses both organic and synthetic options

---

## 5. COMMON MISTAKES IN TOMATO FERTILIZATION

### Mistake 1: Too Much Nitrogen
**Source: UMN Extension & The Almanac**
- "Too much nitrogen fertilization will lead to plants that are bushy, leafy, and slow to bear fruit"
- "Do NOT apply high-nitrogen fertilizers such as those recommended for lawns, as this will promote luxurious foliage but can delay flowering and fruiting"
- **Result:** Lush green foliage with few or no flowers/fruits
- **Fix:** Use balanced or low-nitrogen fertilizer once flowering begins

### Mistake 2: Fertilizing Before Soil Test
**Source: UMN Extension**
- "Have your soil tested to determine pH"
- "Apply phosphorus (P) and potassium (K) according to soil test recommendations"
- "Many Minnesota soils have enough phosphorus"
- **Result:** Over- or under-application of specific nutrients
- **Fix:** Always test soil before planting season

### Mistake 3: Using "Weed and Feed" Products
**Source: UMN Extension**
- "Do not use any fertilizer containing a weed killer ('Weed and Feed'), as it may kill your vegetable plants"
- **Result:** Plant damage or death
- **Fix:** Use only fertilizers specifically labeled for vegetables

### Mistake 4: Not Adjusting Fertilizer During Growth Stages
- Using the same fertilizer from seedling to harvest
- Not reducing nitrogen when flowering begins
- Not increasing potassium during fruiting
- **Fix:** Follow stage-specific fertilization schedule

### Mistake 5: Over-fertilization / Too Frequent Application
- Applying fertilizer too often causes salt buildup
- Can burn roots and damage plants
- **Fix:** Follow recommended rates and intervals (every 3-4 weeks for side-dressing)

### Mistake 6: Fertilizing Dry Plants
- Applying fertilizer to dry soil causes root burn
- **Fix:** Water plants before and after fertilizing

### Mistake 7: Using Fresh Manure
**Source: UMN Extension**
- "Do not use fresh manure as it may contain harmful bacteria and increase weed problems"
- **Result:** Nitrogen burn, weed infestation, potential pathogen contamination
- **Fix:** Only use composted manure (6+ months composting)

### Mistake 8: Neglecting Calcium for Fruit Quality
- Not addressing calcium availability during fruit development
- **Result:** Blossom End Rot (BER)
- **Fix:** Ensure consistent watering, consider calcium supplementation

### Mistake 9: Ignoring pH
- Soil pH outside 5.5-7.0 range limits nutrient availability
- **Fix:** Test pH and amend with lime (to raise) or sulfur (to lower)

### Mistake 10: Using Fast-Release Fertilizers Exclusively
**Source: The Almanac**
- "Avoid fast-release fertilizers"
- **Result:** Nutrient spikes followed by deficiencies, potential burning
- **Fix:** Use combination of slow-release and supplemental liquid feeding

---

## 6. SIGNS OF NUTRIENT DEFICIENCY IN TOMATOES

### Nitrogen (N) Deficiency:
- Yellowing of older/lower leaves first
- Stunted growth
- Pale green to yellow foliage
- Reduced fruit production
- Overall weak, spindly plants

### Phosphorus (P) Deficiency:
- Dark green to purplish discoloration of leaves
- Stunted growth
- Delayed maturity
- Reduced root development
- Poor fruit set

### Potassium (K) Deficiency:
- Yellowing/browning of leaf margins (edges)
- Leaf curling
- Weak stems
- Small, misshapen fruit
- Reduced disease resistance

### Calcium (Ca) Deficiency — Blossom End Rot (BER):
**Source: UMN Extension**
- "Blossom end rot causes the ends of tomato fruit to not develop, leading to the 'blossom end' becoming scabbed over or moldy"
- Dark, sunken, leathery spots on the bottom (blossom end) of fruit
- Usually caused by inconsistent watering disrupting calcium uptake
- Most common in the first fruits of the season
- **Not typically a soil calcium deficiency** — more about uptake and water management

### Magnesium (Mg) Deficiency:
- Interveinal chlorosis (yellowing between veins) on older leaves
- Green veins remain visible
- Can progress to necrosis (tissue death)
- Usually appears mid-to-late season

### Iron (Fe) Deficiency:
- Interveinal chlorosis on YOUNG/NEW leaves
- Similar to magnesium but affects new growth first
- Usually in high-pH soils (>7.0)
- Severe cases: entire leaf turns white/yellow

### Boron (B) Deficiency:
- Blossom drop (flowers falling before fruit set)
- Hollow fruit
- Cracking and corky areas inside fruit
- Stunted growing tips

### Zinc (Zn) Deficiency:
- Small, narrow leaves ("little leaf")
- Shortened internodes
- Reduced leaf size

### Manganese (Mn) Deficiency:
- Interveinal chlorosis on young leaves
- Small brown spots may develop
- Similar to iron deficiency but less severe

### General Disorder: Growth Cracks
**Source: UMN Extension**
- "Growth cracks occur on fruit when they grow too quickly, and most often occur during times of heavy rains and warm temperatures"
- Often linked to inconsistent watering and nutrient/water balance

### General Disorder: Catfacing
**Source: UMN Extension**
- "Catfacing is when fruit becomes scarred and has many potential causes"
- Can include cold damage, poor pollination, and nutritional imbalances

---

## SUMMARY OF SOURCES

### University Extension Services:
1. **UMN Extension (University of Minnesota)** — "Growing tomatoes in home gardens"
   - URL: https://extension.umn.edu/vegetables/growing-tomatoes-home-gardens
   - Content: Soil testing, fertilizer rates, pH recommendations, pest/disease information
   
2. **UMN Extension** — Blossom End Rot and other disorders
   - Content: BER description, growth cracks, catfacing, sunscald, yellow shoulders

### Reputable Gardening Websites:
3. **The Old Farmer's Almanac** — "How to Grow Tomatoes: Complete Guide"
   - URL: https://www.almanac.com/plant/tomatoes
   - Content: Transplanting fertilizer, side-dressing schedule, organic options, compost recommendations

4. **Gardening Know How** — "The Ultimate Tomato Fertilizer Guide"
   - URL: https://www.gardeningknowhow.com/edible/vegetables/tomato/tomato-fertilizer.htm
   - Content: NPK overview, soil testing importance, big feeder classification

5. **RHS (Royal Horticultural Society)** — Growing tomatoes
   - URL: https://www.rhs.org.uk/vegetables/tomatoes/grow-your-own
   - Content: Compost types, planting methods, general care

### Additional Authoritative Sources (Referenced Knowledge):
6. **UC Davis** — Tomato production recommendations
7. **Cornell University** — Vegetable production guidelines
8. **Purdue Extension** — Home vegetable garden fertility
9. **IPI/IFA** — International tomato nutrition guidelines

---

## KEY DATA POINTS FOR THE ARTICLE

### NPK Numbers to Include:
- Transplanting: Bone meal (3-15-0) or 10-20-10
- Vegetative: Balanced 10-10-10
- Fruiting: 5-10-10 or 4-7-10
- Organic options: Espoma Tomato-Tone (4-7-10 or 3-4-6), Fish emulsion (5-1-1)

### Application Rates (UMN Extension):
- ½ cup of 46-0-0 per 100 feet of row
- 1 cup of 27-3-3 per 100 feet of row
- 3½ cups of 10-3-1 per 100 feet of row
- 2-3 tablespoons granular organic per plant

### Schedule:
- At transplanting: bone meal/compost in hole
- First fruit (1 inch diameter): first side-dress
- Every 2 weeks: liquid fertilizer
- Every 3-4 weeks: granular fertilizer
- Continue until frost

### pH:
- Optimal: 5.5-7.0 (best: 6.0-6.8)
- Below 5.5: too acidic, nutrient lockout
- Above 7.0: too alkaline, iron/manganese/zinc deficiency

### Key Warnings:
- Never use fresh manure
- Never use weed-and-feed products
- Too much nitrogen = lush leaves, no fruit
- Inconsistent watering = blossom end rot
- Always test soil before fertilizing
