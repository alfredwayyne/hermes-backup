#!/usr/bin/env python3
"""Verify journal criteria using web searches and direct sources."""

import urllib.request
import json
import re
import time

def fetch_url(url, timeout=15):
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"
        })
        response = urllib.request.urlopen(req, timeout=timeout)
        return response.read().decode("utf-8", errors="ignore")
    except Exception as e:
        return f"ERROR: {e}"

def get_wikipedia_full(wiki_name):
    """Get full Wikipedia page text."""
    url = f"https://en.wikipedia.org/wiki/{wiki_name}"
    html = fetch_url(url)
    if html.startswith("ERROR"):
        return None
    text = re.sub(r'<[^>]+>', ' ', html)
    text = re.sub(r'&#\d+;', '', text)
    text = re.sub(r'&\w+;', ' ', text)
    text = re.sub(r'\s+', ' ', text)
    return text

# Verify Current Pharmaceutical Design - APC status
print("=== Checking Current Pharmaceutical Design APC status ===")
# Bentham Science journals typically have APCs for open access but are free for subscription
# Let me check their website
url = "https://www.eurekaselect.com/page/journal/1381-6128"
html = fetch_url(url)
if not html.startswith("ERROR"):
    text = re.sub(r'<[^>]+>', ' ', html)
    text = re.sub(r'\s+', ' ', text)
    # Look for APC/payment info
    apc_match = re.search(r'(?:APC|article processing|publication fee|charge|free|no fee)[^.]{0,200}', text, re.IGNORECASE)
    if apc_match:
        print(f"  APC info: {apc_match.group()[:200]}")
    else:
        print("  No APC info found on page")
    
    # Check if it's open access
    oa_match = re.search(r'(?:open access|free to publish|no publication fee)[^.]{0,200}', text, re.IGNORECASE)
    if oa_match:
        print(f"  OA info: {oa_match.group()[:200]}")
else:
    print(f"  Website error: {html[:100]}")

print()

# Check Bentham Science APC policy in general
print("=== Checking Bentham Science general APC policy ===")
url = "https://www.eurekaselect.com/page/publishing-policies"
html = fetch_url(url)
if not html.startswith("ERROR"):
    text = re.sub(r'<[^>]+>', ' ', html)
    text = re.sub(r'\s+', ' ', text)
    apc_match = re.search(r'(?:APC|article processing|publication fee|charge|free|no fee| waiver)[^.]{0,300}', text, re.IGNORECASE)
    if apc_match:
        print(f"  Policy: {apc_match.group()[:300]}")
else:
    print(f"  Error: {html[:100]}")

print()

# Check Evidence-Based Complementary and Alternative Medicine
print("=== Checking Evidence-Based Complementary and Alternative Medicine ===")
text = get_wikipedia_full("Evidence-Based_Complementary_and_Alternative_Medicine")
if text:
    if_match = re.search(r'Impact factor\s+(\d+\.?\d*)', text)
    has_sci = 'SCIE' in text or 'Science Citation Index' in text
    has_esci = 'ESCI' in text or 'Emerging Sources' in text
    has_discontinued = 'discontinued' in text.lower() or 'ceased' in text.lower()
    
    print(f"  IF: {if_match.group(1) if if_match else 'N/A'}")
    print(f"  SCIE: {has_sci}")
    print(f"  ESCI: {has_esci}")
    print(f"  Discontinued: {has_discontinued}")
    
    # Get more context
    if has_discontinued:
        print("  NOTE: This journal appears to be discontinued")
else:
    print("  Wikipedia page not found")

print()

# Check Integrative Cancer Therapies
print("=== Checking Integrative Cancer Therapies ===")
text = get_wikipedia_full("Integrative_Cancer_Therapies")
if text:
    if_match = re.search(r'Impact factor\s+(\d+\.?\d*)', text)
    has_sci = 'SCIE' in text or 'Science Citation Index' in text
    has_esci = 'ESCI' in text or 'Emerging Sources' in text
    
    print(f"  IF: {if_match.group(1) if if_match else 'N/A'}")
    print(f"  SCIE: {has_sci}")
    print(f"  ESCI: {has_esci}")
    
    # Get publisher
    publisher_match = re.search(r'Publisher\s+([A-Z][^,\.]{3,50})', text)
    if publisher_match:
        print(f"  Publisher: {publisher_match.group(1)}")
else:
    print("  Wikipedia page not found")

print()

# Check Pharmaceutical Biology more carefully
print("=== Checking Pharmaceutical Biology (Taylor & Francis) ===")
text = get_wikipedia_full("Pharmaceutical_Biology")
if text:
    if_match = re.search(r'Impact factor\s+(\d+\.?\d*)', text)
    has_sci = 'SCIE' in text or 'Science Citation Index' in text
    has_esci = 'ESCI' in text or 'Emerging Sources' in text
    
    print(f"  IF: {if_match.group(1) if if_match else 'N/A'}")
    print(f"  SCIE: {has_sci}")
    print(f"  ESCI: {has_esci}")
    
    publisher_match = re.search(r'Publisher\s+([A-Z][^,\.]{3,50})', text)
    if publisher_match:
        print(f"  Publisher: {publisher_match.group(1)}")
else:
    print("  Wikipedia page not found")

print()

# Check South African Journal of Botany more carefully
print("=== Checking South African Journal of Botany ===")
text = get_wikipedia_full("South_African_Journal_of_Botany")
if text:
    if_match = re.search(r'Impact factor\s+(\d+\.?\d*)', text)
    has_sci = 'SCIE' in text or 'Science Citation Index' in text
    has_esci = 'ESCI' in text or 'Emerging Sources' in text
    
    print(f"  IF: {if_match.group(1) if if_match else 'N/A'}")
    print(f"  SCIE: {has_sci}")
    print(f"  ESCI: {has_esci}")
    
    publisher_match = re.search(r'Publisher\s+([A-Z][^,\.]{3,50})', text)
    if publisher_match:
        print(f"  Publisher: {publisher_match.group(1)}")
else:
    print("  Wikipedia page not found")
