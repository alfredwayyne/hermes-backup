from duckduckgo_search import DDGS
import json

ddgs = DDGS()

searches = [
    "SAGE journals natural products",
    "SAGE journals pharmacology",
    "SAGE journals cancer biology",
    "SAGE journals medicinal chemistry",
    "SAGE journals herbal medicine",
    "SAGE journals complementary alternative medicine",
    "Journal of Herbal Pharmacotherapy SAGE",
    "Journal of Medicinal Food SAGE",
    "SAGE Open Medicine journal",
    "SAGE journals impact factor 2-4",
    "SAGE journals SCIE indexed pharmacology",
    "SAGE journals free publication",
    "SAGE journals subscription hybrid",
    "SAGE Advances in Clinical and Experimental Medicine",
    "SAGE journals drug discovery"
]

all_results = {}
for q in searches:
    try:
        results = ddgs.text(q, max_results=5)
        all_results[q] = results
        print(f"\n===== {q} =====")
        for r in results:
            print(f"  - {r['title']}")
            print(f"    URL: {r['href'][:120]}")
            print(f"    Body: {r['body'][:200]}")
    except Exception as e:
        print(f"ERROR for '{q}': {e}")
        all_results[q] = []

with open('/tmp/sage_search_results.json', 'w') as f:
    json.dump(all_results, f, indent=2)
print("\n\nResults saved to /tmp/sage_search_results.json")
