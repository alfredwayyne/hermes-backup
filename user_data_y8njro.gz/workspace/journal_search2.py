#!/usr/bin/env python3
"""Search OpenAlex for journals in natural products/pharmacognosy with specific citation metrics."""

import urllib.request
import json

def search_openalex_journals(concept, min_citedness=1.0, max_citedness=4.0):
    """Search for journals in a concept area with specific citation metrics."""
    try:
        # Use the search endpoint instead of filters
        encoded = concept.replace(" ", "%20")
        url = f"https://api.openalex.org/sources?search={encoded}&filter=type:journal&per_page=50&sort=summary_stats.2yr_mean_citedness:desc"
        req = urllib.request.Request(url, headers={"User-Agent": "JournalSearch/1.0 (mailto:research@example.com)"})
        response = urllib.request.urlopen(req, timeout=15)
        data = json.loads(response.read())
        return data.get("results", [])
    except Exception as e:
        print(f"Error searching {concept}: {e}")
        return []

# Search for journals
concepts = ["Pharmacognosy", "Natural products chemistry", "Ethnobotany", "Medicinal plants"]
all_journals = {}

for concept in concepts:
    journals = search_openalex_journals(concept, min_citedness=1.0, max_citedness=4.0)
    for j in journals:
        name = j.get("display_name", "")
        citedness = j.get("summary_stats", {}).get("2yr_mean_citedness", 0)
        h = j.get("summary_stats", {}).get("h_index", 0)
        oa = j.get("is_oa", False)
        publisher = j.get("host_organization_name", "")
        issn = j.get("issn_l", "")
        
        if name not in all_journals and 1.0 <= citedness <= 3.5:
            all_journals[name] = {
                "citedness": citedness,
                "h_index": h,
                "oa": oa,
                "publisher": publisher[:60],
                "issn": issn,
                "concept": concept,
            }

# Sort by citedness
sorted_journals = sorted(all_journals.items(), key=lambda x: x[1]["citedness"], reverse=True)

print(f"Found {len(sorted_journals)} journals with 2yr citedness 1.0-3.5:")
print()
for name, info in sorted_journals:
    print(f"  {name}")
    print(f"    Citedness: {info['citedness']:.2f}, H-index: {info['h_index']}, OA: {info['oa']}, Publisher: {info['publisher'][:50]}, ISSN: {info['issn']}")
    print(f"    Concept: {info['concept']}")
    print()
