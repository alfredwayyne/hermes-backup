#!/usr/bin/env python3
"""Comprehensive journal verification for natural products + breast cancer review."""

import urllib.request
import json
import re
import time

def fetch_url(url, timeout=15):
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"
        })
        response = urllib.request.urlopen(req, timeout=timeout)
        return response.read().decode("utf-8", errors="ignore")
    except Exception as e:
        return f"ERROR: {e}"

def get_wikipedia_if(wiki_name):
    """Get IF and indexing from Wikipedia."""
    url = f"https://en.wikipedia.org/wiki/{wiki_name}"
    html = fetch_url(url)
    if html.startswith("ERROR"):
        return None
    
    text = re.sub(r'<[^>]+>', ' ', html)
    text = re.sub(r'&#\d+;', '', text)
    text = re.sub(r'&\w+;', ' ', text)
    text = re.sub(r'\s+', ' ', text)
    
    if_match = re.search(r'Impact factor\s+(\d+\.?\d*)', text)
    has_sci = 'SCIE' in text or 'Science Citation Index' in text
    has_esci = 'ESCI' in text or 'Emerging Sources' in text
    has_scopus = 'Scopus' in text
    
    return {
        "if": if_match.group(1) if if_match else None,
        "scie": has_sci,
        "esci": has_esci,
        "scopus": has_scopus,
    }

# List of journals to check - using Wikipedia article names
journals_to_check = [
    # Original list
    ("Phytochemistry Letters", "Phytochemistry_Letters"),
    ("Journal of Ethnopharmacology", "Journal_of_Ethnopharmacology"),
    ("Pharmaceutical Biology", "Pharmaceutical_Biology_(journal)"),
    ("Biochemical Systematics and Ecology", "Biochemical_Systematics_and_Ecology"),
    ("South African Journal of Botany", "South_African_Journal_of_Botany"),
    ("Industrial Crops and Products", "Industrial_Crops_and_Products"),
    ("Journal of Pharmacy and BioAllied Sciences", "Journal_of_Pharmacy_and_Bioallied_Sciences"),
    ("Pharmacognosy Magazine", "Pharmacognosy_Magazine"),
    ("International Journal of Green Pharmacy", None),
    ("Research in Pharmaceutical Sciences", "Research_in_Pharmaceutical_Sciences"),
    ("Avicenna Journal of Phytomedicine", None),
    ("Iranian Journal of Pharmaceutical Research", None),
    ("Current Pharmaceutical Design", "Current_Pharmaceutical_Design"),
    ("Frontiers in Pharmacology", "Frontiers_in_Pharmacology"),
    ("Molecules", "Molecules_(MDPI)"),
    ("Plants", None),
    ("Biology", "Biology_(journal)"),
    # Additional candidates
    ("Natural Product Communications", "Natural_Product_Communications"),
    ("Natural Products and Bioprospecting", None),
    ("Journal of Natural Medicines", "Journal_of_Natural_Medicines"),
    ("Phytotherapy Research", "Phytotherapy_Research"),
    ("Journal of Ethnobiology and Ethnomedicine", "Journal_of_Ethnobiology_and_Ethnomedicine"),
    ("Bangladesh Journal of Pharmacology", "Bangladesh_Journal_of_Pharmacology"),
    ("Journal of Complementary and Integrative Medicine", None),
    ("Acta Pharmaceutica Sinica B", "Acta_Pharmaceutica_Sinica_B"),
    ("Journal of Asian Natural Products Research", "Journal_of_Asian_Natural_Products_Research"),
    ("Drug Discoveries & Therapeutics", None),
    ("Journal of Herbal Medicine", "Journal_of_Herbal_Medicine"),
    ("Chinese Journal of Integrative Medicine", "Chinese_Journal_of_Integrative_Medicine"),
    ("Zeitschrift für Naturforschung C", None),
    ("Chemistry of Natural Compounds", "Chemistry_of_Natural_Compounds"),
    ("Phyton - International Journal of Experimental Botany", "Phyton"),
    ("Evidence-Based Complementary and Alternative Medicine", None),
    ("Integrative Cancer Therapies", None),
    ("Journal of Cancer Research and Clinical Oncology", None),
    ("Molecular Medicine Reports", None),
    ("Oncology Letters", None),
    ("International Journal of Oncology", None),
    ("Molecular Medicine Reports", None),
    ("Oncology Letters", None),
    ("Experimental and Therapeutic Medicine", None),
    ("Molecular Medicine Reports", None),
    ("Oncology Letters", None),
]

# Deduplicate
seen = set()
unique_journals = []
for display, wiki in journals_to_check:
    if display not in seen:
        seen.add(display)
        unique_journals.append((display, wiki))

print("Checking journals via Wikipedia...")
print("=" * 80)

for display_name, wiki_name in unique_journals:
    if wiki_name:
        wiki_data = get_wikipedia_if(wiki_name)
        if wiki_data:
            if_val = wiki_data["if"]
            scie = wiki_data["scie"]
            esci = wiki_data["esci"]
            scopus = wiki_data["scopus"]
            
            in_range = False
            if if_val:
                try:
                    if_float = float(if_val)
                    in_range = 2.0 <= if_float <= 3.0
                except:
                    pass
            
            status = "✓ IN RANGE" if in_range else "✗"
            print(f"{display_name}")
            print(f"  IF: {if_val or 'N/A'} {status}")
            print(f"  SCIE: {scie}, ESCI: {esci}, Scopus: {scopus}")
            print()
        else:
            print(f"{display_name}: Wikipedia page not found")
            print()
    else:
        print(f"{display_name}: No Wikipedia article name specified")
        print()
    
    time.sleep(0.3)  # Be polite to Wikipedia
