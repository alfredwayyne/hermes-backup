#!/usr/bin/env python3
"""Verify remaining criteria for promising journals and search for more candidates."""

import urllib.request
import json
import re
import time

def fetch_url(url, timeout=15):
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"
        })
        response = urllib.request.urlopen(req, timeout=timeout)
        return response.read().decode("utf-8", errors="ignore")
    except Exception as e:
        return f"ERROR: {e}"

def get_openalex_data(name):
    """Get journal data from OpenAlex."""
    try:
        encoded = name.replace(" ", "%20")
        url = f"https://api.openalex.org/sources?search={encoded}&per_page=1"
        req = urllib.request.Request(url, headers={"User-Agent": "JournalSearch/1.0 (mailto:research@example.com)"})
        response = urllib.request.urlopen(req, timeout=10)
        data = json.loads(response.read())
        results = data.get("results", [])
        if results:
            j = results[0]
            return {
                "name": j.get("display_name", "N/A"),
                "issn": j.get("issn_l", "N/A"),
                "oa": j.get("is_oa", False),
                "h_index": j.get("summary_stats", {}).get("h_index", 0),
                "citedness": j.get("summary_stats", {}).get("2yr_mean_citedness", 0),
                "publisher": j.get("host_organization_name", ""),
                "type": j.get("type", ""),
            }
    except:
        pass
    return None

# Check promising candidates more thoroughly
candidates = [
    "Current Pharmaceutical Design",
    "Phytotherapy Research",
    "Journal of Natural Medicines",
    "Natural Product Communications",
    "Natural Products and Bioprospecting",
    "Journal of Asian Natural Products Research",
    "Acta Pharmaceutica Sinica B",
    "Evidence-Based Complementary and Alternative Medicine",
    "Integrative Cancer Therapies",
    "Journal of Cancer Research and Clinical Oncology",
    "Molecular Medicine Reports",
    "Oncology Letters",
    "International Journal of Oncology",
    "Experimental and Therapeutic Medicine",
    "Pharmaceutical Biology",
    "Journal of Ethnopharmacology",
    "South African Journal of Botany",
    "Biochemical Systematics and Ecology",
]

print("Checking OpenAlex data for candidates...")
print("=" * 80)

for name in candidates:
    data = get_openalex_data(name)
    if data:
        print(f"\n=== {name} ===")
        print(f"  Matched: {data['name']}")
        print(f"  ISSN: {data['issn']}")
        print(f"  OA: {data['oa']}")
        print(f"  H-index: {data['h_index']}")
        print(f"  2yr citedness: {data['citedness']:.2f}")
        print(f"  Publisher: {data['publisher'][:50]}")
        print(f"  Type: {data['type']}")
    else:
        print(f"\n=== {name} === NOT FOUND")
    
    time.sleep(0.5)
