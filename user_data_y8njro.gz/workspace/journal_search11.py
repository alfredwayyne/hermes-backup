#!/usr/bin/env python3
"""Check more journal websites and verify key details."""

import urllib.request
import json
import re
import time

def fetch_url(url, timeout=15):
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"
        })
        response = urllib.request.urlopen(req, timeout=timeout)
        return response.read().decode("utf-8", errors="ignore")
    except Exception as e:
        return f"ERROR: {e}"

# Check Journal of Natural Medicines more thoroughly
print("=== Journal of Natural Medicines (Springer) - Detailed ===")
url = "https://www.springer.com/journal/11418"
html = fetch_url(url)
if not html.startswith("ERROR"):
    text = re.sub(r'<[^>]+>', ' ', html)
    text = re.sub(r'\s+', ' ', text)
    
    # Extract key info
    if_match = re.search(r'Impact Factor\s*:?\s*(\d+\.?\d*)', text)
    has_sci = 'SCIE' in text or 'Science Citation Index' in text
    has_scopus = 'Scopus' in text
    has_medline = 'MEDLINE' in text
    has_pubmed = 'PubMed' in text
    
    print(f"  IF: {if_match.group(1) if if_match else 'N/A'}")
    print(f"  SCIE: {has_sci}")
    print(f"  Scopus: {has_scopus}")
    print(f"  MEDLINE: {has_medline}")
    print(f"  PubMed: {has_pubmed}")
    
    # Look for indexing info
    for pattern in [r'SCIE[^.]{0,100}', r'ESCI[^.]{0,100}', r'Quartile[^.]{0,100}', 
                    r'Q[1-4][^.]{0,100}', r'SJR[^.]{0,100}']:
        matches = re.findall(pattern, text, re.IGNORECASE)
        for m in matches[:2]:
            print(f"  {m[:150]}")
else:
    print(f"  Error: {html[:100]}")

print()

# Try to find Journal of Natural Medicines IF from other sources
print("=== Checking Journal of Natural Medicines from other sources ===")
# Try Springer's metrics page
url = "https://www.springer.com/journal/11418/metrics"
html = fetch_url(url)
if not html.startswith("ERROR"):
    text = re.sub(r'<[^>]+>', ' ', html)
    text = re.sub(r'\s+', ' ', text)
    
    if_match = re.search(r'Impact Factor\s*:?\s*(\d+\.?\d*)', text)
    print(f"  IF from metrics page: {if_match.group(1) if if_match else 'N/A'}")
    
    # Look for SJR, quartile
    for pattern in [r'SJR[^.]{0,100}', r'Q[1-4][^.]{0,100}', r'Quartile[^.]{0,100}']:
        matches = re.findall(pattern, text, re.IGNORECASE)
        for m in matches[:2]:
            print(f"  {m[:150]}")
else:
    print(f"  Metrics page error: {html[:100]}")

print()

# Check a few more journals
more_journals = [
    ("Molecules (MDPI)", "https://www.mdpi.com/journal/molecules"),
    ("Plants (MDPI)", "https://www.mdpi.com/journal/plants"),
    ("Frontiers in Pharmacology", "https://www.frontiersin.org/journals/pharmacology"),
    ("Biology (MDPI)", "https://www.mdpi.com/journal/biology"),
]

for name, url in more_journals:
    print(f"=== {name} ===")
    html = fetch_url(url)
    if not html.startswith("ERROR"):
        text = re.sub(r'<[^>]+>', ' ', html)
        text = re.sub(r'\s+', ' ', text)
        
        if_match = re.search(r'Impact Factor\s*:?\s*(\d+\.?\d*)', text)
        has_sci = 'SCIE' in text or 'Science Citation Index' in text
        has_esci = 'ESCI' in text or 'Emerging Sources' in text
        has_scopus = 'Scopus' in text
        has_oa = 'open access' in text.lower()
        has_apc = 'APC' in text or 'article processing charge' in text.lower() or 'publication fee' in text.lower()
        
        print(f"  IF: {if_match.group(1) if if_match else 'N/A'}")
        print(f"  SCIE: {has_sci}")
        print(f"  ESCI: {has_esci}")
        print(f"  Scopus: {has_scopus}")
        print(f"  OA: {has_oa}")
        print(f"  APC mentioned: {has_apc}")
        
        # Look for APC amount
        apc_match = re.search(r'(?:APC|article processing charge|publication fee)\s*[:\$]?\s*(?:US)?\s*\$?\s*(\d[\d,]*)', text, re.IGNORECASE)
        if apc_match:
            print(f"  APC amount: ${apc_match.group(1)}")
    else:
        print(f"  Error: {html[:100]}")
    print()
    time.sleep(0.5)
