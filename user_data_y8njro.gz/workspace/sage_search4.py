from ddgs import DDGS
import json

ddgs = DDGS()

# Get more detailed info for key journals
searches = [
    "SAGE Open Medicine SCIE indexed Web of Science",
    "Tumor Biology SAGE impact factor 2024 2025 SCIE",
    "Journal of Medicinal Food impact factor SCIE SCOPUS 2024",
    "Experimental Biology and Medicine SAGE impact factor SCIE APC",
    "Journal of Current Oncology SAGE impact factor APC SCIE",
    "Cancer Informatics SAGE impact factor 2.5 SCIE APC",
    "Journal of Integrative Complementary Medicine SAGE IF SCIE",
    "Perspectives Medicinal Chemistry SAGE impact factor SCIE discontinued",
    "SAGE Open Medicine submission fee waiver APC",
    "Tumor Biology SAGE submission guidelines review articles",
    "Journal of Medicinal Food submission guidelines review articles scope",
    "Experimental Biology and Medicine submission guidelines review articles",
    "SAGE journals subscription hybrid free APC waiver authors"
]

for q in searches:
    try:
        results = ddgs.text(q, max_results=4)
        print(f"\n===== {q} =====")
        for r in results:
            print(f"  Title: {r['title']}")
            print(f"  Body: {r['body'][:300]}")
            print()
    except Exception as e:
        print(f"ERROR for '{q}': {e}")
