from ddgs import DDGS
import json

ddgs = DDGS()

# Final detailed searches for the most promising journals
searches = [
    '"SAGE Open Medicine" "impact factor" "2.2" SCIE SCOPUS',
    '"Tumor Biology" "impact factor" SAGE 2024 2025',
    '"Journal of Medicinal Food" "impact factor" SAGE 2024',
    '"Experimental Biology and Medicine" "impact factor" 2.8 SAGE',
    '"Journal of Current Oncology" SAGE "impact factor" 3.8',
    '"Cancer Informatics" SAGE "impact factor" 2.5',
    '"Journal of Integrative and Complementary Medicine" SAGE "impact factor"',
    'SAGE Open Medicine no APC free publish subscription',
    'SAGE subscription journals free publish no APC hybrid',
    '"Tumor Biology" SAGE APC waived free',
    '"Journal of Medicinal Food" SAGE APC subscription hybrid',
    '"Experimental Biology and Medicine" SAGE subscription hybrid APC',
    'SAGE journals subscription no APC pharmacology biology',
]

for q in searches:
    try:
        results = ddgs.text(q, max_results=3)
        print(f"\n===== {q} =====")
        for r in results:
            print(f"  Title: {r['title']}")
            print(f"  Body: {r['body'][:300]}")
            print()
    except Exception as e:
        print(f"ERROR for '{q}': {e}")
