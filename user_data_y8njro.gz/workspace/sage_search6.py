from ddgs import DDGS

ddgs = DDGS()

# Critical checks - some journals may have moved from SAGE
searches = [
    "Tumor Biology IOS Press 2021 still SAGE",
    "SAGE Open Medicine SCIE indexed Web of Science 2024",
    "SAGE Open Medicine indexing databases SCIE ESCI",
    "Journal of Medicinal Food Mary Ann Liebert SAGE 2024",
    "Journal of Current Oncology SAGE Liebert impact factor SCIE",
    "SAGE subscription journals free publish no APC pharmacology",
    "SAGE journals list SCIE indexed pharmacology cancer 2024",
    "Journal of Herbal Pharmacotherapy publisher discontinued",
    "Perspectives Medicinal Chemistry SAGE discontinued",
    "SAGE journals with IF 2-4 SCIE indexed free APC 2024",
    "Cancer Control SAGE impact factor SCIE",
    "Cancer Informatics SAGE SCIE indexed impact factor 2024",
]

for q in searches:
    try:
        results = ddgs.text(q, max_results=3)
        print(f"\n===== {q} =====")
        for r in results:
            print(f"  Title: {r['title']}")
            print(f"  Body: {r['body'][:300]}")
            print()
    except Exception as e:
        print(f"ERROR for {q}: {e}")
