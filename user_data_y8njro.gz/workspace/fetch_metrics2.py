import urllib.request
import re
import json
import ssl

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

def fetch_url(url, timeout=15):
    req = urllib.request.Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
    })
    resp = urllib.request.urlopen(req, timeout=timeout, context=ctx)
    return resp.read().decode("utf-8", errors="ignore")

# Try fetching from different sources
# 1. Try Resurchify
# 2. Try LetPub
# 3. Try WoS Master Journal List

journals = [
    ("Journal of Medicinal Food", "1096-620X"),
    ("Journal of Natural Products", "0163-3864"),
    ("Natural Product Reports", "0265-0568"),
    ("ACS Medicinal Chemistry Letters", "1948-5875"),
    ("Journal of Medicinal Plants Research", "1996-0875"),
    ("Research in Pharmaceutical Sciences", "1735-5362"),
]

for name, issn in journals:
    print(f"\n=== {name} ===")
    
    # Try LetPub
    slug = name.lower().replace(" ", "+").replace(",", "").replace(":", "")
    url = f"https://www.letpub.com.cn/index.php?page=journalapp&view=detail&journalid={issn}"
    try:
        html = fetch_url(url, timeout=10)
        if_match = re.findall(r"影响因子[:\s]*(\d+\.\d+)", html)
        q_match = re.findall(r"中科院分区[:\s]*Q(\d)", html)
        scie_match = re.findall(r"SCI|SCIE|Science Citation Index", html, re.IGNORECASE)
        print(f"  LetPub IF: {if_match[:3]}")
        print(f"  LetPub Q: {q_match[:5]}")
        print(f"  LetPub SCIE: {'Yes' if scie_match else 'No'}")
        if not if_match and not q_match:
            # Try different URL format
            print(f"  LetPub HTML length: {len(html)}")
            print(f"  LetPub snippet: {html[:200]}")
    except Exception as e:
        print(f"  LetPub: ERROR - {e}")
    
    # Try to get from another source - maybe the journal's own website
    try:
        if "acs.org" in name.lower() or "acs" in name.lower():
            # Try ACS journals
            url = f"https://pubs.acs.org/page/{issn}/about.html"
            html = fetch_url(url, timeout=10)
            if_match = re.findall(r"Impact Factor[:\s]*(\d+\.\d+)", html)
            print(f"  ACS IF: {if_match[:3]}")
        elif "rsc.org" in name.lower() or "royal" in name.lower():
            # Try RSC journals
            url = f"https://pubs.rsc.org/en/journals/{issn}"
            html = fetch_url(url, timeout=10)
            if_match = re.findall(r"Impact Factor[:\s]*(\d+\.\d+)", html)
            print(f"  RSC IF: {if_match[:3]}")
    except Exception as e:
        print(f"  Publisher site: ERROR - {e}")
