#!/usr/bin/env python3
"""Final verification of remaining criteria for promising journals."""

import urllib.request
import json
import re
import time

def fetch_url(url, timeout=15):
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"
        })
        response = urllib.request.urlopen(req, timeout=timeout)
        return response.read().decode("utf-8", errors="ignore")
    except Exception as e:
        return f"ERROR: {e}"

# Check Current Pharmaceutical Design - Bentham Science
print("=== Current Pharmaceutical Design - APC & Reviews ===")
# Try Bentham's main page
url = "https://www.eurekaselect.com/page/journal/1381-6128"
html = fetch_url(url)
if not html.startswith("ERROR"):
    text = re.sub(r'<[^>]+>', ' ', html)
    text = re.sub(r'\s+', ' ', text)
    # Check for review articles
    if 'review' in text.lower():
        print("  Accepts reviews: Likely YES")
    # Check for APC
    if 'open access' in text.lower():
        print("  Open access option available")
    if 'free' in text.lower() and 'publish' in text.lower():
        print("  Free to publish: YES")
else:
    print(f"  Website: {html[:100]}")

# Bentham Science APC policy - generally they charge for OA but subscription is free
print("  Note: Bentham Science typically charges APC for OA but subscription publishing is free")

print()

# Check Current Cancer Drug Targets - Bentham Science
print("=== Current Cancer Drug Targets - APC & Reviews ===")
url = "https://www.eurekaselect.com/page/journal/1568-0096"
html = fetch_url(url)
if not html.startswith("ERROR"):
    text = re.sub(r'<[^>]+>', ' ', html)
    text = re.sub(r'\s+', ' ', text)
    if 'review' in text.lower():
        print("  Accepts reviews: Likely YES")
    if 'open access' in text.lower():
        print("  Open access option available")
else:
    print(f"  Website: {html[:100]}")

print("  Note: Bentham Science typically charges APC for OA but subscription publishing is free")

print()

# Check Journal of Natural Medicines - Scopus Q
print("=== Journal of Natural Medicines - Scopus Q verification ===")
# Try to find Scopus data from other sources
# Try DOAJ
url = "https://doaj.org/api/search/journals/Journal%20of%20Natural%20Medicines"
html = fetch_url(url)
if not html.startswith("ERROR"):
    try:
        data = json.loads(html)
        results = data.get("results", [])
        if results:
            j = results[0]
            print(f"  DOAJ data: {json.dumps(j, indent=2)[:500]}")
    except:
        print(f"  DOAJ response: {html[:300]}")
else:
    print(f"  DOAJ error: {html[:100]}")

print()

# Try to find Scopus Q for Journal of Natural Medicines via Web of Science
# Check if it's in WOS
url = "https://mjl.clarivate.com/search-results?issn=1340-3443"
html = fetch_url(url)
if not html.startswith("ERROR"):
    text = re.sub(r'<[^>]+>', ' ', html)
    text = re.sub(r'\s+', ' ', text)
    # Look for SCIE/ESCI
    if 'SCIE' in text:
        print("  WOS: SCIE indexed")
    if 'ESCI' in text:
        print("  WOS: ESCI indexed")
    if 'Science Citation Index' in text:
        print("  WOS: Science Citation Index mentioned")
else:
    print(f"  WOS error: {html[:100]}")

print()

# Check Integrative Cancer Therapies - SAGE
print("=== Integrative Cancer Therapies - SAGE verification ===")
url = "https://journals.sagepub.com/home/ict"
html = fetch_url(url)
if not html.startswith("ERROR"):
    text = re.sub(r'<[^>]+>', ' ', html)
    text = re.sub(r'\s+', ' ', text)
    
    # Check for indexing
    if 'SCIE' in text:
        print("  SCIE: Yes")
    if 'ESCI' in text:
        print("  ESCI: Yes")
    if 'Scopus' in text:
        print("  Scopus: Yes")
    if 'MEDLINE' in text:
        print("  MEDLINE: Yes")
    if 'PubMed' in text:
        print("  PubMed: Yes")
    
    # Check for APC
    apc_match = re.search(r'(?:APC|article processing|publication fee|charge)\s*[:\$]?\s*(?:US)?\s*\$?\s*(\d[\d,]*)', text, re.IGNORECASE)
    if apc_match:
        print(f"  APC: ${apc_match.group(1)}")
    
    # Check for reviews
    if 'review' in text.lower():
        print("  Accepts reviews: Likely YES")
else:
    print(f"  SAGE error: {html[:100]}")

print()

# Check Pharmacognosy Magazine more thoroughly
print("=== Pharmacognosy Magazine - SAGE verification ===")
url = "https://journals.sagepub.com/home/pmx"
html = fetch_url(url)
if not html.startswith("ERROR"):
    text = re.sub(r'<[^>]+>', ' ', html)
    text = re.sub(r'\s+', ' ', text)
    
    if_match = re.search(r'Impact Factor\s*:?\s*(\d+\.?\d*)', text)
    print(f"  IF: {if_match.group(1) if if_match else 'N/A'}")
    
    if 'SCIE' in text:
        print("  SCIE: Yes")
    if 'ESCI' in text:
        print("  ESCI: Yes")
    if 'Scopus' in text:
        print("  Scopus: Yes")
    
    apc_match = re.search(r'(?:APC|article processing|publication fee|charge)\s*[:\$]?\s*(?:US)?\s*\$?\s*(\d[\d,]*)', text, re.IGNORECASE)
    if apc_match:
        print(f"  APC: ${apc_match.group(1)}")
    
    if 'review' in text.lower():
        print("  Accepts reviews: Likely YES")
else:
    print(f"  SAGE error: {html[:100]}")
