import urllib.request
import re
import json
import ssl

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

def fetch_url(url, timeout=15):
    req = urllib.request.Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
    })
    resp = urllib.request.urlopen(req, timeout=timeout, context=ctx)
    return resp.read().decode("utf-8", errors="ignore")

# Try fetching from Resurchify or similar sites that aggregate journal metrics
journals_to_check = [
    ("Journal of Medicinal Food", "1096-620X"),
    ("Journal of Natural Products", "0163-3864"),
    ("Natural Product Reports", "0265-0568"),
    ("ACS Medicinal Chemistry Letters", "1948-5875"),
    ("Journal of Medicinal Plants Research", "1996-0875"),
    ("Research in Pharmaceutical Sciences", "1735-5362"),
]

for name, issn in journals_to_check:
    print(f"\n=== {name} ===")
    # Try to fetch from Resurchify
    slug = name.lower().replace(" ", "-").replace(",", "").replace(":", "")
    url = f"https://www.resurchify.com/impact/details/{slug}"
    try:
        html = fetch_url(url, timeout=10)
        # Look for IF, Q ranking, SCIE info
        if_match = re.findall(r"Impact Factor[:\s]*(\d+\.\d+)", html)
        q_match = re.findall(r"Q(\d)", html)
        scie_match = re.findall(r"SCIE|Science Citation Index", html, re.IGNORECASE)
        sjr_match = re.findall(r"SJR[:\s]*(\d+\.\d+)", html)
        print(f"  IF from Resurchify: {if_match[:3]}")
        print(f"  Q: {q_match[:10]}")
        print(f"  SCIE mention: {'Yes' if scie_match else 'No'}")
        print(f"  SJR: {sjr_match[:3]}")
    except Exception as e:
        print(f"  Resurchify: ERROR - {e}")
    
    # Also try to search on another aggregator
    try:
        # Try Scimago via search
        url2 = f"https://www.scimagojr.com/journalsearch.php?q={issn}&tip=jid"
        html2 = fetch_url(url2, timeout=10)
        sjr2 = re.findall(r"SJR\s*</th>\s*<td[^>]*>(\d+\.\d+)", html2)
        q2 = re.findall(r"Q(\d)", html2)
        if_val = re.findall(r"Total Docs\. .*\s*</th>\s*<td[^>]*>(\d+)", html2)
        print(f"  Scimago SJR: {sjr2[:3]}")
        print(f"  Scimago Q: {q2[:10]}")
    except Exception as e:
        print(f"  Scimago: ERROR - {e}")
