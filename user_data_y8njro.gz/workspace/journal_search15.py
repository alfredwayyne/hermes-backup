#!/usr/bin/env python3
"""Final comprehensive search for qualifying journals."""

import urllib.request
import json
import re
import time

def fetch_url(url, timeout=15):
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"
        })
        response = urllib.request.urlopen(req, timeout=timeout)
        return response.read().decode("utf-8", errors="ignore")
    except Exception as e:
        return f"ERROR: {e}"

def get_openalex(name):
    """Get journal data from OpenAlex."""
    try:
        encoded = name.replace(" ", "%20")
        url = f"https://api.openalex.org/sources?search={encoded}&per_page=1"
        req = urllib.request.Request(url, headers={"User-Agent": "JournalSearch/1.0 (mailto:research@example.com)"})
        response = urllib.request.urlopen(req, timeout=15)
        data = json.loads(response.read())
        results = data.get("results", [])
        if results:
            j = results[0]
            return {
                "name": j.get("display_name", "N/A"),
                "issn": j.get("issn_l", "N/A"),
                "oa": j.get("is_oa", False),
                "h_index": j.get("summary_stats", {}).get("h_index", 0),
                "citedness": j.get("summary_stats", {}).get("2yr_mean_citedness", 0),
                "publisher": j.get("host_organization_name", ""),
                "is_in_doaj": j.get("is_in_doaj", False),
            }
    except Exception as e:
        return {"error": str(e)[:100]}
    return None

# Try OpenAlex again for key journals
key_journals = [
    "Current Pharmaceutical Design",
    "Current Cancer Drug Targets",
    "Journal of Natural Medicines",
    "Integrative Cancer Therapies",
    "Pharmacognosy Magazine",
    "South African Journal of Botany",
    "Pharmaceutical Biology",
]

print("Checking OpenAlex data...")
print("=" * 80)

for name in key_journals:
    data = get_openalex(name)
    if data and "error" not in data:
        print(f"\n=== {name} ===")
        print(f"  Matched: {data['name']}")
        print(f"  ISSN: {data['issn']}")
        print(f"  OA: {data['oa']}")
        print(f"  H-index: {data['h_index']}")
        print(f"  2yr citedness: {data['citedness']:.2f}")
        print(f"  Publisher: {data['publisher'][:60]}")
        print(f"  DOAJ: {data['is_in_doaj']}")
    elif data and "error" in data:
        print(f"\n=== {name} === Error: {data['error']}")
    else:
        print(f"\n=== {name} === NOT FOUND")
    
    time.sleep(5)  # Longer delay
