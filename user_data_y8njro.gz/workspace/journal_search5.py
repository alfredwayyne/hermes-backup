#!/usr/bin/env python3
"""Verify specific journals for remaining criteria."""

import urllib.request
import json
import re
import time

def fetch_url(url, timeout=15):
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"
        })
        response = urllib.request.urlopen(req, timeout=timeout)
        return response.read().decode("utf-8", errors="ignore")
    except Exception as e:
        return f"ERROR: {e}"

def get_wikipedia_full(wiki_name):
    """Get full Wikipedia page text for analysis."""
    url = f"https://en.wikipedia.org/wiki/{wiki_name}"
    html = fetch_url(url)
    if html.startswith("ERROR"):
        return None
    
    text = re.sub(r'<[^>]+>', ' ', html)
    text = re.sub(r'&#\d+;', '', text)
    text = re.sub(r'&\w+;', ' ', text)
    text = re.sub(r'\s+', ' ', text)
    return text

# Check Current Pharmaceutical Design thoroughly
print("=== Current Pharmaceutical Design ===")
text = get_wikipedia_full("Current_Pharmaceutical_Design")
if text:
    # Extract key info
    if_match = re.search(r'Impact factor\s+(\d+\.?\d*)', text)
    has_sci = 'SCIE' in text or 'Science Citation Index' in text
    has_esci = 'ESCI' in text or 'Emerging Sources' in text
    has_scopus = 'Scopus' in text
    has_pubmed = 'PubMed' in text
    has_medline = 'MEDLINE' in text
    
    # Look for APC info
    has_apc = 'article processing charge' in text.lower() or 'APC' in text
    has_open_access = 'open access' in text.lower()
    
    print(f"  IF: {if_match.group(1) if if_match else 'N/A'}")
    print(f"  SCIE: {has_sci}")
    print(f"  ESCI: {has_esci}")
    print(f"  Scopus: {has_scopus}")
    print(f"  PubMed: {has_pubmed}")
    print(f"  MEDLINE: {has_medline}")
    print(f"  APC mentioned: {has_apc}")
    print(f"  Open Access: {has_open_access}")
    
    # Extract publisher info
    publisher_match = re.search(r'Publisher\s+([A-Z][^,\.]{3,50})', text)
    if publisher_match:
        print(f"  Publisher: {publisher_match.group(1)}")
    
    # Extract indexing info
    indexing_section = re.search(r'Indexing(.{0,500})', text)
    if indexing_section:
        print(f"  Indexing info: {indexing_section.group(1)[:200]}")
else:
    print("  Wikipedia page not found")

print()

# Check Phytotherapy Research thoroughly
print("=== Phytotherapy Research ===")
text = get_wikipedia_full("Phytotherapy_Research")
if text:
    if_match = re.search(r'Impact factor\s+(\d+\.?\d*)', text)
    has_sci = 'SCIE' in text or 'Science Citation Index' in text
    has_esci = 'ESCI' in text or 'Emerging Sources' in text
    has_scopus = 'Scopus' in text
    
    print(f"  IF: {if_match.group(1) if if_match else 'N/A'}")
    print(f"  SCIE: {has_sci}")
    print(f"  ESCI: {has_esci}")
    print(f"  Scopus: {has_scopus}")
    
    publisher_match = re.search(r'Publisher\s+([A-Z][^,\.]{3,50})', text)
    if publisher_match:
        print(f"  Publisher: {publisher_match.group(1)}")
else:
    print("  Wikipedia page not found")

print()

# Check more journals that might be in range
print("=== Checking additional journals ===")
additional = [
    ("Natural_Product_Communications", "Natural Product Communications"),
    ("Journal_of_Natural_Medicines", "Journal of Natural Medicines"),
    ("Evidence-Based_Complementary_and_Alternative_Medicine", "Evidence-Based Complementary and Alternative Medicine"),
    ("Integrative_Cancer_Therapies", "Integrative Cancer Therapies"),
    ("Journal_of_Cancer_Research_and_Clinical_Oncology", "Journal of Cancer Research and Clinical Oncology"),
    ("Molecular_Medicine_Reports", "Molecular Medicine Reports"),
    ("Oncology_Letters", "Oncology Letters"),
    ("International_Journal_of_Oncology", "International Journal of Oncology"),
    ("Experimental_and_Therapeutic_Medicine", "Experimental and Therapeutic Medicine"),
    ("Acta_Pharmaceutica_Sinica_B", "Acta Pharmaceutica Sinica B"),
    ("Journal_of_Asian_Natural_Products_Research", "Journal of Asian Natural Products Research"),
    ("Zeitschrift_für_Naturforschung_C", "Zeitschrift für Naturforschung C"),
    ("Drug_Discoveries_%26_Therapeutics", "Drug Discoveries & Therapeutics"),
    ("Journal_of_Herbal_Medicine", "Journal of Herbal Medicine"),
    ("Molecules", "Molecules (MDPI)"),
    ("Pharmaceutical_Biology", "Pharmaceutical Biology"),
]

for wiki_name, display_name in additional:
    text = get_wikipedia_full(wiki_name)
    if text:
        if_match = re.search(r'Impact factor\s+(\d+\.?\d*)', text)
        has_sci = 'SCIE' in text or 'Science Citation Index' in text
        has_esci = 'ESCI' in text or 'Emerging Sources' in text
        
        if if_val := (if_match.group(1) if if_match else None):
            try:
                if_float = float(if_val)
                in_range = 2.0 <= if_float <= 3.0
                marker = "✓" if in_range else "✗"
                print(f"  {display_name}: IF={if_val} {marker}, SCIE={has_sci}, ESCI={has_esci}")
            except:
                print(f"  {display_name}: IF={if_val}, SCIE={has_sci}, ESCI={has_esci}")
        else:
            print(f"  {display_name}: IF=N/A, SCIE={has_sci}, ESCI={has_esci}")
    else:
        print(f"  {display_name}: Wikipedia not found")
    
    time.sleep(0.3)
