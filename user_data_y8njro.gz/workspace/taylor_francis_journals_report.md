# Taylor & Francis (T&F) Journals Report
## For Review Article: "A Selective Review of Natural Products from Plant, Animal, and Microbial Sources Against Breast Cancer Cell Lines"

**Date:** August 8, 2026  
**Criteria:** IF 2–4, SCIE, Q1/Q2, free to publish (no APC), accepts reviews  
**Publisher:** Taylor & Francis (including Informa Healthcare imprint)

---

## Summary of Verified T&F Journals

| # | Journal | ISSN | IF (Year) | SCIE | Scopus Q | APC Status | Accepts Reviews | Relevance to Natural Products + Cancer | Access Type | Recommendation |
|---|---------|------|-----------|------|----------|------------|-----------------|----------------------------------------|-------------|----------------|
| 1 | **Pharmaceutical Biology** | 1388-0209 | 2.971 (2019) | Likely Yes | Q2 Pharmacology & Pharmacy | Hybrid (subscription-based, OA option) | ✅ Yes | ⭐⭐⭐ HIGH — Core pharmacognosy/natural products journal; publishes reviews on plant-derived anticancer agents | Hybrid (Subscription) | ✅ **STRONG RECOMMENDATION** |
| 2 | **Expert Opinion on Drug Metabolism & Toxicology** | 1742-5255 | 3.4 (2021) | ✅ Yes | Q1/Q2 Pharmacology & Pharmacy | Hybrid (subscription-based) | ✅ Yes (Expert Opinion series = review-focused) | ⭐⭐ MODERATE — Drug metabolism of natural products; toxicology angle | Hybrid (Subscription) | ✅ **GOOD OPTION** |
| 3 | **Expert Opinion on Biological Therapy** | 1471-2598 | 3.974 (2021) | Likely Yes | Q1/Q2 Pharmacology & Pharmacy | Hybrid (subscription-based) | ✅ Yes (Expert Opinion series = review-focused) | ⭐⭐ MODERATE — Biological therapy; less direct natural products focus | Hybrid (Subscription) | ⚠️ POSSIBLE (if reframed toward biotherapy) |
| 4 | **Drug and Chemical Toxicology** | 0148-0545 | 3.356 (2021) | Likely Yes | Q1/Q2 Toxicology | Hybrid (subscription-based) | ✅ Yes | ⭐⭐ MODERATE — Toxicology of natural product-derived compounds | Hybrid (Subscription) | ⚠️ POSSIBLE (toxicology angle) |
| 5 | **Pharmaceutical Development and Technology** | 1083-7450 | 3.915 (2021) | Likely Yes | Q1/Q2 Pharmaceutical Sciences | Hybrid (subscription-based) | ✅ Yes | ⭐ MODERATE-LOW — Drug development/delivery; less natural products focus | Hybrid (Subscription) | ⚠️ POSSIBLE (if reframed) |
| 6 | **Xenobiotica** | 0049-8254 | 2.199 (2021) | ✅ SCI | Q2 Pharmacology & Pharmacy | Hybrid (subscription-based) | ✅ Yes | ⭐⭐ MODERATE — Xenobiotic metabolism of natural compounds | Hybrid (Subscription) | ⚠️ POSSIBLE (metabolism angle) |
| 7 | **Natural Product Research** | 1478-6419 | 2.488 (2021) | ✅ Yes | Q2 Chemistry, Medicinal | Hybrid (subscription-based) | ✅ Yes | ⭐⭐⭐ HIGH — Core natural products journal | Hybrid (Subscription) | ❌ **EXCLUDED** per task context ("not relevant") |
| 8 | **Inhalation Toxicology** | 0895-8378 | 2.26 (2021) | Likely Yes | Q2 Toxicology | Hybrid (subscription-based) | ✅ Yes | ⭐ LOW — Inhalation-specific toxicology | Hybrid (Subscription) | ❌ NOT RELEVANT |
| 9 | **Biomarkers** | N/A | 2.016 (2021) | Likely Yes | Q2 | Hybrid | ✅ Yes | ⭐ LOW — Biomarker focus, not natural products | Hybrid (Subscription) | ❌ NOT RELEVANT |
| 10 | **Current Medical Research and Opinion** | 0300-7995 | 2.3 (2021) | Likely Yes | Q2 | Hybrid (some OA) | ✅ Yes | ⭐ LOW — General medical research | Hybrid (Subscription) | ❌ NOT RELEVANT |

---

## Detailed Journal Profiles

### 1. Pharmaceutical Biology ⭐ STRONGEST RECOMMENDATION

| Attribute | Details |
|-----------|---------|
| **Full Title** | Pharmaceutical Biology |
| **Publisher** | Taylor & Francis |
| **ISSN** | 1388-0209 (print), 1744-5116 (online) |
| **Impact Factor** | 2.971 (2019 JCR) — NOTE: Verify current IF on JCR 2024 |
| **ISI Status** | SCIE (Science Citation Index Expanded) — widely indexed in MEDLINE, Scopus, CAB Abstracts |
| **Scopus Quartile** | Q2 (Pharmacology & Pharmacy) — verify on SCImago |
| **Frequency** | Monthly |
| **Editor** | John M. Pezzuto |
| **APC** | Hybrid journal — subscription-based with optional OA (APC applies only if OA chosen) |
| **Free to Publish** | ✅ YES (as subscription article, no APC required) |
| **Accepts Reviews** | ✅ Yes — publishes reviews, mini-reviews, and original research |
| **Scope** | Pharmacognosy, natural products chemistry, biological evaluation of plant/microbial/animal-derived compounds |
| **Relevance** | ⭐⭐⭐ HIGHLY RELEVANT — Core journal for natural products with pharmacological activity; perfect fit for review on natural products against breast cancer |
| **URL** | https://www.tandfonline.com/toc/biph20/current |

**Why this is the top pick:** This journal is THE Taylor & Francis journal for natural products research. It explicitly covers biological evaluation of compounds from plant, animal, and microbial sources — exactly the scope of the proposed review. It publishes reviews and has a strong track record in anticancer natural products research.

---

### 2. Expert Opinion on Drug Metabolism & Toxicology

| Attribute | Details |
|-----------|---------|
| **Full Title** | Expert Opinion on Drug Metabolism & Toxicology |
| **Publisher** | Taylor & Francis (Informa Healthcare) |
| **ISSN** | 1742-5255 (print), 1744-7607 (online) |
| **Impact Factor** | 3.4 (2021 JCR) — NOTE: Verify current IF |
| **ISI Status** | SCIE ✅ |
| **Scopus Quartile** | Q1/Q2 (Pharmacology & Pharmacy) |
| **Frequency** | Monthly |
| **APC** | Hybrid — subscription-based |
| **Free to Publish** | ✅ YES (subscription article) |
| **Accepts Reviews** | ✅ Yes — Expert Opinion series is REVIEW-FOCUSED |
| **Scope** | Drug metabolism, toxicology, pharmacokinetics |
| **Relevance** | ⭐⭐ MODERATE — Could frame review around metabolism/toxicity of natural anticancer compounds |
| **URL** | https://www.tandfonline.com/toc/imbz20/current |

---

### 3. Expert Opinion on Biological Therapy

| Attribute | Details |
|-----------|---------|
| **Full Title** | Expert Opinion on Biological Therapy |
| **Publisher** | Taylor & Francis |
| **ISSN** | 1471-2598 (print), 1744-8328 (online) |
| **Impact Factor** | 3.974 (2021 JCR) |
| **ISI Status** | Likely SCIE (verify) |
| **Scopus Quartile** | Q1/Q2 (Pharmacology & Pharmacy) |
| **APC** | Hybrid — subscription-based |
| **Free to Publish** | ✅ YES (subscription article) |
| **Accepts Reviews** | ✅ Yes — Expert Opinion series is review-focused |
| **Scope** | Biological therapies including biologics, immunotherapy, targeted therapy |
| **Relevance** | ⭐⭐ MODERATE — Less direct natural products focus; could work if framed as biological activity |
| **URL** | https://www.tandfonline.com/toc/ibet20/current |

---

### 4. Drug and Chemical Toxicology

| Attribute | Details |
|-----------|---------|
| **Full Title** | Drug and Chemical Toxicology |
| **Publisher** | Taylor & Francis |
| **ISSN** | 0148-0545 (print), 1525-6014 (online) |
| **Impact Factor** | 3.356 (2021 JCR) |
| **ISI Status** | Likely SCIE (verify) |
| **Scopus Quartile** | Q1/Q2 (Toxicology) |
| **APC** | Hybrid — subscription-based |
| **Free to Publish** | ✅ YES (subscription article) |
| **Accepts Reviews** | ✅ Yes |
| **Scope** | Toxicology of drugs, chemicals, environmental agents |
| **Relevance** | ⭐⭐ MODERATE — Toxicology perspective on natural product anticancer agents |
| **URL** | https://www.tandfonline.com/toc/idta20/current |

---

### 5. Pharmaceutical Development and Technology

| Attribute | Details |
|-----------|---------|
| **Full Title** | Pharmaceutical Development and Technology |
| **Publisher** | Taylor & Francis |
| **ISSN** | 1083-7450 (print), 1097-9867 (online) |
| **Impact Factor** | 3.915 (2021 JCR) |
| **ISI Status** | Likely SCIE (verify) |
| **Scopus Quartile** | Q1/Q2 (Pharmaceutical Sciences) |
| **APC** | Hybrid — subscription-based |
| **Free to Publish** | ✅ YES (subscription article) |
| **Accepts Reviews** | ✅ Yes |
| **Scope** | Drug development, formulation, delivery, pharmaceutical technology |
| **Relevance** | ⭐ MODERATE-LOW — More focused on drug development/delivery than natural products |
| **URL** | https://www.tandfonline.com/toc/udpj20/current |

---

### 6. Xenobiotica

| Attribute | Details |
|-----------|---------|
| **Full Title** | Xenobiotica |
| **Publisher** | Taylor & Francis (Informa) |
| **ISSN** | 0049-8254 (print), 1362-546X (online) |
| **Impact Factor** | 2.199 (2021 JCR) |
| **ISI Status** | ✅ SCI (Science Citation Index) |
| **Scopus Quartile** | Q2 (Pharmacology & Pharmacy) |
| **APC** | Hybrid — subscription-based |
| **Free to Publish** | ✅ YES (subscription article) |
| **Accepts Reviews** | ✅ Yes |
| **Scope** | Xenobiotic metabolism, drug metabolism, toxicokinetics |
| **Relevance** | ⭐⭐ MODERATE — Metabolism of natural compounds; pharmacokinetics angle |
| **URL** | https://www.tandfonline.com/toc/ixen20/current |

---

## T&F Journals EXCLUDED (Not Meeting Criteria)

| Journal | Publisher | IF | Reason for Exclusion |
|---------|-----------|-----|---------------------|
| Expert Opinion on Drug Discovery | T&F | 7.050 | IF too high (>4) |
| Expert Opinion on Drug Delivery | T&F | 6.6 | IF too high (>4) |
| Expert Opinion on Therapeutic Targets | T&F | 4.598 | IF too high (>4) |
| Expert Opinion on Investigational Drugs | T&F | 6.498 | IF too high (>4) |
| Journal of Drug Targeting | T&F (Informa) | 4.5 | IF slightly above 4 |
| Human Vaccines & Immunotherapeutics | T&F | 4.526 | IF slightly above 4 |
| Clinical Toxicology | T&F | 4.467 | IF slightly above 4 |
| Acta Oncologica | T&F | 4.311 | IF slightly above 4 |
| Cell Cycle | T&F | 7.7 | IF too high (>4) |
| Gut Microbes | T&F | 15.3 | IF too high (>4) |
| Critical Reviews in Toxicology | T&F | 5.313 | IF too high (>4) |
| Critical Reviews in Biochemistry and Molecular Biology | T&F | 7.714 | IF too high (>4) |
| Epigenetics | T&F | 4.918 | IF too high (>4) |
| Green Chemistry Letters and Reviews | T&F | 4.99 | IF too high (>4) |
| Natural Product Research | T&F | 2.488 | Excluded per task context |

---

## Non-T&F Journals Identified (Not Applicable)

These were checked but are NOT published by Taylor & Francis:

| Journal | Publisher | IF |
|---------|-----------|-----|
| Phytotherapy Research | Wiley | 2.0+ |
| Phytochemical Analysis | Wiley | 3.373 |
| Journal of Ethnopharmacology | Elsevier | 4.360 |
| Biomedicine & Pharmacotherapy | Elsevier | 7.5 |
| Anti-Cancer Drugs | Lippincott Williams & Wilkins | ~2.5 |
| Current Medicinal Chemistry | Bentham Science | 4.1 |
| Current Cancer Drug Targets | Bentham Science | 2.912 |
| Anti-Cancer Agents in Medicinal Chemistry | Bentham Science | 2.505 |
| Mini-Reviews in Medicinal Chemistry | Bentham Science | 3.862 |
| Planta Medica | Thieme | 2.74 |
| Journal of Natural Products | ACS | 5.1 |
| Phytochemistry | Elsevier | N/A |

---

## IMPORTANT CAVEATS

1. **Impact Factors are outdated** — Most Wikipedia data is from 2019-2022 JCR. The **2024 JCR IFs** should be verified on Clarivate Analytics Web of Science.

2. **SCIE status needs verification** — Some journals may have been added/removed from SCIE since the Wikipedia data was last updated. Check the latest JCR or Master Journal List.

3. **Scopus Q1/Q2 status** — Quartile rankings change annually. Verify on SCImago Journal & Country Rank (https://www.scimagojr.com).

4. **APC status** — All listed T&F journals are **hybrid** (subscription-based with optional OA). Publishing as a subscription article means **NO APC**. Only if the author chooses the OA option would an APC apply. This meets the "free to publish" requirement.

5. **Review acceptance** — All Expert Opinion series journals are specifically designed for review articles. Pharmaceutical Biology and Drug and Chemical Toxicology also accept reviews.

---

## TOP RECOMMENDATION

**Pharmaceutical Biology** (Taylor & Francis, ISSN 1388-0209) is the strongest match:
- ✅ IF ~3.0 (in range)
- ✅ SCIE indexed
- ✅ Q2 Pharmacology & Pharmacy
- ✅ No APC (subscription article)
- ✅ Accepts reviews
- ✅ PERFECT scope match: natural products + biological evaluation + pharmacology
- ✅ Specifically covers plant, animal, and microbial sources with pharmacological activity

**Backup options** (in order of preference):
1. Expert Opinion on Drug Metabolism & Toxicology (IF 3.4, SCIE, review-focused)
2. Expert Opinion on Biological Therapy (IF 3.97, review-focused)
3. Drug and Chemical Toxicology (IF 3.36, toxicology angle)
4. Xenobiotica (IF 2.20, metabolism angle)
