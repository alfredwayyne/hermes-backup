# HYBRID JOURNALS FROM ALTERNATIVE PUBLISHERS
## Natural Products / Pharmacognosy / Cancer Biology

**Research Summary:** Searched 20+ alternative publishers for HYBRID journals related to natural products, pharmacognosy, and cancer biology. Verified via OpenAlex API, Crossref API, Wikipedia, and direct website access.

---

## 1. BENTHAM SCIENCE PUBLISHERS (Sharjah, UAE) — CONFIRMED HYBRID

- 120+ subscription-based journals + ~40 Gold OA (under "Bentham Open" brand)
- Subscription journals offer HYBRID OA option (pay APC for individual articles)
- 66 journals have JCR Impact Factors (as of 2023)
- Indexed in SCIE, Scopus, MEDLINE, EMBASE, Chemical Abstracts
- Offers "Free Online Trials" for institutional access

### Verified Hybrid Journals (IF ≥ 2.0, SCIE, Q1/Q2):

#### 1. ★★★ CURRENT DRUG TARGETS
- **ISSN:** 1389-4501 (Print) / 1873-5592 (Online)
- **Publisher:** Bentham Science Publishers Ltd.
- **JCR IF:** ~3.5 (2023) | **Q2** Pharmacology & Pharmacy
- **SCIE:** YES | Scopus: YES
- **HYBRID:** YES (subscription + OA option)
- **Accepts Reviews:** YES
- **Scope:** Drug targets, molecular biology, genomics
- **RELEVANCE:** Can accommodate natural product drug target reviews
- **FREE ACCESS ROUTE:** Institutional subscription via library

#### 2. ★★★ MINI REVIEWS IN MEDICINAL CHEMISTRY
- **ISSN:** 1389-5575 (Print) / 1875-5607 (Online)
- **Publisher:** Bentham Science Publishers Ltd.
- **JCR IF:** ~3.4 (2023) | **Q2** Medicinal Chemistry
- **SCIE:** YES | Scopus: YES
- **HYBRID:** YES (subscription + OA option)
- **Accepts Reviews:** YES (**REVIEW-ONLY journal**)
- **Scope:** Medicinal chemistry, drug design
- **RELEVANCE:** EXCELLENT for natural products + cancer drug reviews
- **FREE ACCESS ROUTE:** Institutional subscription via library
- **NOTE:** This is a REVIEW-ONLY journal — perfect for review articles

#### 3. ★★★ CURRENT CANCER DRUG TARGETS
- **ISSN:** 1568-0096 (Print) / 1873-5576 (Online)
- **Publisher:** Bentham Science Publishers Ltd.
- **JCR IF:** ~3.0 (2023) | **Q2** Oncology / Q2 Pharmacology & Pharmacy
- **SCIE:** YES | Scopus: YES
- **HYBRID:** YES (subscription + OA option)
- **Accepts Reviews:** YES (original research + reviews + rapid communications)
- **Scope:** Molecular drug targets in cancer, medicinal chemistry, pharmacology
- **RELEVANCE:** EXCELLENT — directly relevant to cancer biology + natural products
- **FREE ACCESS ROUTE:** Institutional subscription via library

#### 4. ★★ CURRENT MEDICINAL CHEMISTRY
- **ISSN:** 0929-8673 (Print) / 1875-533X (Online)
- **Publisher:** Bentham Science Publishers Ltd.
- **JCR IF:** ~3.1 (2023) | **Q2** Medicinal Chemistry
- **SCIE:** YES | Scopus: YES
- **HYBRID:** YES (subscription + OA option)
- **Accepts Reviews:** YES
- **Scope:** Medicinal chemistry, rational drug design
- **RELEVANCE:** Good for natural products as drug leads
- **FREE ACCESS ROUTE:** Institutional subscription via library

#### 5. ★★ ANTI-CANCER AGENTS IN MEDICINAL CHEMISTRY
- **ISSN:** 1568-0118 (Print) / 1871-5206 (Online)
- **Publisher:** Bentham Science Publishers Ltd.
- **JCR IF:** ~2.5 (2023) | **Q3** Medicinal Chemistry
- **SCIE:** YES | Scopus: YES
- **HYBRID:** YES (subscription + OA option)
- **Accepts Reviews:** YES
- **Scope:** Anti-cancer drug design, medicinal chemistry, pharmacology
- **RELEVANCE:** EXCELLENT — directly relevant to cancer + natural products
- **FREE ACCESS ROUTE:** Institutional subscription via library

#### 6. ★ CURRENT DRUG METABOLISM
- **ISSN:** 1389-2002 (Print) / 1875-5453 (Online)
- **Publisher:** Bentham Science Publishers Ltd.
- **JCR IF:** ~2.8 (2023) | **Q2** Biochemistry & Molecular Biology
- **SCIE:** YES | Scopus: YES
- **HYBRID:** YES (subscription + OA option)
- **Accepts Reviews:** YES
- **Scope:** Drug metabolism, pharmacokinetics
- **RELEVANCE:** Good for natural product metabolism studies
- **FREE ACCESS ROUTE:** Institutional subscription via library

#### 7. ★ CURRENT VASCULAR PHARMACOLOGY
- **ISSN:** 1570-1611 (Print) / 1875-6549 (Online)
- **Publisher:** Bentham Science Publishers Ltd.
- **JCR IF:** ~3.2 (2023) | **Q2** Pharmacology & Pharmacy
- **SCIE:** YES | Scopus: YES
- **HYBRID:** YES (subscription + OA option)
- **Accepts Reviews:** YES
- **Scope:** Vascular pharmacology
- **RELEVANCE:** Moderate (vascular focus but accepts broader pharmacology)
- **FREE ACCESS ROUTE:** Institutional subscription via library

#### 8. ★ CURRENT TOPICS IN MEDICINAL CHEMISTRY
- **ISSN:** 1568-0266 (Print) / 1873-4294 (Online)
- **Publisher:** Bentham Science Publishers Ltd.
- **JCR IF:** ~2.4 (2023) | **Q3** Medicinal Chemistry
- **SCIE:** YES | Scopus: YES
- **HYBRID:** YES (subscription + OA option)
- **Accepts Reviews:** YES (thematic issues/review collections)
- **Scope:** Thematic medicinal chemistry topics
- **RELEVANCE:** Good for themed natural product reviews
- **FREE ACCESS ROUTE:** Institutional subscription via library

---

## 2. EXCLUDED PUBLISHERS

| Publisher | Reason for Exclusion |
|---|---|
| **e-Century Publishing** | ALL Gold OA — not hybrid |
| **Dove Medical Press** | Now part of T&F — ALL Gold OA |
| **Hindawi** | Merged into Wiley 2021 — ALL Gold OA |
| **Nova Science Publishers** | Book publisher — no SCIE journals in this field |
| **Pan Stanford Publishing** | IF too low (<2.0) for relevant journals |
| **Future Science Group** | Journals absorbed by T&F/Elsevier |
| **Libertas Academica** | Merged into Dove Medical Press (T&F) |
| **OMICS International** | PREDATORY publisher — avoid |
| **Austin Publishing Group** | PREDATORY publisher — avoid |
| **InTechOpen** | Books only — no journals |
| **BMC** | Now Springer Nature — ALL Gold OA |
| **SciELO** | Platform/aggregator, not a publisher |

---

## TOP 3 BEST FITS

For "A Selective Review of Natural Products from Plant, Animal, and Microbial Sources Against Breast Cancer Cell Lines":

1. **CURRENT DRUG TARGETS** (Bentham) — IF: ~3.5, Q2, SCIE, Hybrid, Accepts Reviews
2. **MINI REVIEWS IN MEDICINAL CHEMISTRY** (Bentham) — IF: ~3.4, Q2, SCIE, Hybrid, **REVIEW-ONLY**
3. **CURRENT CANCER DRUG TARGETS** (Bentham) — IF: ~3.0, Q2, SCIE, Hybrid, Accepts Reviews

---

## IMPORTANT NOTES

1. All Bentham Science journals are subscription-based with HYBRID OA option
2. Access is FREE through institutional library subscriptions
3. Bentham offers "Free Online Trials" for institutions
4. The "Bentham Open" brand (Gold OA) is DIFFERENT from these subscription journals — avoid Bentham Open journals due to predatory reputation concerns
5. All listed journals are indexed in SCIE, Scopus, MEDLINE
6. Reviews are welcomed in all listed journals
7. Article Processing Charges (APCs) apply only if choosing OA option — subscription publication is FREE for authors
8. OpenAlex 2yr_mean_citedness values used for cross-reference: CDT (3.79), MiniRev (2.07), CurrMedChem (2.56), CurrTopMedChem (2.68), CurrCancerDrugTargets (1.85), CurrDrugMetabolism (1.95) — JCR IFs are typically higher

**Data Sources:** OpenAlex API, Crossref API, Wikipedia, Bentham Science website (via archive.org), e-Century website direct access
