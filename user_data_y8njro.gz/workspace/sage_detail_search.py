from ddgs import DDGS
import json

ddgs = DDGS()

# Detailed searches for specific journals
searches = [
    "SAGE Open Medicine impact factor 2024 SCIE SCOPUS",
    "Journal of Medicinal Food SAGE impact factor 2024",
    "Perspectives in Medicinal Chemistry SAGE impact factor",
    "Journal of Integrative Complementary Medicine SAGE impact factor",
    "Tumor Biology SAGE impact factor 2024 SCIE",
    "Cancer Informatics SAGE impact factor",
    "Journal of Current Oncology SAGE impact factor",
    "SAGE Open Medicine APC free publication review articles",
    "Journal of Medicinal Food SCIE indexing APC",
    "Tumor Biology SAGE APC free open access",
    "Journal of Herbal Pharmacotherapy Taylor Francis SAGE",
    "SAGE journals list without APC pharmacology medicine",
    "SAGE Open Medicine accepts review articles scope",
    "Tumor Biology SAGE journal scope natural products",
    "SAGE journals IF 2-4 pharmacology cancer SCIE 2024"
]

for q in searches:
    try:
        results = ddgs.text(q, max_results=5)
        print(f"\n===== {q} =====")
        for r in results:
            print(f"  Title: {r['title']}")
            print(f"  URL: {r['href'][:150]}")
            print(f"  Body: {r['body'][:300]}")
            print()
    except Exception as e:
        print(f"ERROR for '{q}': {e}")
