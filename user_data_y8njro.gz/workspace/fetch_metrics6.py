import urllib.request
import re
import json
import ssl

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

def fetch_url(url, timeout=15):
    req = urllib.request.Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
    })
    resp = urllib.request.urlopen(req, timeout=timeout, context=ctx)
    return resp.read().decode("utf-8", errors="ignore")

# Try to fetch from LetPub with proper journal IDs
# LetPub uses journal IDs like "journalapp/view/detail/journalid/XXXX"
# Let me try to search for the journal ID first

journals = [
    ("Journal of Medicinal Food", "1096-620X"),
    ("Journal of Natural Products", "0163-3864"),
    ("Natural Product Reports", "0265-0568"),
    ("ACS Medicinal Chemistry Letters", "1948-5875"),
    ("Journal of Medicinal Plants Research", "1996-0875"),
    ("Research in Pharmaceutical Sciences", "1735-5362"),
]

for name, issn in journals:
    print(f"\n=== {name} ===")
    
    # Try LetPub search with ISSN
    url = f"https://www.letpub.com.cn/index.php?page=journalapp&view=search&search_field=issn&searchname={issn}"
    try:
        html = fetch_url(url, timeout=15)
        
        # Find the journal detail link
        detail_links = re.findall(r'href="(/index\.php\?page=journalapp[^"]*)"', html)
        print(f"  Detail links: {detail_links[:3]}")
        
        if detail_links:
            # Fetch the first detail link
            detail_url = f"https://www.letpub.com.cn{detail_links[0]}"
            detail_html = fetch_url(detail_url, timeout=15)
            detail_text = re.sub(r'<[^>]+>', ' ', detail_html)
            detail_text = re.sub(r'\s+', ' ', detail_text)
            
            # Look for IF, Q, SCIE info
            if_match = re.findall(r"IF[：:]\s*(\d+\.\d+)", detail_text)
            q_match = re.findall(r"中科院.*?[Qq](\d)", detail_text)
            scie_match = re.findall(r"SCI[CE]|Science Citation Index", detail_text, re.IGNORECASE)
            
            print(f"  Detail IF: {if_match[:5]}")
            print(f"  Detail Q: {q_match[:10]}")
            print(f"  Detail SCIE: {'Yes' if scie_match else 'No'}")
            
            # Look for specific patterns
            if_patterns = re.findall(r"(\d+\.\d+)\s*(?:\(|（)", detail_text)
            print(f"  Detail numbers with parens: {if_patterns[:5]}")
            
    except Exception as e:
        print(f"  LetPub: ERROR - {e}")
