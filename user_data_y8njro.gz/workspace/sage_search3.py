from ddgs import DDGS
import json

ddgs = DDGS()

# More targeted searches for specific journals
searches = [
    '"Tumor Biology" SAGE impact factor SCIE 2024',
    '"SAGE Open Medicine" impact factor SCOPUS Q2',
    '"Journal of Medicinal Food" impact factor 2024 Mary Ann Liebert SAGE',
    '"Cancer Informatics" SAGE impact factor SCIE indexing',
    '"Perspectives in Medicinal Chemistry" SAGE impact factor',
    '"Journal of Current Oncology" impact factor SCIE',
    '"Journal of Integrative and Complementary Medicine" SAGE impact factor',
    '"Journal of Herbal Pharmacotherapy" discontinued',
    'SAGE journals SCIE Q1 Q2 pharmacology cancer free APC 2024',
    'SAGE Open Medicine SCIE indexing impact factor',
    'Tumor Biology SAGE open access APC',
    '"Journal of Pharmacology and Pharmacotherapeutics" SAGE impact factor',
    'SAGE experimental biology medicine impact factor',
    '"Experimental Biology and Medicine" SAGE impact factor',
    'SAGE natural products cancer review journal'
]

for q in searches:
    try:
        results = ddgs.text(q, max_results=4)
        print(f"\n===== {q} =====")
        for r in results:
            print(f"  Title: {r['title']}")
            print(f"  Body: {r['body'][:250]}")
            print()
    except Exception as e:
        print(f"ERROR for '{q}': {e}")
