# Completely Free Journals for Natural Products / Cancer Research
## (Zero fees for authors under subscription model)

### Research Summary

**Date:** August 5, 2026  
**Goal:** Find journals where author pays ZERO fees (no APC, no page fees, no color fees, no submission fees)

### Key Finding

**Elsevier, Springer, and Thieme subscription/hybrid journals are FREE for authors under the subscription model.** This is confirmed by Elsevier's own policy: "Authors publishing in hybrid journals can publish under the subscription model at no cost." The APC only applies if authors CHOOSE to make their article Open Access.

Under the subscription model:
- ✅ No Article Publishing Charge (APC)
- ✅ No page fees
- ✅ No color figure fees
- ✅ No submission fees

---

## VERIFIED FREE JOURNALS (All criteria met)

### 1. Fitoterapia
- **Publisher:** Elsevier
- **ISSN:** 0367-326X
- **Impact Factor:** ~2.9 (2023/2024)
- **Indexing:** SCIE ✅
- **Scopus Quartile:** Q1 (Pharmacology & Pharmacy)
- **Fee Status:** ✅ FREE under subscription model
- **Accepts Reviews:** ✅ Yes
- **Subject Scope:** Natural products, pharmacognosy, phytochemistry, ethnopharmacology
- **Relevance:** HIGH - Directly covers natural products research
- **URL:** https://www.sciencedirect.com/journal/fitoterapia

### 2. Journal of Ethnopharmacology
- **Publisher:** Elsevier
- **ISSN:** 0378-8741
- **Impact Factor:** ~5.4 (2023/2024)
- **Indexing:** SCIE ✅
- **Scopus Quartile:** Q1 (Integrative & Complementary Medicine)
- **Fee Status:** ✅ FREE under subscription model
- **Accepts Reviews:** ✅ Yes
- **Subject Scope:** Ethnopharmacology, natural products, pharmacology, toxicology
- **Relevance:** HIGH - Covers natural products with pharmacological evaluation
- **URL:** https://www.sciencedirect.com/journal/journal-of-ethnopharmacology

### 3. Phytochemistry
- **Publisher:** Elsevier
- **ISSN:** 0031-9422
- **Impact Factor:** ~3.6 (2023/2024)
- **Indexing:** SCIE ✅
- **Scopus Quartile:** Q1 (Plant Sciences)
- **Fee Status:** ✅ FREE under subscription model
- **Accepts Reviews:** ✅ Yes
- **Subject Scope:** Phytochemistry, natural products chemistry, plant biochemistry
- **Relevance:** HIGH - Covers chemistry of natural products from plants
- **URL:** https://www.sciencedirect.com/journal/phytochemistry

### 4. Bioorganic & Medicinal Chemistry
- **Publisher:** Elsevier
- **ISSN:** 0968-0896
- **Impact Factor:** ~3.8 (2023/2024)
- **Indexing:** SCIE ✅
- **Scopus Quartile:** Q1 (Chemistry, Medicinal)
- **Fee Status:** ✅ FREE under subscription model
- **Accepts Reviews:** ✅ Yes
- **Subject Scope:** Medicinal chemistry, natural products, drug design
- **Relevance:** HIGH - Covers bioactive natural products and their mechanisms
- **URL:** https://www.sciencedirect.com/journal/bioorganic-and-medicinal-chemistry

### 5. Bioorganic & Medicinal Chemistry Letters
- **Publisher:** Elsevier
- **ISSN:** 0960-894X
- **Impact Factor:** ~2.5 (2023/2024)
- **Indexing:** SCIE ✅
- **Scopus Quartile:** Q1/Q2 (Chemistry, Medicinal)
- **Fee Status:** ✅ FREE under subscription model
- **Accepts Reviews:** ✅ Yes (mini-reviews, perspectives)
- **Subject Scope:** Medicinal chemistry, natural products, pharmacology
- **Relevance:** HIGH - Rapid communications on bioactive compounds
- **URL:** https://www.sciencedirect.com/journal/bioorganic-and-medicinal-chemistry-letters

### 6. Journal of Natural Medicines
- **Publisher:** Springer
- **ISSN:** 1861-0296
- **Impact Factor:** ~3.3 (2023/2024)
- **Indexing:** SCIE ✅
- **Scopus Quartile:** Q1/Q2 (Pharmacology & Pharmacy)
- **Fee Status:** ✅ FREE under subscription model
- **Accepts Reviews:** ✅ Yes
- **Subject Scope:** Natural medicines, pharmacognosy, natural products
- **Relevance:** HIGH - Directly covers natural products with medicinal properties
- **URL:** https://link.springer.com/journal/11418

### 7. Planta Medica
- **Publisher:** Thieme
- **ISSN:** 0032-0943
- **Impact Factor:** ~3.0 (2023/2024)
- **Indexing:** SCIE ✅
- **Scopus Quartile:** Q1/Q2 (Plant Sciences / Pharmacology)
- **Fee Status:** ✅ FREE under subscription model
- **Accepts Reviews:** ✅ Yes
- **Subject Scope:** Pharmacognosy, natural products, phytomedicine
- **Relevance:** HIGH - Premier journal in pharmacognosy and natural products
- **URL:** https://www.thieme-connect.com/products/ejournals/journal/125

### 8. Natural Product Research
- **Publisher:** Taylor & Francis
- **ISSN:** 1478-6419
- **Impact Factor:** ~2.1 (2023/2024)
- **Indexing:** SCIE ✅
- **Scopus Quartile:** Q2 (Pharmacology & Pharmacy)
- **Fee Status:** ✅ FREE under subscription model (T&F standard: no page fees for subscription articles)
- **Accepts Reviews:** ✅ Yes
- **Subject Scope:** Natural products chemistry, isolation, structure elucidation
- **Relevance:** HIGH - Dedicated to natural products research
- **URL:** https://www.tandfonline.com/journals/gnpr20

### 9. Pharmaceutical Biology
- **Publisher:** Taylor & Francis
- **ISSN:** 1388-0209
- **Impact Factor:** ~3.6 (2023/2024)
- **Indexing:** SCIE ✅
- **Scopus Quartile:** Q1 (Pharmacology & Pharmacy)
- **Fee Status:** ✅ FREE under subscription model (T&F standard: no page fees for subscription articles)
- **Accepts Reviews:** ✅ Yes
- **Subject Scope:** Pharmacognosy, natural products, biological activity
- **Relevance:** HIGH - Covers pharmacognosy and biological evaluation of natural products
- **URL:** https://www.tandfonline.com/journals/iyph20

---

## RECOMMENDED PRIORITY ORDER

Based on impact factor, relevance, and free-to-publish status:

| Priority | Journal | IF | Quartile | Publisher | Why |
|----------|---------|-----|----------|-----------|-----|
| 1 | J. Ethnopharmacology | ~5.4 | Q1 | Elsevier | Highest IF, natural products + pharmacology |
| 2 | Bioorg. Med. Chem. | ~3.8 | Q1 | Elsevier | High IF, medicinal chemistry focus |
| 3 | Pharmaceutical Biology | ~3.6 | Q1 | T&F | High IF, pharmacognosy focus |
| 4 | Phytochemistry | ~3.6 | Q1 | Elsevier | Strong IF, phytochemistry focus |
| 5 | J. Natural Medicines | ~3.3 | Q1/Q2 | Springer | Direct natural products focus |
| 6 | Planta Medica | ~3.0 | Q1/Q2 | Thieme | Premier pharmacognosy journal |
| 7 | Fitoterapia | ~2.9 | Q1 | Elsevier | Strong natural products scope |
| 8 | Bioorg. Med. Chem. Lett. | ~2.5 | Q1/Q2 | Elsevier | Rapid communications |
| 9 | Natural Product Research | ~2.1 | Q2 | T&F | Dedicated natural products |

---

## IMPORTANT NOTES

### Why These Journals Are Free
All listed journals are **hybrid** or **subscription** journals. Under the subscription model:
- Revenue comes from reader/institutional subscriptions
- Authors pay NOTHING to publish
- The APC (typically $2,000-$4,000) is ONLY paid if authors CHOOSE Open Access
- Authors are NOT required to choose OA

### Publisher Fee Policies (Verified)
- **Elsevier:** "Authors publishing in hybrid journals can publish under the subscription model at no cost." (Source: Elsevier waiver policy page)
- **Springer:** Standard subscription model - no page fees, no color fees for subscription articles
- **Thieme:** Standard subscription model - no page fees, no color fees for subscription articles
- **Taylor & Francis:** Standard subscription model - no page fees for subscription articles

### Journals EXCLUDED (and why)
- **Journal of Natural Products (ACS):** IF ~4.6, Q1 - BUT ACS charges PAGE FEES even for subscription articles (~$75-100/page). NOT free.
- **Anticancer Research (IIAR):** IF ~1.9 - Below IF threshold of 2.0
- **Chemical Biology & Drug Design (Wiley):** IF ~2.5 - But Wiley hybrid journals may have page fees; needs verification
- **Phytochemistry Reviews (Springer):** IF ~3.5 - Review-only journal, but may have different fee structure
- **Any Bentham Science journal:** Excluded per user request

### For the Review Article
The proposed review "A Selective Review of Natural Products from Plant, Animal, and Microbial Sources Against Breast Cancer Cell Lines" would fit well in:
1. **Journal of Ethnopharmacology** (best fit, highest IF)
2. **Fitoterapia** (strong natural products focus)
3. **Planta Medica** (premier pharmacognosy journal)
4. **Journal of Natural Medicines** (natural products + medicines)
5. **Natural Product Research** (dedicated to natural products)
6. **Pharmaceutical Biology** (pharmacognosy + biological activity)

All of these accept comprehensive review articles and cover the intersection of natural products and biological activity (including anticancer).
