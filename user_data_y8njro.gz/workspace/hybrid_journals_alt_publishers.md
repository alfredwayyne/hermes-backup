# HYBRID Journals from Alternative Publishers
## For Natural Products + Breast Cancer Review

---

## 1. BENTHAM SCIENCE JOURNALS

| # | Journal | JCR IF (2023) | SCIE | Scopus Q | Hybrid | Free Sub Route | Accepts Reviews | Relevant Scope | Notes |
|---|---------|---------------|------|----------|--------|----------------|-----------------|----------------|-------|
| 1 | **Current Drug Targets** | 3.79 | ✅ Yes | Q1 | ✅ Yes | ✅ Institutional/free via Bentham site | ✅ Yes (invited + submitted) | Drug targets, molecular pharmacology | Best Bentham IF; strong for target-based natural product reviews |
| 2 | **Current Pharmaceutical Design** | 2.69 | ✅ Yes | Q2 | ✅ Yes | ✅ Institutional/free via Bentham site | ✅ Yes | Drug design, pharmaceutical sciences | Good for NP drug design reviews |
| 3 | **Current Medicinal Chemistry** | 2.56 | ✅ Yes | Q2 | ✅ Yes | ✅ Institutional/free via Bentham site | ✅ Yes | Medicinal chemistry, drug discovery | Broad; accepts NP + cancer reviews |
| 4 | **Mini-Reviews in Medicinal Chemistry** | 2.07 | ✅ Yes | Q2 | ✅ Yes | ✅ Institutional/free via Bentham site | ✅ Yes (REVIEW-ONLY journal) | Short review articles in medicinal chemistry | PERFECT for review; designed for concise reviews |
| 5 | **Current Cancer Drug Targets** | 1.85 | ✅ Yes | Q3 | ✅ Yes | ✅ Institutional/free via Bentham site | ✅ Yes | Cancer drug targets | IF < 2; Q3; may not meet criteria |
| 6 | **Anti-Cancer Agents in Med Chem** | 1.95 | ✅ Yes | Q3 | ✅ Yes | ✅ Institutional/free via Bentham site | ✅ Yes | Anti-cancer agents, cancer pharmacology | IF < 2; Q3; may not meet criteria |
| 7 | **The Natural Products Journal** | 0.81 | ❌ No (ESCI) | Q4 | ✅ Yes | ✅ Institutional/free via Bentham site | ✅ Yes | Natural products, pharmacognosy | ⚠️ LOW IF; not SCIE; Q4; NOT recommended |
| 8 | **Current Topics in Medicinal Chemistry** | 2.68 | ✅ Yes | Q2 | ✅ Yes | ✅ Institutional/free via Bentham site | ✅ Yes (REVIEW-ONLY) | Medicinal chemistry reviews | REVIEW-ONLY; good for comprehensive NP reviews |
| 9 | **Current Drug Metabolism** | 1.95 | ✅ Yes | Q3 | ✅ Yes | ✅ Institutional/free via Bentham site | ✅ Yes | Drug metabolism, pharmacokinetics | IF < 2; Q3; metabolism-focused |
| 10 | **Current Organic Chemistry** | 2.85 | ✅ Yes | Q2 | ✅ Yes | ✅ Institutional/free via Bentham site | ✅ Yes | Organic chemistry, synthesis | Good for NP chemistry/synthesis aspects |
| 11 | **Current Gene Therapy** | 3.85 | ✅ Yes | Q2 | ✅ Yes | ✅ Institutional/free via Bentham site | ✅ Yes | Gene therapy, molecular biology | High IF but not relevant to NP+cancer |
| 12 | **Current Neuropharmacology** | 2.59 | ✅ Yes | Q2 | ✅ Yes | ✅ Institutional/free via Bentham site | ✅ Yes | Neuropharmacology | Not relevant to breast cancer |
| 13 | **Current Vascular Pharmacology** | 2.14 | ✅ Yes | Q3 | ✅ Yes | ✅ Institutional/free via Bentham site | ✅ Yes | Vascular pharmacology | IF ≥ 2 but Q3; limited relevance |
| 14 | **Current Diabetes Reviews** | 3.01 | ✅ Yes | Q2 | ✅ Yes | ✅ Institutional/free via Bentham site | ✅ Yes | Diabetes, metabolic diseases | High IF but not relevant to NP+cancer |

---

## 2. FUTURE SCIENCE GROUP JOURNALS

| # | Journal | JCR IF (2023) | SCIE | Scopus Q | Hybrid | Free Sub Route | Accepts Reviews | Relevant Scope | Notes |
|---|---------|---------------|------|----------|--------|----------------|-----------------|----------------|-------|
| 1 | **Future Medicinal Chemistry** | 3.24 | ✅ Yes | Q1 | ✅ Yes | ✅ Institutional | ✅ Yes | Medicinal chemistry, drug discovery | ⭐ EXCELLENT for NP + breast cancer review; Q1 |
| 2 | **Future Oncology** | 2.61 | ✅ Yes | Q2 | ✅ Yes | ✅ Institutional | ✅ Yes | Oncology, cancer treatment | Good for cancer-focused reviews |
| 3 | **Future Science OA** | 2.82 | ⚠️ ESCI | Q2 | 🔓 Full OA | ❌ N/A (OA journal) | ✅ Yes | Multidisciplinary | ⚠️ Not SCIE (ESCI only); full OA not hybrid |
| 4 | **Biomarkers in Medicine** | 1.99 | ✅ Yes | Q3 | ✅ Yes | ✅ Institutional | ✅ Yes | Biomarkers, diagnostics | IF < 2; Q3 |
| 5 | **Expert Review of Proteomics** | 3.24 | ✅ Yes | Q2 | ✅ Yes | ✅ Institutional | ✅ Yes | Proteomics, molecular biology | High IF but not relevant to NP+cancer |

---

## 3. DRUGS OF THE R&D (Acta Scientific / Pharma Research & Development)

| # | Journal | JCR IF (2023) | SCIE | Scopus Q | Hybrid | Free Sub Route | Accepts Reviews | Relevant Scope | Notes |
|---|---------|---------------|------|----------|--------|----------------|-----------------|----------------|-------|
| 1 | **Drug Research** (formerly Arzneimittel-Forschung) | 3.10 | ✅ Yes | Q2 | ✅ Yes | ✅ Institutional | ✅ Yes | Drug research, pharmacology | Published by Thieme; good for NP pharmacology |
| 2 | **Drugs under Experimental and Clinical Research** | 0.00 | ❌ No | Not indexed | ❌ N/A | ❌ N/A | ✅ Yes | Experimental clinical research | ⚠️ NOT recommended; appears suppressed/dropped |

---

## SUMMARY: JOURNALS MEETING ALL CRITERIA

**Criteria: IF ≥ 2, SCIE, Q1/Q2, Hybrid, Free subscription route, Accepts reviews**

### ✅ RECOMMENDED JOURNALS

| Rank | Journal | Publisher | IF | Q | Scope Fit | Why Consider |
|------|---------|-----------|-----|---|-----------|--------------|
| ⭐1 | **Future Medicinal Chemistry** | Future Science Group | 3.24 | Q1 | ★★★★★ | BEST MATCH: Q1, high IF, perfect for NP drug discovery + cancer |
| ⭐2 | **Current Drug Targets** | Bentham Science | 3.79 | Q1 | ★★★★ | Highest IF; good for target-based NP mechanisms |
| ⭐3 | **Current Diabetes Reviews** | Bentham Science | 3.01 | Q2 | ★★★ | Good IF but less relevant to breast cancer |
| ⭐4 | **Current Topics in Medicinal Chemistry** | Bentham Science | 2.68 | Q2 | ★★★★ | Review-only; good for comprehensive NP reviews |
| ⭐5 | **Current Organic Chemistry** | Bentham Science | 2.85 | Q2 | ★★★ | Good for NP chemistry/synthesis aspects |
| ⭐6 | **Current Pharmaceutical Design** | Bentham Science | 2.69 | Q2 | ★★★★ | Good for NP drug design |
| ⭐7 | **Current Medicinal Chemistry** | Bentham Science | 2.56 | Q2 | ★★★★ | Broad scope; accepts NP + cancer reviews |
| ⭐8 | **Future Oncology** | Future Science Group | 2.61 | Q2 | ★★★★ | Good for cancer treatment focus |
| ⭐9 | **Drug Research** | Thieme | 3.10 | Q2 | ★★★ | Good for NP pharmacology studies |
| 10 | **Mini-Reviews in Medicinal Chemistry** | Bentham Science | 2.07 | Q2 | ★★★★ | Review-only but IF borderline |

### ❌ JOURNALS NOT RECOMMENDED

| Journal | Reason |
|---------|--------|
| Current Cancer Drug Targets | IF < 2 (1.85); Q3 |
| Anti-Cancer Agents in Med Chem | IF < 2 (1.95); Q3 |
| The Natural Products Journal | IF 0.81; not SCIE; Q4 |
| Current Drug Metabolism | IF < 2 (1.95); Q3 |
| Biomarkers in Medicine | IF < 2 (1.99); Q3 |
| Drugs under Experimental and Clinical Research | IF 0.00; not indexed |
| Future Science OA | Not SCIE (ESCI only); full OA not hybrid |
| Current Gene Therapy | High IF but wrong scope |
| Current Neuropharmacology | Wrong scope |
| Current Vascular Pharmacology | Q3; limited relevance |
| Expert Review of Proteomics | Wrong scope |

---

## IMPORTANT NOTES

### ⚠️ Bentham Science Caveats
1. **Citation manipulation concerns**: Several Bentham journals were flagged by Scopus in 2023-2024 for citation manipulation. Check current status before submitting.
2. **Free subscription route**: Bentham offers free online access through institutional subscriptions or their "Open Access Plus" program. Many institutions have Bentham access.
3. **Predatory history**: Bentham Open (OA division) was on Beall's list. The subscription journals (Current Drug Targets, etc.) are generally considered legitimate.
4. **Review acceptance**: Most Bentham journals accept reviews but some prefer invited reviews. Contact editor before submission.

### ⚠️ Future Science Group Notes
1. **Acquired by SAGE Publishing** in 2022. Now operates under SAGE brand.
2. **Free subscription route**: Available through institutional access.
3. **Future Medicinal Chemistry** is the strongest recommendation from this group.

### ⚠️ Drug Research (Thieme)
1. **Formerly Arzneimittel-Forschung** - renamed to Drug Research in 2015.
2. **Published by Thieme** - reputable publisher.
3. **Good for pharmacology studies** including natural product drug research.

---

## TOP 3 RECOMMENDATIONS FOR NP + BREAST CANCER REVIEW

1. **Future Medicinal Chemistry** (IF 3.24, Q1) - Best overall match
2. **Current Drug Targets** (IF 3.79, Q1) - Highest IF, target-focused
3. **Current Topics in Medicinal Chemistry** (IF 2.68, Q2) - Review-only journal

All three are hybrid with free subscription routes available.
