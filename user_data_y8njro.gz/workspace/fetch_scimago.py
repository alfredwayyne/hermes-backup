import urllib.request
import re
import ssl

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

journals = [
    ("J Med Food", "1096-620X"),
    ("J Nat Prod", "0163-3864"),
    ("Nat Prod Rep", "0265-0568"),
    ("Metallomics", "1756-5901"),
    ("ACS Med Chem Lett", "1948-5875"),
    ("J Med Plants Res", "1996-0875"),
    ("Res Pharm Sci", "1735-5362"),
    ("Iran J Pharm Res", "1726-6882"),
]

for name, issn in journals:
    url = f"https://www.scimagojr.com/journalsearch.php?q={issn}&tip=jiss"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        resp = urllib.request.urlopen(req, timeout=15, context=ctx)
        html = resp.read().decode("utf-8", errors="ignore")
        sjr = re.findall(r"SJR\s*</th>\s*<td>(\d+\.\d+)", html)
        q = re.findall(r"Q(\d)", html)
        h = re.findall(r"h-index\s*</th>\s*<td>(\d+)", html)
        print(f"{name}: SJR={sjr[:2]}, Q={q[:10]}, h={h[:1]}")
    except Exception as e:
        print(f"{name}: ERROR - {e}")
