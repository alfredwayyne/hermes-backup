#!/usr/bin/env python3
"""Check journal websites directly for APC and other info."""

import urllib.request
import json
import re
import time

def fetch_url(url, timeout=15):
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"
        })
        response = urllib.request.urlopen(req, timeout=timeout)
        return response.read().decode("utf-8", errors="ignore")
    except Exception as e:
        return f"ERROR: {e}"

# Check Current Pharmaceutical Design - Bentham Science
print("=== Current Pharmaceutical Design (Bentham Science) ===")
# Bentham Science APC info
url = "https://www.eurekaselect.com/page/journal/1381-6128/about"
html = fetch_url(url)
if not html.startswith("ERROR"):
    text = re.sub(r'<[^>]+>', ' ', html)
    text = re.sub(r'\s+', ' ', text)
    # Look for APC/fee info
    for pattern in [r'APC[^.]{0,200}', r'article processing[^.]{0,200}', r'publication fee[^.]{0,200}', 
                    r'free to publish[^.]{0,200}', r'no charge[^.]{0,200}', r'open access[^.]{0,200}',
                    r'review[^.]{0,200}']:
        matches = re.findall(pattern, text, re.IGNORECASE)
        for m in matches[:2]:
            print(f"  {m[:200]}")
else:
    print(f"  Error: {html[:100]}")

print()

# Check Integrative Cancer Therapies - SAGE
print("=== Integrative Cancer Therapies (SAGE) ===")
url = "https://journals.sagepub.com/home/ict"
html = fetch_url(url)
if not html.startswith("ERROR"):
    text = re.sub(r'<[^>]+>', ' ', html)
    text = re.sub(r'\s+', ' ', text)
    for pattern in [r'APC[^.]{0,200}', r'article processing[^.]{0,200}', r'publication fee[^.]{0,200}',
                    r'free to publish[^.]{0,200}', r'no charge[^.]{0,200}', r'open access[^.]{0,200}',
                    r'review[^.]{0,200}']:
        matches = re.findall(pattern, text, re.IGNORECASE)
        for m in matches[:2]:
            print(f"  {m[:200]}")
else:
    print(f"  Error: {html[:100]}")

print()

# Check Pharmaceutical Biology - Taylor & Francis
print("=== Pharmaceutical Biology (Taylor & Francis) ===")
url = "https://www.tandfonline.com/journals/ibph20"
html = fetch_url(url)
if not html.startswith("ERROR"):
    text = re.sub(r'<[^>]+>', ' ', html)
    text = re.sub(r'\s+', ' ', text)
    for pattern in [r'APC[^.]{0,200}', r'article processing[^.]{0,200}', r'publication fee[^.]{0,200}',
                    r'free to publish[^.]{0,200}', r'no charge[^.]{0,200}', r'open access[^.]{0,200}',
                    r'review[^.]{0,200}']:
        matches = re.findall(pattern, text, re.IGNORECASE)
        for m in matches[:2]:
            print(f"  {m[:200]}")
else:
    print(f"  Error: {html[:100]}")

print()

# Check South African Journal of Botany - Elsevier
print("=== South African Journal of Botany (Elsevier) ===")
url = "https://www.sciencedirect.com/journal/south-african-journal-of-botany"
html = fetch_url(url)
if not html.startswith("ERROR"):
    text = re.sub(r'<[^>]+>', ' ', html)
    text = re.sub(r'\s+', ' ', text)
    for pattern in [r'APC[^.]{0,200}', r'article processing[^.]{0,200}', r'publication fee[^.]{0,200}',
                    r'free to publish[^.]{0,200}', r'no charge[^.]{0,200}', r'open access[^.]{0,200}',
                    r'review[^.]{0,200}']:
        matches = re.findall(pattern, text, re.IGNORECASE)
        for m in matches[:2]:
            print(f"  {m[:200]}")
else:
    print(f"  Error: {html[:100]}")

print()

# Check Journal of Natural Medicines - Springer
print("=== Journal of Natural Medicines (Springer) ===")
url = "https://www.springer.com/journal/11418"
html = fetch_url(url)
if not html.startswith("ERROR"):
    text = re.sub(r'<[^>]+>', ' ', html)
    text = re.sub(r'\s+', ' ', text)
    for pattern in [r'APC[^.]{0,200}', r'article processing[^.]{0,200}', r'publication fee[^.]{0,200}',
                    r'free to publish[^.]{0,200}', r'no charge[^.]{0,200}', r'open access[^.]{0,200}',
                    r'review[^.]{0,200}']:
        matches = re.findall(pattern, text, re.IGNORECASE)
        for m in matches[:2]:
            print(f"  {m[:200]}")
else:
    print(f"  Error: {html[:100]}")

print()

# Check Natural Product Communications - SAGE
print("=== Natural Product Communications (SAGE) ===")
url = "https://journals.sagepub.com/home/npc"
html = fetch_url(url)
if not html.startswith("ERROR"):
    text = re.sub(r'<[^>]+>', ' ', html)
    text = re.sub(r'\s+', ' ', text)
    for pattern in [r'APC[^.]{0,200}', r'article processing[^.]{0,200}', r'publication fee[^.]{0,200}',
                    r'free to publish[^.]{0,200}', r'no charge[^.]{0,200}', r'open access[^.]{0,200}',
                    r'review[^.]{0,200}']:
        matches = re.findall(pattern, text, re.IGNORECASE)
        for m in matches[:2]:
            print(f"  {m[:200]}")
else:
    print(f"  Error: {html[:100]}")

print()

# Check Journal of Asian Natural Products Research - T&F
print("=== Journal of Asian Natural Products Research (T&F) ===")
url = "https://www.tandfonline.com/journals/tjna20"
html = fetch_url(url)
if not html.startswith("ERROR"):
    text = re.sub(r'<[^>]+>', ' ', html)
    text = re.sub(r'\s+', ' ', text)
    for pattern in [r'APC[^.]{0,200}', r'article processing[^.]{0,200}', r'publication fee[^.]{0,200}',
                    r'free to publish[^.]{0,200}', r'no charge[^.]{0,200}', r'open access[^.]{0,200}',
                    r'review[^.]{0,200}']:
        matches = re.findall(pattern, text, re.IGNORECASE)
        for m in matches[:2]:
            print(f"  {m[:200]}")
else:
    print(f"  Error: {html[:100]}")
