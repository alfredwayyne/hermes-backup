import urllib.request
import re
import json
import ssl

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

def fetch_url(url, timeout=15):
    req = urllib.request.Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
    })
    resp = urllib.request.urlopen(req, timeout=timeout, context=ctx)
    return resp.read().decode("utf-8", errors="ignore")

# Try LetPub with proper search
journals = [
    ("Journal of Medicinal Food", "1096-620X"),
    ("Journal of Natural Products", "0163-3864"),
    ("Natural Product Reports", "0265-0568"),
    ("ACS Medicinal Chemistry Letters", "1948-5875"),
    ("Journal of Medicinal Plants Research", "1996-0875"),
    ("Research in Pharmaceutical Sciences", "1735-5362"),
]

for name, issn in journals:
    print(f"\n=== {name} ===")
    
    # Try LetPub search
    search_name = name.replace(" ", "+")
    url = f"https://www.letpub.com.cn/index.php?page=journalapp&view=search&search_field=journal_name&searchname={search_name}"
    try:
        html = fetch_url(url, timeout=15)
        # Clean HTML
        text = re.sub(r'<[^>]+>', ' ', html)
        text = re.sub(r'\s+', ' ', text)
        
        # Look for IF and Q info in the text
        # LetPub usually shows "IF:" and "中科院分区:" in the results
        if_match = re.findall(r"IF[：:]\s*(\d+\.\d+)", text)
        q_match = re.findall(r"中科院.*?[Qq](\d)", text)
        scie_match = re.findall(r"SCI[CE]|Science Citation Index", text, re.IGNORECASE)
        
        print(f"  IF: {if_match[:5]}")
        print(f"  Q: {q_match[:10]}")
        print(f"  SCIE: {'Yes' if scie_match else 'No'}")
        
        # Also look for specific patterns
        if_patterns = re.findall(r"(\d+\.\d+)\s*(?:\(|（)", text)
        print(f"  Numbers with parens: {if_patterns[:5]}")
        
    except Exception as e:
        print(f"  LetPub: ERROR - {e}")
