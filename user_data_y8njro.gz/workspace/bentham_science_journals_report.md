# Bentham Science Journals — Detailed Report
## For: "A Selective Review of Natural Products from Plant, Animal, and Microbial Sources Against Breast Cancer Cell Lines"

**Report Date:** August 4, 2026  
**Criteria:** IF ≥ 2.0, SCIE/SCI indexed, Q1/Q2 Scopus, Hybrid (subscription+OA), accepts reviews

---

## Publisher Overview

**Bentham Science Publishers** (est. 1994, Sharjah, UAE) publishes 120+ subscription-based journals and ~40 open access journals (Bentham Open division). As of 2023, **66 journals have JCR Impact Factors**. All subscription journals are indexed in Scopus, Chemical Abstracts, MEDLINE, EMBASE. Bentham is a member of COPE.

**Important Notes:**
- Bentham subscription journals = **HYBRID** (authors can optionally pay an APC for OA; subscription route is FREE)
- Bentham Open journals are fully OA with APC (not hybrid)
- Some Bentham journals may be **ESCI** (Emerging Sources Citation Index) rather than SCIE — flagged below
- Bentham Open journals have been criticized for predatory practices (Beall's list) — avoid for review articles

---

## Journal-by-Journal Analysis

### 1. Current Drug Targets ⭐⭐⭐ BEST MATCH
| Field | Detail |
|---|---|
| **ISSN** | 1389-4501 (Print) / 1873-5592 (Online) |
| **Impact Factor** | **~4.0** (2023 JCR) |
| **ISI Status** | **SCIE** ✓ |
| **Scopus Q** | **Q1** (Pharmacology & Pharmacy) |
| **Hybrid?** | YES — subscription journal with optional OA |
| **APC** | FREE for subscription route |
| **Accepts Reviews?** | YES — themed issues are review-heavy |
| **Frequency** | 12 issues/year |
| **Relevance to Topic** | **VERY HIGH** — drug targets for cancer; natural product targets; accepts reviews on breast cancer molecular targets |
| **Assessment** | ✅ **TOP CHOICE** — SCIE, Q1, IF well above 2.0, actively publishes themed review collections |

---

### 2. Mini-Reviews in Medicinal Chemistry ⭐⭐⭐ BEST MATCH
| Field | Detail |
|---|---|
| **ISSN** | 1568-0169 (Print) / 1875-5607 (Online) |
| **Impact Factor** | **~3.8** (2023 JCR) |
| **ISI Status** | **SCIE** ✓ |
| **Scopus Q** | **Q1** (Medicinal Chemistry) |
| **Hybrid?** | YES — subscription journal with optional OA |
| **APC** | FREE for subscription route |
| **Accepts Reviews?** | **YES — ONLY publishes reviews** (mini-reviews, typically 3-10 pages) |
| **Frequency** | Monthly (12 issues/year) |
| **Relevance to Topic** | **VERY HIGH** — exclusively publishes mini-reviews; natural products against cancer is a core topic |
| **Assessment** | ✅ **TOP CHOICE** — If the article is a focused mini-review (≤10 pages), this is ideal. SCIE, Q1, review-only journal |

---

### 3. Current Medicinal Chemistry ⭐⭐ STRONG MATCH
| Field | Detail |
|---|---|
| **ISSN** | 0929-8673 (Print) / 1875-533X (Online) |
| **Impact Factor** | **~3.7** (2023 JCR) |
| **ISI Status** | **SCIE** ✓ |
| **Scopus Q** | **Q1** (Medicinal Chemistry) |
| **Hybrid?** | YES — subscription journal with optional OA |
| **APC** | FREE for subscription route |
| **Accepts Reviews?** | YES — original research + review papers |
| **Frequency** | 18 issues/year |
| **Relevance to Topic** | **HIGH** — medicinal chemistry, drug design; natural product drug discovery fits well |
| **Assessment** | ✅ **STRONG CHOICE** — SCIE, Q1, high IF, welcomes reviews on medicinal chemistry topics |

---

### 4. Anti-Cancer Agents in Medicinal Chemistry ⭐⭐ STRONG MATCH
| Field | Detail |
|---|---|
| **ISSN** | 1567-7192 (Print) / 1875-5992 (Online) |
| **Impact Factor** | **~2.7** (2023 JCR) |
| **ISI Status** | **SCIE** ✓ |
| **Scopus Q** | **Q2** (Medicinal Chemistry / Oncology) |
| **Hybrid?** | YES — subscription journal with optional OA |
| **APC** | FREE for subscription route |
| **Accepts Reviews?** | YES — original research + review papers |
| **Frequency** | 18 issues/year |
| **Relevance to Topic** | **VERY HIGH** — specifically covers anti-cancer agents and their medicinal chemistry |
| **Assessment** | ✅ **STRONG CHOICE** — Directly relevant; SCIE, Q2, accepts reviews on natural anti-cancer agents |

---

### 5. Current Cancer Drug Targets ⭐⭐ STRONG MATCH
| Field | Detail |
|---|---|
| **ISSN** | 1568-0142 (Print) / 1873-5592 (Online) |
| **Impact Factor** | **~3.0** (2023 JCR) |
| **ISI Status** | **SCIE** ✓ |
| **Scopus Q** | **Q1-Q2** (Oncology / Pharmacology) |
| **Hybrid?** | YES — subscription journal with optional OA |
| **APC** | FREE for subscription route |
| **Accepts Reviews?** | YES — original research, reviews, rapid communications |
| **Frequency** | 12 issues/year |
| **Relevance to Topic** | **VERY HIGH** — molecular drug targets in cancer; natural product targets in breast cancer |
| **Assessment** | ✅ **STRONG CHOICE** — SCIE, Q1-Q2, cancer drug targets is the exact topic |

---

### 6. Current Topics in Medicinal Chemistry ⭐ GOOD MATCH
| Field | Detail |
|---|---|
| **ISSN** | 1568-0266 (Print) / 1873-4294 (Online) |
| **Impact Factor** | **~3.2** (2023 JCR) |
| **ISI Status** | **SCIE** ✓ |
| **Scopus Q** | **Q1-Q2** (Medicinal Chemistry) |
| **Hybrid?** | YES — subscription journal with optional OA |
| **APC** | FREE for subscription route |
| **Accepts Reviews?** | YES — themed issues of review articles |
| **Frequency** | 24 issues/year (biweekly) |
| **Relevance to Topic** | **HIGH** — themed issues on medicinal chemistry; natural products in cancer is a recurring theme |
| **Assessment** | ✅ **GOOD CHOICE** — SCIE, Q1-Q2, themed review issues |

---

### 7. Current Pharmaceutical Design ⭐ GOOD MATCH
| Field | Detail |
|---|---|
| **ISSN** | 1381-6128 (Print) / 1873-4286 (Online) |
| **Impact Factor** | **~2.3** (2023 JCR) |
| **ISI Status** | **SCIE** ✓ |
| **Scopus Q** | **Q2-Q3** (Pharmacology & Pharmacy) |
| **Hybrid?** | YES — subscription journal with optional OA |
| **APC** | FREE for subscription route |
| **Accepts Reviews?** | YES — themed issues devoted to single therapeutic areas |
| **Frequency** | 46 issues/year |
| **Relevance to Topic** | **MEDIUM-HIGH** — pharmacology and drug design; cancer therapeutics possible |
| **Assessment** | ⚠️ **VIABLE** — SCIE, but Q2-Q3 and lower IF. Still meets criteria if Q2 in specific category |

---

### 8. Current Drug Metabolism ⭐ GOOD MATCH
| Field | Detail |
|---|---|
| **ISSN** | 1389-2002 (Print) / 1875-5453 (Online) |
| **Impact Factor** | **~2.8** (2023 JCR; Wikipedia confirmed 2.960 for 2019) |
| **ISI Status** | **SCIE** ✓ |
| **Scopus Q** | **Q2** (Pharmacology & Pharmacy) |
| **Hybrid?** | YES — subscription journal with optional OA |
| **APC** | FREE for subscription route |
| **Accepts Reviews?** | YES — original research + review papers |
| **Frequency** | 10 issues/year |
| **Relevance to Topic** | **MEDIUM** — drug metabolism of natural products from plants/animals/microbes |
| **Assessment** | ⚠️ **VIABLE** — Metabolism angle could work for a review on bioactive natural product metabolism |

---

### 9. Current Organic Chemistry ⭐ OKAY MATCH
| Field | Detail |
|---|---|
| **ISSN** | 1385-2795 (Print) / 1570-1794 (Online) |
| **Impact Factor** | **~2.2** (2023 JCR) |
| **ISI Status** | **SCIE** ✓ |
| **Scopus Q** | **Q2-Q3** (Organic Chemistry) |
| **Hybrid?** | YES — subscription journal with optional OA |
| **APC** | FREE for subscription route |
| **Accepts Reviews?** | YES — scientific review journal (summarizes progress) |
| **Frequency** | 12 issues/year |
| **Relevance to Topic** | **MEDIUM** — natural product chemistry is explicitly listed as a topic |
| **Assessment** | ⚠️ **VIABLE** — Natural products chemistry fits, but IF is borderline and Q2-Q3 |

---

### 10. Current Gene Therapy ⚠️ MARGINAL MATCH
| Field | Detail |
|---|---|
| **ISSN** | 1566-5099 (Print) / 1875-5631 (Online) |
| **Impact Factor** | **~2.5** (2023 JCR) |
| **ISI Status** | **SCIE** ✓ |
| **Scopus Q** | **Q2-Q3** (Genetics / Biotechnology) |
| **Hybrid?** | YES — subscription journal with optional OA |
| **APC** | FREE for subscription route |
| **Accepts Reviews?** | YES — original research, reviews, rapid communications |
| **Frequency** | 12 issues/year |
| **Relevance to Topic** | **LOW** — gene therapy focus, not directly about natural products or breast cancer |
| **Assessment** | ❌ **NOT RECOMMENDED** — Focus on gene therapy doesn't align well with natural products review |

---

### 11. Current Neuropharmacology ⚠️ MARGINAL MATCH
| Field | Detail |
|---|---|
| **ISSN** | 1570-159X (Print) / 1875-6190 (Online) |
| **Impact Factor** | **~4.5** (2023 JCR) |
| **ISI Status** | **SCIE** ✓ |
| **Scopus Q** | **Q1** (Pharmacology & Pharmacy) |
| **Hybrid?** | YES — subscription journal with optional OA |
| **APC** | FREE for subscription route |
| **Accepts Reviews?** | YES |
| **Frequency** | 12 issues/year |
| **Relevance to Topic** | **LOW** — neuropharmacology focus, not cancer |
| **Assessment** | ❌ **NOT RECOMMENDED** — Despite high IF, neuropharmacology focus is off-topic |

---

### 12. The Natural Products Journal ⭐⭐ STRONG MATCH (if hybrid)
| Field | Detail |
|---|---|
| **ISSN** | 1875-6794 (Print) / 1875-6786 (Online) |
| **Impact Factor** | **~2.1** (2023 JCR) |
| **ISI Status** | **SCIE** ✓ |
| **Scopus Q** | **Q2-Q3** (Biochemistry / Pharmacology) |
| **Hybrid?** | YES — subscription journal with optional OA |
| **APC** | FREE for subscription route |
| **Accepts Reviews?** | YES |
| **Frequency** | Quarterly (4 issues/year) |
| **Relevance to Topic** | **VERY HIGH** — natural products journal, directly covers plant/animal/microbial natural products |
| **Assessment** | ⚠️ **VIABLE but lower IF** — Topically perfect but IF ~2.1 is borderline and Q2-Q3 |

> **Note:** There may be confusion with "Natural Product Research" (Taylor & Francis, ISSN 1478-6419) which is a different journal. The Bentham journal is "The Natural Products Journal."

---

## Summary: TOP RECOMMENDATIONS (Ranked)

| Rank | Journal | IF | Scopus Q | Review-friendly | Natural Products | Cancer |
|------|---------|-----|----------|-----------------|------------------|--------|
| **1** | **Mini-Reviews in Medicinal Chemistry** | ~3.8 | Q1 | ⭐⭐⭐ (only reviews) | ⭐⭐ | ⭐⭐ |
| **2** | **Current Drug Targets** | ~4.0 | Q1 | ⭐⭐⭐ | ⭐⭐ | ⭐⭐⭐ |
| **3** | **Current Medicinal Chemistry** | ~3.7 | Q1 | ⭐⭐⭐ | ⭐⭐ | ⭐⭐ |
| **4** | **Anti-Cancer Agents in Medicinal Chem.** | ~2.7 | Q2 | ⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐ |
| **5** | **Current Cancer Drug Targets** | ~3.0 | Q1-Q2 | ⭐⭐⭐ | ⭐⭐ | ⭐⭐⭐ |
| **6** | **Current Topics in Medicinal Chemistry** | ~3.2 | Q1-Q2 | ⭐⭐⭐ (themed) | ⭐⭐ | ⭐⭐ |
| **7** | **Current Pharmaceutical Design** | ~2.3 | Q2-Q3 | ⭐⭐⭐ (themed) | ⭐⭐ | ⭐⭐ |
| **8** | **Current Drug Metabolism** | ~2.8 | Q2 | ⭐⭐ | ⭐⭐ | ⭐ |
| **9** | **Current Organic Chemistry** | ~2.2 | Q2-Q3 | ⭐⭐⭐ | ⭐⭐⭐ | ⭐ |
| **10** | **The Natural Products Journal** | ~2.1 | Q2-Q3 | ⭐⭐ | ⭐⭐⭐ | ⭐⭐ |

---

## Key Facts About Bentham Hybrid Journals

1. **All subscription-based Bentham journals are HYBRID** — authors can choose free subscription route or pay OA fee
2. **Subscription route = NO APC** — this is a major advantage
3. **OA APC** — Bentham charges ~$2,800-$3,500 USD for OA option (varies by journal)
4. **All journals accept reviews** — Bentham journals actively solicit review articles and themed issues
5. **Themed/Collection issues** — Many Bentham journals run themed issues; the editor-in-chief can be contacted to propose a collection
6. **SCIE verification** — As of 2023, 66 Bentham journals have JCR Impact Factors (SCIE indexed); verify specific journals at jcr.clarivate.com

## ⚠️ Critical Notes

1. **Impact Factors are approximate** — based on 2023 JCR data; always verify at jcr.clarivate.com before submission
2. **Scopus Q-rankings change yearly** — verify at scimagojr.com
3. **ESCI vs SCIE** — Some newer Bentham journals may only be ESCI (Emerging Sources), which has NO Impact Factor. Verify before targeting
4. **Bentham Open vs Bentham Science** — Avoid Bentham Open (fully OA, predatory concerns). Target Bentham Science (subscription/hybrid) journals only
5. **No submission fees** for subscription route — this is a significant financial advantage

## Recommended Submission Strategy

For a review article on "Natural Products from Plant, Animal, and Microbial Sources Against Breast Cancer Cell Lines":

**Option A (Full review, ~8000-15000 words):**
→ **Current Drug Targets** or **Anti-Cancer Agents in Medicinal Chemistry**
- Both actively publish natural product-focused review collections
- Contact themed issue editors

**Option B (Mini-review, ≤6 pages):**
→ **Mini-Reviews in Medicinal Chemistry**
- Only publishes reviews; Q1, high IF
- Perfect for a focused review

**Option C (Drug targets angle):**
→ **Current Cancer Drug Targets**
- Molecular mechanisms of natural products against breast cancer targets
