import urllib.request
import re
import json
import ssl

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

def fetch_url(url, timeout=15):
    req = urllib.request.Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
    })
    resp = urllib.request.urlopen(req, timeout=timeout, context=ctx)
    return resp.read().decode("utf-8", errors="ignore")

# Let me try to fetch the LetPub search page and look at the raw HTML
# to understand the structure better
url = "https://www.letpub.com.cn/index.php?page=journalapp&view=search&search_field=journal_name&searchname=Journal+of+Natural+Products"
html = fetch_url(url, timeout=15)

# Save the HTML for analysis
with open("/data/workspace/letpub_search.html", "w") as f:
    f.write(html)

# Let me look for patterns in the HTML
# First, let me find all the table rows
rows = re.findall(r'<tr[^>]*>(.*?)</tr>', html, re.DOTALL)
print(f"Found {len(rows)} table rows")

# Let me look for the first few rows that might contain journal data
for i, row in enumerate(rows[:10]):
    text = re.sub(r'<[^>]+>', ' ', row)
    text = re.sub(r'\s+', ' ', text).strip()
    if text:
        print(f"Row {i}: {text[:200]}")
