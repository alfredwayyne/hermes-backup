#!/usr/bin/env python3
"""Check Scopus quartiles and SCIE status for promising journals."""

import urllib.request
import json
import re
import time

def fetch_url(url, timeout=15):
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"
        })
        response = urllib.request.urlopen(req, timeout=timeout)
        return response.read().decode("utf-8", errors="ignore")
    except Exception as e:
        return f"ERROR: {e}"

# Try to check Scopus quartiles via SCImago API or other sources
# SCImago has a widget API that might work
journals_to_check = [
    ("Current Pharmaceutical Design", "1381-6128"),
    ("Integrative Cancer Therapies", "1534-7354"),
    ("Pharmaceutical Biology", "1388-0209"),
    ("South African Journal of Botany", "0254-6299"),
    ("Journal of Natural Medicines", "1861-0294"),
    ("Natural Product Communications", "1555-9475"),
    ("Journal of Asian Natural Products Research", "1028-6020"),
]

print("Checking Scopus data...")
print("=" * 80)

for name, issn in journals_to_check:
    # Try Scopus source search
    url = f"https://www.scopus.com/sourceid/{issn}"
    html = fetch_url(url)
    
    if not html.startswith("ERROR"):
        text = re.sub(r'<[^>]+>', ' ', html)
        text = re.sub(r'\s+', ' ', text)
        
        # Look for quartile info
        q_match = re.search(r'(?:Q[1-4]|quartile)[^.]{0,100}', text, re.IGNORECASE)
        sjr_match = re.search(r'(?:SJR|SCImago)[^.]{0,100}', text, re.IGNORECASE)
        
        print(f"\n=== {name} (ISSN: {issn}) ===")
        if q_match:
            print(f"  Quartile: {q_match.group()[:100]}")
        if sjr_match:
            print(f"  SJR: {sjr_match.group()[:100]}")
        
        # Check for indexing info
        if 'SCIE' in text:
            print("  SCIE: Yes")
        if 'ESCI' in text:
            print("  ESCI: Yes")
        if 'Scopus' in text:
            print("  Scopus: Yes")
    else:
        print(f"\n=== {name} === Scopus error: {html[:100]}")
    
    time.sleep(0.5)
