# Journal Metrics Research Report
## For E2F1-p53 Pathway Cancer Biology Review Article
### Date: July 29, 2026

## Summary Table

| # | Journal | Impact Factor | ISI Status | Scopus Q Rank | APC (USD) | Publisher | Accepts Reviews |
|---|---------|--------------|------------|---------------|-----------|-----------|----------------|
| 1 | Current Medical Science | 2.23 (OpenAlex 2yr mean) | SCIE | Q2 | $3,390 (hybrid) | Springer Nature / Huazhong Univ | Yes |
| 2 | Molecular Biology Reports | 2.32 (JCR 2020) / 3.09 (OpenAlex) | SCIE | Q2 | $3,790 (hybrid) | Springer Nature | Yes |
| 3 | Progress in Biophysics and Molecular Biology | 3.67 (JCR 2020) / 4.29 (OpenAlex) | SCIE | Q1 | $3,050 (hybrid) | Elsevier | Yes |
| 4 | European Journal of Pharmaceutics and Biopharmaceutics | 5.00 (OpenAlex) | SCIE | Q1 | $4,270 (hybrid) | Elsevier | Yes |
| 5 | Molecular and Cellular Biology | 5.07 (JCR 2021) / 2.88 (OpenAlex) | SCIE | Q2 | No APC | ASM / Taylor & Francis | Yes |
| 6 | Transcription | 2.69 (OpenAlex) | SCIE | Q2-Q3 | No APC | Taylor & Francis | Yes |
| 7 | Cell Cycle | 2.27 (OpenAlex) | SCIE | Q2 | No APC | Taylor & Francis | Yes |
| 8 | Epigenomics | 2.81 (OpenAlex) / 4.98 (JCR 2017) | SCIE | Q2 | No APC | Future Medicine | Yes |
| 9 | Critical Reviews in Biochemistry and Molecular Biology | 6.4 (WoS 2026) / 7.71 (JCR 2014) / 8.41 (OpenAlex) | SCIE | Q1 | No APC | Taylor & Francis | Yes (review-only journal) |

## Detailed Notes by Journal

### 1. Current Medical Science
- **ISSN:** 2096-5230 (Print) / 2523-899X (Online)
- **Publisher:** Springer Nature (co-published with Huazhong University of Science and Technology)
- **Impact Factor:** ~2.23 (OpenAlex 2yr_mean_citedness). Wikipedia reports JCR 2017 IF of 0.948, but this is outdated. Current metrics suggest improvement.
- **ISI Status:** SCIE (indexed in Science Citation Index per Wikipedia and indexing databases)
- **Scopus Q Rank:** Q2 (estimated based on field and metrics)
- **APC:** $3,390 for open access; subscription access available without APC
- **Review articles:** Yes - accepts review articles as a general medical journal
- **NOTES:** IF may be borderline for IF > 2 criterion. The 2017 IF was only 0.948. Current metrics have improved but verification of exact current JCR IF recommended.

### 2. Molecular Biology Reports
- **ISSN:** 0301-4851 (Print) / 1573-4978 (Online)
- **Publisher:** Springer Nature
- **Impact Factor:** 2.316 (JCR 2020 per Wikipedia); OpenAlex 2yr_mean_citedness: 3.09
- **ISI Status:** SCIE (indexed in Science Citation Index, PubMed/MEDLINE, Scopus)
- **Scopus Q Rank:** Q2
- **APC:** $3,790 for open access; subscription access available without APC
- **Review articles:** Yes - accepts review articles
- **NOTES:** Hybrid journal. Established 1806. Good standing.

### 3. Progress in Biophysics and Molecular Biology
- **ISSN:** 0079-6107 (Print) / 1873-1732 (Online)
- **Publisher:** Elsevier
- **Impact Factor:** 3.667 (JCR 2020); CiteScore 5.8; OpenAlex 2yr_mean_citedness: 4.29
- **ISI Status:** SCIE
- **Scopus Q Rank:** Q1 (in Biophysics category)
- **APC:** $3,050 for open access; subscription access available without APC
- **Review articles:** Yes - primarily publishes reviews and perspectives
- **NOTES:** Strong journal for reviews. High h-index (174).

### 4. European Journal of Pharmaceutics and Biopharmaceutics
- **ISSN:** 0939-6411
- **Publisher:** Elsevier
- **Impact Factor:** ~5.0 (OpenAlex 2yr_mean_citedness)
- **ISI Status:** SCIE (indexed in Science Citation Index, Scopus, MEDLINE, EMBASE)
- **Scopus Q Rank:** Q1 (in Pharmaceutics category)
- **APC:** $4,270 for open access; subscription access available without APC
- **Review articles:** Yes - accepts review articles
- **NOTES:** Strong journal. h-index 211. However, scope is primarily pharmaceutics - may not be ideal for pure cancer biology.

### 5. Molecular and Cellular Biology
- **ISSN:** 0270-7306 (Print) / 1098-5549 (Online)
- **Publisher:** American Society for Microbiology (ASM), currently under Taylor & Francis
- **Impact Factor:** 5.069 (JCR 2021 per Wikipedia); OpenAlex 2yr_mean_citedness: 2.88
- **ISI Status:** SCIE
- **Scopus Q Rank:** Q2
- **APC:** No APC for subscription access; may have OA options
- **Review articles:** Yes - accepts review articles
- **NOTES:** Very high h-index (460). Long-established journal (32,000+ articles). Note the discrepancy between JCR 2021 (5.07) and OpenAlex current (2.88) - may indicate IF has decreased recently.

### 6. Transcription
- **ISSN:** 2154-1264 (Print) / 2154-1272 (Online)
- **Publisher:** Taylor & Francis (formerly Landes Bioscience)
- **Impact Factor:** ~2.69 (OpenAlex 2yr_mean_citedness)
- **ISI Status:** SCIE
- **Scopus Q Rank:** Q2-Q3
- **APC:** No APC for subscription access
- **Review articles:** Yes - accepts review articles
- **NOTES:** Smaller journal (480 works). Focuses specifically on transcription mechanisms. Good fit for E2F1-p53 pathway review.

### 7. Cell Cycle
- **ISSN:** 1538-4101 (Print) / 1551-4005 (Online)
- **Publisher:** Taylor & Francis (formerly Landes Bioscience)
- **Impact Factor:** ~2.27 (OpenAlex 2yr_mean_citedness)
- **ISI Status:** SCIE
- **Scopus Q Rank:** Q2
- **APC:** No APC for subscription access
- **Review articles:** Yes - accepts review articles
- **NOTES:** Good fit for cancer biology/cell cycle regulation. 9,863 works. h-index 200.

### 8. Epigenomics
- **ISSN:** 1750-1911 (Print) / 1750-192X (Online)
- **Publisher:** Future Medicine (now part of Taylor & Francis)
- **Impact Factor:** 4.979 (JCR 2017 per Wikipedia); OpenAlex 2yr_mean_citedness: 2.81
- **ISI Status:** SCIE (Science Citation Index Expanded)
- **Scopus Q Rank:** Q2 (ranked 31st out of 166 in Genetics & Heredity per JCR 2017)
- **APC:** No APC for subscription access
- **Review articles:** Yes - accepts review articles
- **NOTES:** IF has decreased from 4.98 (2017) to ~2.81 currently. May have been transferred from Future Medicine to Taylor & Francis.

### 9. Critical Reviews in Biochemistry and Molecular Biology
- **ISSN:** 1040-9238 (Print) / 1549-7798 (Online)
- **Publisher:** Taylor & Francis
- **Impact Factor:** 6.4 (WoS 2026 per Wikipedia); JCR 2014: 7.714; OpenAlex 2yr_mean_citedness: 8.41
- **ISI Status:** SCIE
- **Scopus Q Rank:** Q1
- **APC:** No APC for subscription access
- **Review articles:** Yes - EXCLUSIVELY publishes review articles
- **NOTES:** This is a review-only journal. Highest IF among the 9 journals. Excellent choice for a review article. h-index 185. Established 1972.

## Best Candidates for E2F1-p53 Pathway Review (meeting IF>2, SCIE, Q1/Q2, no APC)

### Tier 1 (Best Fit):
1. **Critical Reviews in Biochemistry and Molecular Biology** - IF ~6.4-8.4, SCIE, Q1, review-only journal, NO APC
2. **Molecular and Cellular Biology** - IF ~2.88-5.07, SCIE, Q2, NO APC

### Tier 2 (Good Fit):
3. **Progress in Biophysics and Molecular Biology** - IF ~3.67-4.29, SCIE, Q1, but APC ~$3,050
4. **Epigenomics** - IF ~2.81, SCIE, Q2, NO APC (if epigenetic aspects of E2F1-p53 are covered)
5. **Cell Cycle** - IF ~2.27, SCIE, Q2, NO APC (good fit for cell cycle regulation)

### Tier 3 (Acceptable):
6. **Transcription** - IF ~2.69, SCIE, Q2-Q3, NO APC
7. **Molecular Biology Reports** - IF ~2.32-3.09, SCIE, Q2, but APC ~$3,790

### Tier 4 (Caution):
8. **Current Medical Science** - IF may be borderline (~2.23), need to verify current JCR IF
9. **European Journal of Pharmaceutics and Biopharmaceutics** - Good IF but scope mismatch; APC $4,270

## Data Sources
- OpenAlex API (2yr_mean_citedness as proxy for current IF)
- Wikipedia journal articles (JCR impact factors from various years)
- Crossref API (publisher verification)
- DOAJ (open access verification)

## Caveats
- Impact Factors are approximate - JCR official values should be verified on Clarivate's Master Journal List
- Scopus Q rankings are estimated - exact rankings should be verified on SCImago Journal Rank
- APC fees may vary - verify on journal websites before submission
- Some IF values are from different years (2014-2026) and may not reflect current standing
- "No APC" means no mandatory APC for subscription access; OA options may have fees
