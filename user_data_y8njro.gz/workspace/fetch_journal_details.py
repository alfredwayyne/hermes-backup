import urllib.request
import re
import json
import ssl

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

journals = [
    "Journal_of_Medicinal_Food",
    "Journal_of_Natural_Products",
    "Natural_Product_Reports",
    "Metallomics",
    "ACS_Medicinal_Chemistry_Letters",
    "Journal_of_Medicinal_Plants_Research",
    "Research_in_Pharmaceutical_Sciences",
]

for j in journals:
    url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{j}"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        resp = urllib.request.urlopen(req, timeout=10, context=ctx)
        data = json.loads(resp.read().decode("utf-8"))
        abstract = data.get("extract", "No extract")
        print(f"\n=== {j.replace('_', ' ')} ===")
        print(f"  Extract: {abstract[:300]}")
    except Exception as e:
        print(f"\n=== {j.replace('_', ' ')} === ERROR: {e}")

# Now let me search for impact factors using a different source
# Let me try to search for journal metrics using the Crossref API
print("\n\n=== Checking Crossref for journal metrics ===")

journals_crossref = [
    ("J Med Food", "1096-620X"),
    ("J Nat Prod", "0163-3864"),
    ("Nat Prod Rep", "0265-0568"),
    ("ACS Med Chem Lett", "1948-5875"),
    ("Res Pharm Sci", "1735-5362"),
    ("Iran J Pharm Res", "1726-6882"),
]

for name, issn in journals_crossref:
    url = f"https://api.crossref.org/journals/{issn}"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        resp = urllib.request.urlopen(req, timeout=10, context=ctx)
        data = json.loads(resp.read().decode("utf-8"))
        msg = data.get("message", {})
        print(f"\n=== {name} ===")
        print(f"  Title: {msg.get('title', 'N/A')}")
        print(f"  Publisher: {msg.get('publisher', 'N/A')}")
        print(f"  ISSN: {msg.get('ISSN', 'N/A')}")
        print(f"  ISSN-L: {msg.get('ISSN-L', 'N/A')}")
        print(f"  Subject: {msg.get('subject', 'N/A')[:5] if msg.get('subject') else 'N/A'}")
    except Exception as e:
        print(f"\n=== {name} === ERROR: {e}")
