# Journal Verification Report
## Topic: Natural Products from Plant, Animal, and Microbial Sources Against Breast Cancer Cell Lines
## Criteria: FREE (subscription, no APC/page fees), IF ≥ 2.0, SCIE, Q1/Q2 Scopus, accepts reviews, relevant to natural products + cancer

---

## VERIFIED DATA (from publisher websites, August 2025)

### Springer Journals (Hybrid = FREE for subscription submissions)

| Journal | IF (JCR 2025) | Hybrid | SCIE | Verdict |
|---------|-----------|--------|------|---------|
| Archives of Pharmacal Research | 8.2 | ✅ | ✅ | ❌ IF TOO HIGH |
| Molecular Biology Reports | 3.2 | ✅ | ✅ | ⚠️ See below |
| In Vitro Cell Dev Biol - Animal | 2.0 | ✅ | ✅ | ⚠️ See below |
| Cytotechnology | 2.2 | ✅ | ✅ | ⚠️ See below |

---

## QUALIFIED JOURNALS (Ranked by relevance)

### 🥇 1. Chinese Journal of Natural Medicines (Elsevier)
- **IF**: ~3.0 (JCR 2023) ✓
- **SCIE**: Yes ✓
- **Free for authors**: Yes (hybrid; subscription submissions free) ✓
- **Scopus Q**: Q1 (Pharmacology & Pharmacy) ✓
- **Accepts reviews**: Yes ✓
- **Relevance to NP + cancer**: HIGH - natural medicines, pharmacology ✓
- **STATUS**: EXCELLENT MATCH ✓✓
- **URL**: https://www.sciencedirect.com/journal/chinese-journal-of-natural-medicines

### 🥈 2. Planta Medica (Thieme)
- **IF**: ~2.5 (JCR 2023) ✓
- **SCIE**: Yes ✓
- **Free for authors**: Yes (hybrid; subscription submissions free) ✓
- **Scopus Q**: Q1-Q2 (Pharmacology & Pharmacy) ✓
- **Accepts reviews**: Yes ✓
- **Relevance to NP + cancer**: HIGH - natural products from plants ✓
- **STATUS**: EXCELLENT MATCH ✓✓
- **URL**: https://www.thieme-connect.com/products/ejournals/journal/0031-9274

### 🥉 3. Toxicology in Vitro (Elsevier)
- **IF**: ~3.0 (JCR 2023) ✓
- **SCIE**: Yes ✓
- **Free for authors**: Yes (hybrid; subscription submissions free) ✓
- **Scopus Q**: Q1-Q2 (Toxicology) ✓
- **Accepts reviews**: Yes ✓
- **Relevance to NP + cancer**: GOOD - in vitro cytotoxicity studies of NPs
- **STATUS**: QUALIFIES ✓
- **URL**: https://www.sciencedirect.com/journal/toxicology-in-vitro

### 4. Drug and Chemical Toxicology (Taylor & Francis)
- **IF**: ~3.4 (JCR 2023) ✓
- **SCIE**: Yes ✓
- **Free for authors**: Yes (hybrid; subscription submissions free) ✓
- **Scopus Q**: Q2 (Toxicology/Pharmacology) ✓
- **Accepts reviews**: Yes ✓
- **Relevance to NP + cancer**: GOOD - chemical toxicology of drugs and natural compounds
- **STATUS**: QUALIFIES ✓
- **URL**: https://www.tandfonline.com/journals/idct20

### 5. Molecular Biology Reports (Springer)
- **IF**: 3.2 (JCR 2025, VERIFIED from Springer website) ✓
- **SCIE**: Yes ✓
- **Free for authors**: Yes (hybrid; subscription submissions free) ✓
- **Scopus Q**: Q2 (Biology/Molecular Biology) ✓
- **Accepts reviews**: Yes ✓
- **Relevance to NP + cancer**: MODERATE - publishes molecular mechanisms, could fit if review focuses on molecular pathways of NPs against breast cancer
- **STATUS**: QUALIFIES ✓
- **URL**: https://link.springer.com/journal/11033

### 6. Cytotechnology (Springer)
- **IF**: 2.2 (JCR 2025, VERIFIED from Springer website) ✓
- **SCIE**: Yes ✓
- **Free for authors**: Yes (hybrid; subscription submissions free) ✓
- **Scopus Q**: Q2 (Cell Biology/Biotechnology) ✓
- **Accepts reviews**: Yes ✓
- **Relevance to NP + cancer**: MODERATE-LOW - cell culture/biotechnology focus; could fit if review focuses on in vitro cell culture methods for testing NPs against breast cancer
- **STATUS**: QUALIFIES (marginal relevance) ✓
- **URL**: https://link.springer.com/journal/10616

---

## REJECTED JOURNALS

| Journal | Publisher | Reason |
|---------|-----------|--------|
| Drug Development Research | Wiley | IF ~1.5 - BELOW 2.0 |
| Phytotherapy Research | Wiley | IF ~6.1 - TOO HIGH (also excluded per context) |
| Clinical & Exp Pharmacol Physiol | Wiley | DISCONTINUED ~2023 |
| Biopharmaceutics & Drug Disposition | Wiley | IF ~2.1 borderline but LOW relevance to NP+cancer; primarily pharmacokinetics |
| Pharmaceutical Statistics | Wiley | IF ~1.7 - BELOW 2.0 |
| Archives of Pharmacal Research | Springer | IF 8.2 - TOO HIGH |
| In Vitro Cell Dev Biol - Animal | Springer | IF 2.0 borderline; likely Q3 Scopus - may not meet Q1/Q2 |
| Journal Pharmacol & Toxicol Methods | Elsevier | IF ~2.2 but methodology-focused; low relevance |
| Drug Research | Thieme | IF ~1.4 - BELOW 2.0 |

---

## IMPORTANT CAVEATS

1. **IF values for non-Springer journals** are based on training knowledge + Wikipedia data (2018-2020). **Verify current IF from JCR 2023/2024 before submission.**
2. **Scopus Q rankings** are approximate and should be verified on Scopus/ScimagoJR.
3. **"Free for subscription submissions"** is standard policy for ALL hybrid journals at these publishers (Springer, Elsevier, T&F, Thieme). No page charges or color fees for subscription-track papers.
4. **Relevance assessment is subjective.** Chinese Journal of Natural Medicines and Planta Medica are the strongest topical matches. Toxicology in Vitro and Drug and Chemical Toxicology are good for cytotoxicity-focused reviews.
5. **In Vitro Cell Dev Biol - Animal** (IF 2.0) is borderline on both IF and Scopus ranking - verify before targeting.
