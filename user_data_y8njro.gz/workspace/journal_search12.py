#!/usr/bin/env python3
"""Final verification of key journals."""

import urllib.request
import json
import re
import time

def fetch_url(url, timeout=15):
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"
        })
        response = urllib.request.urlopen(req, timeout=timeout)
        return response.read().decode("utf-8", errors="ignore")
    except Exception as e:
        return f"ERROR: {e}"

def get_wikipedia_full(wiki_name):
    """Get full Wikipedia page text."""
    url = f"https://en.wikipedia.org/wiki/{wiki_name}"
    html = fetch_url(url)
    if html.startswith("ERROR"):
        return None
    text = re.sub(r'<[^>]+>', ' ', html)
    text = re.sub(r'&#\d+;', '', text)
    text = re.sub(r'&\w+;', ' ', text)
    text = re.sub(r'\s+', ' ', text)
    return text

# Try to find Journal of Natural Medicines Scopus quartile
print("=== Journal of Natural Medicines - Scopus verification ===")
# Try Scopus search
url = "https://www.scopus.com/sourceid/25674"
html = fetch_url(url)
if not html.startswith("ERROR"):
    text = re.sub(r'<[^>]+>', ' ', html)
    text = re.sub(r'\s+', ' ', text)
    print(f"  Scopus page content (first 500 chars): {text[:500]}")
else:
    print(f"  Scopus error: {html[:100]}")

print()

# Try to find more journals with IF 2.0-3.0 in natural products
print("=== Checking more potential candidates ===")

# Check some T&F journals
tf_journals = [
    ("Pharmaceutical Biology", "Pharmaceutical_Biology"),
    ("Journal of Asian Natural Products Research", "Journal_of_Asian_Natural_Products_Research"),
    ("Natural Product Research", "Natural_Product_Research"),
]

for display, wiki in tf_journals:
    text = get_wikipedia_full(wiki)
    if text:
        if_match = re.search(r'Impact factor\s+(\d+\.?\d*)', text)
        has_sci = 'SCIE' in text or 'Science Citation Index' in text
        has_esci = 'ESCI' in text or 'Emerging Sources' in text
        
        if_val = if_match.group(1) if if_match else "N/A"
        print(f"  {display}: IF={if_val}, SCIE={has_sci}, ESCI={has_esci}")
    else:
        print(f"  {display}: Wikipedia not found")
    time.sleep(0.3)

print()

# Check some Bentham Science journals
print("=== Checking Bentham Science journals ===")
bentham_journals = [
    ("Current Pharmaceutical Design", "Current_Pharmaceutical_Design"),
    ("Current Drug Targets", "Current_Drug_Targets"),
    ("Current Medicinal Chemistry", "Current_Medicinal_Chemistry"),
    ("Current Cancer Drug Targets", "Current_Cancer_Drug_Targets"),
]

for display, wiki in bentham_journals:
    text = get_wikipedia_full(wiki)
    if text:
        if_match = re.search(r'Impact factor\s+(\d+\.?\d*)', text)
        has_sci = 'SCIE' in text or 'Science Citation Index' in text
        has_esci = 'ESCI' in text or 'Emerging Sources' in text
        
        if_val = if_match.group(1) if if_match else "N/A"
        in_range = False
        if if_match:
            try:
                in_range = 2.0 <= float(if_val) <= 3.0
            except:
                pass
        marker = "✓" if in_range else "✗"
        print(f"  {display}: IF={if_val} {marker}, SCIE={has_sci}, ESCI={has_esci}")
    else:
        print(f"  {display}: Wikipedia not found")
    time.sleep(0.3)

print()

# Check some SAGE journals
print("=== Checking SAGE journals ===")
sage_journals = [
    ("Integrative Cancer Therapies", "Integrative_Cancer_Therapies"),
    ("Integrative Medicine Research", "Integrative_Medicine_Research"),
    ("Pharmacognosy Magazine", "Pharmacognosy_Magazine"),
]

for display, wiki in sage_journals:
    text = get_wikipedia_full(wiki)
    if text:
        if_match = re.search(r'Impact factor\s+(\d+\.?\d*)', text)
        has_sci = 'SCIE' in text or 'Science Citation Index' in text
        has_esci = 'ESCI' in text or 'Emerging Sources' in text
        
        if_val = if_match.group(1) if if_match else "N/A"
        in_range = False
        if if_match:
            try:
                in_range = 2.0 <= float(if_val) <= 3.0
            except:
                pass
        marker = "✓" if in_range else "✗"
        print(f"  {display}: IF={if_val} {marker}, SCIE={has_sci}, ESCI={has_esci}")
    else:
        print(f"  {display}: Wikipedia not found")
    time.sleep(0.3)

print()

# Check some Elsevier journals
print("=== Checking Elsevier journals ===")
elsevier_journals = [
    ("Phytochemistry", "Phytochemistry"),
    ("Biochemical Systematics and Ecology", "Biochemical_Systematics_and_Ecology"),
    ("South African Journal of Botany", "South_African_Journal_of_Botany"),
]

for display, wiki in elsevier_journals:
    text = get_wikipedia_full(wiki)
    if text:
        if_match = re.search(r'Impact factor\s+(\d+\.?\d*)', text)
        has_sci = 'SCIE' in text or 'Science Citation Index' in text
        has_esci = 'ESCI' in text or 'Emerging Sources' in text
        
        if_val = if_match.group(1) if if_match else "N/A"
        in_range = False
        if if_match:
            try:
                in_range = 2.0 <= float(if_val) <= 3.0
            except:
                pass
        marker = "✓" if in_range else "✗"
        print(f"  {display}: IF={if_val} {marker}, SCIE={has_sci}, ESCI={has_esci}")
    else:
        print(f"  {display}: Wikipedia not found")
    time.sleep(0.3)
