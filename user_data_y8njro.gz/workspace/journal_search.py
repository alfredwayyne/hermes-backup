#!/usr/bin/env python3
"""Search for journal metrics using Crossref API and other sources."""

import urllib.request
import json
import re
import time

def search_crossref(journal_name):
    """Get basic info from Crossref."""
    try:
        encoded = journal_name.replace(" ", "%20")
        url = f"https://api.crossref.org/journals/{encoded}"
        req = urllib.request.Request(url, headers={"User-Agent": "JournalResearch/1.0 (mailto:test@example.com)"})
        response = urllib.request.urlopen(req, timeout=10)
        data = json.loads(response.read())
        info = data.get("message", {})
        return {
            "issn": info.get("ISSN", []),
            "publisher": info.get("publisher", "Unknown"),
            "subject": info.get("subject", []),
        }
    except Exception as e:
        return {"error": str(e)[:100]}

def search_bing(query):
    """Search via Bing and extract text snippets."""
    try:
        encoded = query.replace(" ", "+")
        url = f"https://www.bing.com/search?q={encoded}"
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml",
            "Accept-Language": "en-US,en;q=0.9",
        })
        response = urllib.request.urlopen(req, timeout=15)
        html = response.read().decode("utf-8", errors="ignore")
        # Remove HTML tags
        text = re.sub(r'<[^>]+>', ' ', html)
        text = re.sub(r'\s+', ' ', text)
        return text[:3000]
    except Exception as e:
        return f"Error: {str(e)[:100]}"

# Test with a few journals
journals = [
    "Phytochemistry Letters",
    "Journal of Ethnopharmacology",
]

for j in journals:
    print(f"\n=== {j} ===")
    cr = search_crossref(j)
    print(f"Crossref: {json.dumps(cr, indent=2)[:500]}")
    time.sleep(0.5)

# Also try searching via Bing
for j in ["Phytochemistry Letters impact factor 2024"]:
    print(f"\n=== Bing: {j} ===")
    result = search_bing(j)
    # Find relevant lines
    for segment in result.split('.'):
        segment = segment.strip()
        if any(kw in segment.lower() for kw in ['impact factor', 'if=', 'quartile', 'q1', 'q2', 'scie', 'esci', 'scopus']):
            if 10 < len(segment) < 300:
                print(f"  {segment}")
