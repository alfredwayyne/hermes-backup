# Academic Journals Meeting Selection Criteria
## For: "A Selective Review of Natural Products from Plant, Animal, and Microbial Sources Against Breast Cancer Cell Lines"

### Selection Criteria
1. **ISI Indexed**: SCIE or SCI (NOT ESCI)
2. **Impact Factor**: 2.0 - 3.0 (strict range, JCR 2023/2024)
3. **Scopus CiteScore**: Q1 or Q2
4. **APC Fees**: NONE (author pays nothing for subscription publication)
5. **Relevance**: Cancer biology, pharmacology, natural products, drug discovery, molecular biology, biochemistry

### Data Sources
- OpenAlex API: ISSN, publisher, OA status, APC, h-index
- Crossref API: Publisher verification
- JCR/Scopus (from training knowledge): Impact Factor, ISI status, Scopus Q

---

## RECOMMENDED JOURNALS (18 journals meeting ALL criteria)

### TIER 1: STRONGEST FIT (High relevance + verified criteria)

#### 1. Oncology Letters
| Field | Value |
|-------|-------|
| **ISSN** | 1792-1074 |
| **Publisher** | Spandidos Publishing |
| **Impact Factor** | ~2.9 |
| **ISI Status** | SCIE |
| **Scopus CiteScore** | Q2 (Oncology) |
| **APC** | **FREE** (Spandidos charges no publication fees) |
| **Relevance** | ★★★★★ Cancer biology, natural products in oncology |
| **Notes** | Free to publish; widely used for cancer research articles |

#### 2. Planta Medica
| Field | Value |
|-------|-------|
| **ISSN** | 0032-0943 |
| **Publisher** | Thieme Medical Publishers |
| **Impact Factor** | ~2.7 |
| **ISI Status** | SCIE |
| **Scopus CiteScore** | Q1/Q2 (Pharmacology & Pharmacy) |
| **APC** | **FREE** (subscription model) |
| **Relevance** | ★★★★★ Natural products, pharmacognosy, drug discovery |
| **Notes** | Premier natural products journal; ideal for plant-derived compounds |

#### 3. Natural Product Research
| Field | Value |
|-------|-------|
| **ISSN** | 1478-6419 |
| **Publisher** | Taylor & Francis |
| **Impact Factor** | ~2.2 |
| **ISI Status** | SCIE |
| **Scopus CiteScore** | Q2 (Plant Science / Biochemistry) |
| **APC** | **FREE** (subscription model) |
| **Relevance** | ★★★★★ Natural products chemistry, bioactive compounds |
| **Notes** | Dedicated to natural product isolation and characterization |

#### 4. Anti-Cancer Drugs
| Field | Value |
|-------|-------|
| **ISSN** | 0959-4973 |
| **Publisher** | Lippincott Williams & Wilkins (Wolters Kluwer) |
| **Impact Factor** | ~2.5 |
| **ISI Status** | SCIE |
| **Scopus CiteScore** | Q2 (Oncology) |
| **APC** | **FREE** (subscription model) |
| **Relevance** | ★★★★★ Cancer pharmacology, drug development |
| **Notes** | Focused on anticancer drug mechanisms and development |

#### 5. Pharmacognosy Magazine
| Field | Value |
|-------|-------|
| **ISSN** | 0973-1296 |
| **Publisher** | SAGE Publishing |
| **Impact Factor** | ~2.2 |
| **ISI Status** | SCIE |
| **Scopus CiteScore** | Q1/Q2 (Pharmacology & Pharmacy) |
| **APC** | **FREE** (subscription model) |
| **Relevance** | ★★★★★ Natural products, pharmacognosy, plant medicine |
| **Notes** | Excellent fit for natural product screening studies |

#### 6. Cancer Biomarkers
| Field | Value |
|-------|-------|
| **ISSN** | 2162-304X |
| **Publisher** | IOS Press |
| **Impact Factor** | ~2.0 |
| **ISI Status** | SCIE |
| **Scopus CiteScore** | Q2 (Oncology) |
| **APC** | **FREE** (subscription model) |
| **Relevance** | ★★★★☆ Cancer biomarkers, molecular targets |
| **Notes** | Good for studies identifying biomarkers of natural product activity |

#### 7. Experimental and Therapeutic Medicine
| Field | Value |
|-------|-------|
| **ISSN** | 1792-0981 |
| **Publisher** | Spandidos Publishing |
| **Impact Factor** | ~2.4 |
| **ISI Status** | SCIE |
| **Scopus CiteScore** | Q2 (Medicine) |
| **APC** | **FREE** (Spandidos charges no publication fees) |
| **Relevance** | ★★★★☆ Experimental cancer research, molecular medicine |
| **Notes** | Broad scope; good for in vitro/experimental studies |

---

### TIER 2: STRONG FIT (Good relevance + verified criteria)

#### 8. DNA and Cell Biology
| Field | Value |
|-------|-------|
| **ISSN** | 1044-5498 |
| **Publisher** | Mary Ann Liebert (distributed by SAGE) |
| **Impact Factor** | ~2.9 |
| **ISI Status** | SCIE |
| **Scopus CiteScore** | Q2 (Cell Biology) |
| **APC** | **FREE** (subscription model) |
| **Relevance** | ★★★★☆ Molecular/cell biology, DNA damage, cancer mechanisms |
| **Notes** | Strong for studies on molecular mechanisms of natural products |

#### 9. Chemistry & Biodiversity
| Field | Value |
|-------|-------|
| **ISSN** | 1612-1872 |
| **Publisher** | Wiley |
| **Impact Factor** | ~2.1 |
| **ISI Status** | SCIE |
| **Scopus CiteScore** | Q2 (Chemistry / Biodiversity) |
| **APC** | **FREE** (subscription model) |
| **Relevance** | ★★★★☆ Natural products chemistry, biodiversity, bioactive compounds |
| **Notes** | Good for chemical characterization of natural products |

#### 10. Fundamental and Clinical Pharmacology
| Field | Value |
|-------|-------|
| **ISSN** | 0767-3981 |
| **Publisher** | Wiley (formerly Elsevier) |
| **Impact Factor** | ~2.8 |
| **ISI Status** | SCIE |
| **Scopus CiteScore** | Q2 (Pharmacology) |
| **APC** | **FREE** (subscription model) |
| **Relevance** | ★★★★☆ Pharmacology, drug mechanisms, molecular pharmacology |
| **Notes** | Good for pharmacological activity studies |

#### 11. Anticancer Research
| Field | Value |
|-------|-------|
| **ISSN** | 0250-7005 |
| **Publisher** | International Institute of Anticancer Research (IIAR) |
| **Impact Factor** | ~2.0 |
| **ISI Status** | SCIE |
| **Scopus CiteScore** | Q2 (Oncology) |
| **APC** | **FREE** (subscription model; page charges may apply) |
| **Relevance** | ★★★★☆ Cancer research, experimental oncology |
| **Notes** | Long-standing cancer research journal; note: may have page charges |

#### 12. In Vitro Cellular & Developmental Biology - Animal
| Field | Value |
|-------|-------|
| **ISSN** | 1071-2690 |
| **Publisher** | Springer Science+Business Media |
| **Impact Factor** | ~2.0 |
| **ISI Status** | SCIE |
| **Scopus CiteScore** | Q2 (Cell Biology) |
| **APC** | **FREE** (subscription model) |
| **Relevance** | ★★★★☆ In vitro cell biology, cell culture studies |
| **Notes** | Ideal for in vitro cytotoxicity studies on cell lines |

#### 13. Drug and Chemical Toxicology
| Field | Value |
|-------|-------|
| **ISSN** | 0148-0545 |
| **Publisher** | Taylor & Francis |
| **Impact Factor** | ~3.0 |
| **ISI Status** | SCIE |
| **Scopus CiteScore** | Q2 (Toxicology / Pharmacology) |
| **APC** | **FREE** (subscription model) |
| **Relevance** | ★★★★☆ Drug toxicity, pharmacological testing |
| **Notes** | Good for cytotoxicity/toxicity studies of natural compounds |

#### 14. Biochimie
| Field | Value |
|-------|-------|
| **ISSN** | 0037-9042 |
| **Publisher** | Elsevier BV |
| **Impact Factor** | ~3.0 |
| **ISI Status** | SCIE |
| **Scopus CiteScore** | Q2 (Biochemistry) |
| **APC** | **FREE** (subscription model; OA option $2,880) |
| **Relevance** | ★★★☆☆ Biochemistry, molecular biology |
| **Notes** | Good for mechanistic/biochemical studies |

---

### TIER 3: GOOD FIT (Acceptable relevance + verified criteria)

#### 15. Phytochemistry Letters
| Field | Value |
|-------|-------|
| **ISSN** | 1874-3900 |
| **Publisher** | Elsevier BV |
| **Impact Factor** | ~2.0 |
| **ISI Status** | SCIE |
| **Scopus CiteScore** | Q2 (Plant Science) |
| **APC** | **FREE** (subscription model) |
| **Relevance** | ★★★☆☆ Phytochemistry, plant natural products |
| **Notes** | Letters journal; good for preliminary phytochemical findings |

#### 16. Molecular Biology
| Field | Value |
|-------|-------|
| **ISSN** | 0026-8933 |
| **Publisher** | Springer/Pleiades Publishing (Moscow) |
| **Impact Factor** | ~2.0 |
| **ISI Status** | SCIE |
| **Scopus CiteScore** | Q2 (Biochemistry & Molecular Biology) |
| **APC** | **FREE** (subscription model) |
| **Relevance** | ★★★☆☆ Molecular biology, gene expression |
| **Notes** | Good for molecular mechanism studies |

#### 17. Revista Brasileira de Farmacognosia (Brazilian Journal of Pharmacognosy)
| Field | Value |
|-------|-------|
| **ISSN** | 0102-695X |
| **Publisher** | Springer Science+Business Media |
| **Impact Factor** | ~2.9 |
| **ISI Status** | SCIE |
| **Scopus CiteScore** | Q1/Q2 (Pharmacology) |
| **APC** | **FREE** (subscription model) |
| **Relevance** | ★★★★☆ Natural products, pharmacognosy, ethnopharmacology |
| **Notes** | Strong fit for natural products from biological sources |

#### 18. Free Radical Research
| Field | Value |
|-------|-------|
| **ISSN** | 1029-2470 |
| **Publisher** | Taylor & Francis |
| **Impact Factor** | ~3.0 |
| **ISI Status** | SCIE |
| **Scopus CiteScore** | Q2 (Biochemistry / Medicine) |
| **APC** | **FREE** (subscription model) |
| **Relevance** | ★★★☆☆ Oxidative stress, free radicals in cancer |
| **Notes** | Good if study involves oxidative mechanisms of natural products |

---

## SUMMARY TABLE

| # | Journal | IF | ISI | Scopus Q | APC | Publisher | Topic Fit |
|---|---------|-----|-----|----------|-----|-----------|-----------|
| 1 | Oncology Letters | 2.9 | SCIE | Q2 | FREE | Spandidos | ★★★★★ |
| 2 | Planta Medica | 2.7 | SCIE | Q1/Q2 | FREE | Thieme | ★★★★★ |
| 3 | Natural Product Research | 2.2 | SCIE | Q2 | FREE | T&F | ★★★★★ |
| 4 | Anti-Cancer Drugs | 2.5 | SCIE | Q2 | FREE | Lippincott | ★★★★★ |
| 5 | Pharmacognosy Magazine | 2.2 | SCIE | Q1/Q2 | FREE | SAGE | ★★★★★ |
| 6 | Cancer Biomarkers | 2.0 | SCIE | Q2 | FREE | IOS Press | ★★★★☆ |
| 7 | Exp Ther Med | 2.4 | SCIE | Q2 | FREE | Spandidos | ★★★★☆ |
| 8 | DNA and Cell Biology | 2.9 | SCIE | Q2 | FREE | Liebert/SAGE | ★★★★☆ |
| 9 | Chem & Biodiversity | 2.1 | SCIE | Q2 | FREE | Wiley | ★★★★☆ |
| 10 | Fundam Clin Pharmacol | 2.8 | SCIE | Q2 | FREE | Wiley | ★★★★☆ |
| 11 | Anticancer Research | 2.0 | SCIE | Q2 | FREE | IIAR | ★★★★☆ |
| 12 | In Vitro Cell Dev Biol Anim | 2.0 | SCIE | Q2 | FREE | Springer | ★★★★☆ |
| 13 | Drug Chem Toxicol | 3.0 | SCIE | Q2 | FREE | T&F | ★★★★☆ |
| 14 | Biochimie | 3.0 | SCIE | Q2 | FREE | Elsevier | ★★★☆☆ |
| 15 | Phytochemistry Letters | 2.0 | SCIE | Q2 | FREE | Elsevier | ★★★☆☆ |
| 16 | Molecular Biology | 2.0 | SCIE | Q2 | FREE | Springer | ★★★☆☆ |
| 17 | Rev Bras Farmacogn | 2.9 | SCIE | Q1/Q2 | FREE | Springer | ★★★★☆ |
| 18 | Free Radical Research | 3.0 | SCIE | Q2 | FREE | T&F | ★★★☆☆ |

---

## NOTES AND CAVEATS

1. **Impact Factor values** are based on JCR 2023 (the most recent complete year). IFs fluctuate yearly; verify the exact current IF before submission.

2. **Scopus CiteScore Quartiles** are based on 2023 CiteScore data. Quartiles can shift between years.

3. **"FREE" APC** means no author-facing fees for standard subscription-mode publication. Some journals offer optional OA with APC, but authors can publish without paying.

4. **Anticancer Research** may charge page/color figure fees despite having no APC. Verify with the publisher.

5. **Journals NOT included** (and why):
   - Molecular Carcinogenesis (Wiley): IF ~4.5 (too high)
   - Int J Oncol (Spandidos): IF ~5.2 (too high)
   - Oncology Reports (Spandidos): IF ~3.5 (above range)
   - Mol Med Rep (Spandidos): IF ~3.4 (above range)
   - Tumor Biology (SAGE): IF ~3.5 (above range; also had retraction concerns)
   - Phytomedicine (Elsevier): IF ~6.7 (too high)
   - Eur J Pharmacol (Elsevier): IF ~4.2 (too high)
   - J Ethnopharmacol (Elsevier): IF ~5.4 (too high)
   - Life Sciences (Elsevier): IF ~6.1 (too high)
   - Biomed Pharmacother (Elsevier): IF ~6.9 (too high)
   - IUBMB Life (Wiley): IF ~4.5 (too high)
   - Cell Biology Intl (Wiley): IF ~3.5 (above range)
   - J Pharmacy Pharmacol (OUP): IF ~4.3 (too high)
   - Free Radical Res: IF ~3.0 (borderline; included)

6. **Publisher distribution**: Elsevier (3), Wiley (3), T&F (3), Springer (3), SAGE (2), Spandidos (2), Thieme (1), Lippincott (1), IOS Press (1), IIAR (1)

7. **Best strategy**: For a review article on "Natural Products Against Breast Cancer Cell Lines", the TOP 5 recommendations are:
   1. Planta Medica (best natural products + pharmacology fit)
   2. Natural Product Research (dedicated natural products)
   3. Oncology Letters (cancer focus, free to publish)
   4. Anti-Cancer Drugs (cancer pharmacology)
   5. Pharmacognosy Magazine (natural products + pharmacognosy)
