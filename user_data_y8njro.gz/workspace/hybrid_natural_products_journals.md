# HYBRID Journals for Natural Products Research — IF ≥ 2.0

**Purpose:** For a review article: *"A Selective Review of Natural Products from Plant, Animal, and Microbial Sources Against Breast Cancer Cell Lines"*

**Criteria:** HYBRID (both subscription + OA options), IF ≥ 2.0, SCIE/SCI indexed, Scopus Q1/Q2

---

## Summary Table

| # | Journal Name | Publisher | IF (Latest JCR) | ISI Status | Scopus Q | Hybrid? | Reviews Accepted | Best Fit for Review? |
|---|-------------|-----------|-----------------|------------|----------|---------|-----------------|---------------------|
| 1 | **Phytomedicine** | Elsevier | ~11.3 | SCIE | Q1 | ✅ Yes | ✅ Yes | ⭐⭐⭐ Excellent |
| 2 | **Phytotherapy Research** | Wiley | ~6.7 | SCIE | Q1 | ✅ Yes | ✅ Yes | ⭐⭐⭐ Excellent |
| 3 | **Journal of Ethnopharmacology** | Elsevier | ~5.4 | SCIE | Q1 | ✅ Yes | ✅ Yes | ⭐⭐⭐ Excellent |
| 4 | **Journal of Natural Products** | ACS | ~5.1 | SCI/SCIE | Q1 | ✅ Yes (ACS AuthorChoice) | ✅ Yes | ⭐⭐⭐ Excellent |
| 5 | **Chemico-Biological Interactions** | Elsevier | ~5.2 | SCIE | Q1 | ✅ Yes | ✅ Yes | ⭐⭐ Good |
| 6 | **Journal of Pharmacy and Pharmacology** | Oxford University Press | ~4.1 | SCIE | Q1 | ✅ Yes (OUP OA option) | ✅ Yes | ⭐⭐ Good |
| 7 | **Phytochemistry** | Elsevier | ~3.5 | SCIE | Q1 | ✅ Yes | ✅ Yes | ⭐⭐ Good |
| 8 | **Fitoterapia** | Elsevier | ~3.4 | SCIE | Q1 | ✅ Yes | ✅ Yes | ⭐⭐ Good |
| 9 | **Pharmaceutical Biology** | Taylor & Francis | ~3.3 | SCIE | Q2 | ✅ Yes (Open Select) | ✅ Yes | ⭐⭐ Good |
| 10 | **Bioorganic & Medicinal Chemistry** | Elsevier | ~3.3 | SCIE | Q2 | ✅ Yes | ✅ Yes | ⭐ Acceptable |
| 11 | **Planta Medica** | Thieme | ~2.7 | SCI | Q1/Q2 | ✅ Yes | ✅ Yes | ⭐ Acceptable |
| 12 | **Journal of Natural Medicines** | Springer | ~2.6 | SCIE | Q2 | ✅ Yes (Springer Open Choice) | ✅ Yes | ⭐ Acceptable |
| 13 | **Natural Product Research** | Taylor & Francis | ~2.2 | SCIE | Q2 | ✅ Yes (Open Select) | ✅ Yes | ⭐ Acceptable |

---

## Detailed Journal Profiles

### 1. Phytomedicine
- **Publisher:** Elsevier
- **ISSN:** 0944-7113 (print) / 1618-095X (web)
- **Impact Factor:** ~11.3 (2025 JCR) — previously 6.7 (2021)
- **ISI Status:** SCIE (Science Citation Index Expanded)
- **Scopus:** Q1 in Pharmacology & Pharmacy
- **Hybrid:** ✅ Yes — Elsevier hybrid journal with OA option (article processing charge ~$3,200 USD)
- **Reviews:** ✅ Yes — actively publishes systematic reviews and narrative reviews
- **Scope:** Pharmacology, toxicology, clinical efficacy of phytotherapeutics, natural products
- **Frequency:** Monthly
- **Notes:** Top-ranked journal for phytomedicine research. Very well-suited for a breast cancer natural products review.

### 2. Phytotherapy Research
- **Publisher:** John Wiley & Sons
- **ISSN:** 0951-418X (print) / 1099-1573 (web)
- **Impact Factor:** ~6.7 (2023 JCR) — previously 6.338 (2021)
- **ISI Status:** SCIE
- **Scopus:** Q1 in Chemistry (Medicinal) and Pharmacology & Pharmacy
- **Hybrid:** ✅ Yes — Wiley Open Access option available (OA APC ~$3,990 USD)
- **Reviews:** ✅ Yes — publishes reviews, original research, short communications, letters
- **Scope:** Medicinal plant research, pharmacology, toxicology, clinical applications of herbs/natural products
- **Frequency:** Monthly
- **Notes:** Highly relevant for review articles on natural products against cancer.

### 3. Journal of Ethnopharmacology
- **Publisher:** Elsevier
- **ISSN:** 0378-8741 (print) / 1872-7573 (web)
- **Impact Factor:** ~5.4 (2023 JCR) — previously 4.36 (2020)
- **ISI Status:** SCIE
- **Scopus:** Q1 in Pharmacology & Pharmacy
- **Hybrid:** ✅ Yes — Elsevier hybrid with OA option
- **Reviews:** ✅ Yes — publishes review articles regularly
- **Scope:** Ethnopharmacology, traditional medicine, natural products with biological activity
- **Frequency:** 18 issues/year
- **Notes:** Strong fit if review covers traditional/ethnobotanical perspectives alongside modern pharmacology.

### 4. Journal of Natural Products
- **Publisher:** American Chemical Society (ACS) + American Society of Pharmacognosy (ASP)
- **ISSN:** 0163-3864 (print) / 1520-6025 (web)
- **Impact Factor:** ~5.1 (2022 JCR)
- **ISI Status:** SCI (Science Citation Index) / SCIE
- **Scopus:** Q1 in Organic Chemistry, Pharmacology & Pharmacy
- **Hybrid:** ✅ Yes — ACS AuthorChoice hybrid model (OA option available)
- **Reviews:** ✅ Yes — publishes reviews and perspectives
- **Scope:** Chemistry and biochemistry of naturally occurring compounds; isolation, structure elucidation, biological evaluation
- **Frequency:** Monthly
- **Notes:** Premier journal for natural product chemistry. Excellent for a review of NPs with anticancer activity.

### 5. Chemico-Biological Interactions
- **Publisher:** Elsevier
- **ISSN:** 0009-2797 (print) / 1872-7786 (web)
- **Impact Factor:** ~5.2 (2023 JCR) — previously 5.192 (2020)
- **ISI Status:** SCIE
- **Scopus:** Q1 in Toxicology, Biochemistry & Molecular Biology
- **Hybrid:** ✅ Yes — Elsevier hybrid with OA option
- **Reviews:** ✅ Yes — publishes review articles
- **Scope:** Chemical-biological interactions, toxicology, molecular pharmacology, drug-natural product interactions
- **Frequency:** Monthly
- **Notes:** Good fit if review emphasizes mechanism of action and chemical-biological interactions of NPs against breast cancer.

### 6. Journal of Pharmacy and Pharmacology
- **Publisher:** Oxford University Press (OUP) / Royal Pharmaceutical Society
- **ISSN:** 0022-3573 (print) / 2042-7158 (web)
- **Impact Factor:** ~4.1 (2023 JCR)
- **ISI Status:** SCIE
- **Scopus:** Q1 in Pharmacology, Pharmacy
- **Hybrid:** ✅ Yes — OUP Optional Open Access
- **Reviews:** ✅ Yes — publishes reviews and research papers
- **Scope:** Pharmacology, pharmaceutics, drug delivery, natural products pharmacology
- **Frequency:** Monthly
- **Notes:** Well-established journal; good for pharmacological evaluation reviews.

### 7. Phytochemistry
- **Publisher:** Elsevier
- **ISSN:** 0031-9422 (print) / 1873-3700 (web)
- **Impact Factor:** ~3.5 (2023 JCR)
- **ISI Status:** SCIE
- **Scopus:** Q1 in Plant Science, Biochemistry
- **Hybrid:** ✅ Yes — Elsevier hybrid with OA option
- **Reviews:** ✅ Yes — publishes review articles
- **Scope:** Chemistry of plant secondary metabolites, biosynthesis, structure elucidation
- **Frequency:** Monthly
- **Notes:** More chemistry-focused. Best if review emphasizes chemical characterization of NPs.

### 8. Fitoterapia
- **Publisher:** Elsevier
- **ISSN:** 0367-326X (print) / 1873-6971 (web)
- **Impact Factor:** ~3.4 (2022 JCR)
- **ISI Status:** SCIE
- **Scopus:** Q1 in Pharmacology, Plant Science
- **Hybrid:** ✅ Yes — Elsevier hybrid with OA option
- **Reviews:** ✅ Yes — publishes review articles
- **Scope:** Pharmacognosy, phytotherapy, biological evaluation of plant extracts and natural products
- **Frequency:** 8 issues/year
- **Notes:** Good for reviews combining phytochemistry with pharmacological screening.

### 9. Pharmaceutical Biology
- **Publisher:** Taylor & Francis
- **ISSN:** 1388-0209 (print) / 1744-5116 (web)
- **Impact Factor:** ~3.3 (2023 JCR)
- **ISI Status:** SCIE
- **Scopus:** Q2 in Pharmacology, Pharmacy
- **Hybrid:** ✅ Yes — Taylor & Francis Open Select
- **Reviews:** ✅ Yes — publishes reviews
- **Scope:** Pharmaceutical biology, pharmacognosy, natural product pharmacology
- **Frequency:** Monthly
- **Notes:** Good mid-tier option. Accepts reviews on natural product biological activities.

### 10. Bioorganic & Medicinal Chemistry
- **Publisher:** Elsevier
- **ISSN:** 0968-0896 (print) / 1464-3391 (web)
- **Impact Factor:** ~3.3 (2023 JCR)
- **ISI Status:** SCIE
- **Scopus:** Q2 in Biochemistry, Organic Chemistry, Medicinal Chemistry
- **Hybrid:** ✅ Yes — Elsevier hybrid with OA option
- **Reviews:** ✅ Yes — publishes reviews
- **Scope:** Medicinal chemistry, organic chemistry, bioorganic chemistry, drug design
- **Frequency:** Semi-monthly
- **Notes:** If review emphasizes SAR and medicinal chemistry of natural products with anticancer activity.

### 11. Planta Medica
- **Publisher:** Thieme Medical Publishers
- **ISSN:** 0032-0943 (print) / 1439-0221 (web)
- **Impact Factor:** ~2.7 (2023 JCR) — previously 2.74 (2018)
- **ISI Status:** SCI (Science Citation Index)
- **Scopus:** Q1 in Integrative & Complementary Medicine, Q2 in Plant Sciences
- **Hybrid:** ✅ Yes — Thieme Open Access option available
- **Reviews:** ✅ Yes — publishes reviews and original research
- **Scope:** Medicinal plants, bioactive natural products, pharmacognosy
- **Frequency:** 18 issues/year
- **Notes:** Official journal of GA (Society for Medicinal Plant and Natural Product Research). Historic journal with strong reputation.

### 12. Journal of Natural Medicines
- **Publisher:** Springer Nature
- **ISSN:** 1861-0374 (print) / 1861-0387 (web)
- **Impact Factor:** ~2.6 (2023 JCR)
- **ISI Status:** SCIE
- **Scopus:** Q2 in Pharmacology, Plant Science
- **Hybrid:** ✅ Yes — Springer Open Choice
- **Reviews:** ✅ Yes — publishes review articles
- **Scope:** Natural product chemistry, pharmacology, biological activities of natural products
- **Frequency:** Quarterly
- **Notes:** Japanese-origin journal with international scope. Good for reviews on bioactive NPs.

### 13. Natural Product Research
- **Publisher:** Taylor & Francis
- **ISSN:** 1478-6419 (print) / 1478-6427 (web)
- **Impact Factor:** ~2.2 (2023 JCR)
- **ISI Status:** SCIE
- **Scopus:** Q2 in Complementary & Alternative Medicine, Plant Science
- **Hybrid:** ✅ Yes — Taylor & Francis Open Select
- **Reviews:** ✅ Yes — publishes reviews
- **Scope:** Natural product chemistry, structure determination, biological activity
- **Frequency:** 24 issues/year
- **Notes:** Good accessible option for natural products research reviews.

---

## Hybrid OA Program Details by Publisher

| Publisher | Hybrid OA Program | Typical APC (USD) |
|-----------|------------------|-------------------|
| **Elsevier** | Open Access articles in hybrid journals | ~$2,800–$4,500 |
| **Wiley** | Wiley Open Access | ~$3,000–$4,500 |
| **ACS** | ACS AuthorChoice | ~$3,000–$4,000 |
| **Springer Nature** | Open Choice | ~$2,990–$3,490 |
| **Thieme** | Thieme Open Access | ~$2,800 |
| **Oxford Univ. Press** | Optional Open Access | ~$3,000–$3,500 |
| **Taylor & Francis** | Open Select | ~$2,950–$3,200 |

---

## Recommendations for Review Article: "Natural Products Against Breast Cancer Cell Lines"

### Tier 1 — High Impact + Strong Fit (IF ≥ 5)
1. **Phytomedicine** (IF ~11.3) — Best overall choice; publishes many cancer-related NP reviews
2. **Phytotherapy Research** (IF ~6.7) — Excellent for clinical/translational perspective
3. **Journal of Ethnopharmacology** (IF ~5.4) — Great if including ethnobotanical/plant/animal sources
4. **Journal of Natural Products** (IF ~5.1) — Premier NP journal; chemistry + biology
5. **Chemico-Biological Interactions** (IF ~5.2) — Good for mechanism-focused reviews

### Tier 2 — Solid Mid-Range (IF 3–5)
6. **Journal of Pharmacy and Pharmacology** (IF ~4.1)
7. **Phytochemistry** (IF ~3.5) — More chemistry-oriented
8. **Fitoterapia** (IF ~3.4)
9. **Pharmaceutical Biology** (IF ~3.3)
10. **Bioorganic & Medicinal Chemistry** (IF ~3.3) — More medicinal chemistry focus

### Tier 3 — Acceptable (IF 2–3)
11. **Planta Medica** (IF ~2.7) — Historic journal, good reputation
12. **Journal of Natural Medicines** (IF ~2.6)
13. **Natural Product Research** (IF ~2.2)

---

## Notes
- All IFs are approximate and based on JCR 2022–2025 data. **Verify current IF before submission** at https://jcr.clarivate.com/
- Scopus Q rankings may shift annually. Verify at https://www.scimagojr.com/
- All 13 journals are confirmed HYBRID (not pure OA like MDPI, Frontiers, Bentham)
- All accept review articles, but check specific submission guidelines for word limits and formatting
- For a review covering plants, animals, AND microbes, **Journal of Ethnopharmacology** or **Phytomedicine** are likely the best thematic fits
- For a chemistry-heavy approach, **Journal of Natural Products** or **Phytochemistry** are preferred
- Generated: August 4, 2026
