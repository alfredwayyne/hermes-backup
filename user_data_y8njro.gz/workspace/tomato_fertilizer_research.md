# Tomato Fertilizer Research: Complete NPK Guide by Growth Stage

## Sources Used
- University of Maryland Extension (UMD) - "Fertilizing Vegetable Gardens" (Updated May 2026)
- University of Maryland Extension - "Growing Tomatoes in a Home Garden" (Updated Nov 2025)
- University of Minnesota Extension - "Growing Tomatoes" 
- University of Maryland Extension - "Garden Fertilizer Basics" (Updated May 2025)
- Royal Horticultural Society (RHS) - "How to Grow Tomatoes"
- Clemson University Extension (HGIC) - "Tomato Factsheet" (Revised Mar 2022)
- MorningChores - "Best Fertilizer for Tomatoes" (Product reviews with NPK data)
- Epic Gardening - "Tomato Fertilizer Facts & How To Use Them Right"

---

## 1. SEEDLING STAGE (Germination to Transplant)

### NPK Ratio: High Phosphorus - 5-10-5 or 10-10-10 (balanced preferred)

**Key Requirements:**
- Seedlings need phosphorus for root development and establishment
- Use a **soluble (water-soluble) fertilizer** mixed with water
- Balanced or slightly phosphorus-heavy formulation preferred
- Avoid high nitrogen at this stage (causes leggy growth)

**Recommended Products:**
- **Miracle-Gro Water Soluble Tomato Plant Food** (18-18-21) - good phosphorus for seedlings
- **Espoma Tomato-tone** (3-4-6) - organic option with calcium
- Diluted liquid fertilizer at half strength for young seedlings

**Specific Rates (from UMD Extension):**
- Fertilize spring seedlings and transplants with a soluble fertilizer mixed with water
- Switch to granular (applied dry) vegetable fertilizer as plants grow

**Application Method:**
- Water-soluble fertilizer diluted in water
- Apply at planting time
- Add compost to planting hole before transplanting

**Timing:** At planting/transplanting time

---

## 2. VEGETATIVE GROWTH STAGE (After Transplant, Before Flowering)

### NPK Ratio: 10-10-10 (balanced) or 4-6-3

**Key Requirements:**
- Moderate nitrogen for leaf and stem growth
- Phosphorus for continued root development
- Balanced NPK formulation

**Specific Rates (from UMD Extension):**
- Tomatoes are "heavy feeders" needing **3 lbs of Nitrogen per 1,000 sq ft** (equivalent to 0.3 lbs / 4.8 oz per 100 sq ft)
- General vegetable recommendation: 2 lbs N per 1,000 sq ft; tomatoes need 50% more

**Organic Options:**
- Cottonseed meal (6-2-1) - approximately 33.3 lbs per 1,000 sq ft to supply 2 lbs N
- Blood meal (12-0-0) - approximately 16.7 lbs per 1,000 sq ft to supply 2 lbs N
- Fish meal (8-10% N)
- Fish emulsion (5% N)
- Composted manure incorporated before planting

**Application Method:**
- Granular fertilizer worked into top 2-4 inches of soil
- Water-in after application

**Timing:** 2-3 weeks after transplanting, before flowering begins

---

## 3. FLOWERING STAGE (Bloom Set to Early Fruit)

### NPK Ratio: 5-10-10 or 8-32-16 (higher P and K, lower N)

**Key Requirements:**
- **Reduce nitrogen** - excess nitrogen at this stage causes:
  - Bushy, leafy plants with fewer flowers
  - Delayed fruit set
  - Lush foliage at expense of fruit production
- **Increase phosphorus** for flower development and fruit set
- **Increase potassium** for fruit quality

**Key Warning (from UMN Extension):**
"Too much nitrogen fertilization will lead to plants that are bushy, leafy, and slow to bear fruit."

**Recommended Products:**
- **Dr. Earth Organic 5 Tomato, Vegetable & Herb Fertilizer** (5-7-3) - phosphorus-rich for flowering
- **Jobe's Organics** (2-5-3) - balanced organic option
- **Espoma Tomato-tone** (3-4-6) - contains 8% calcium to prevent blossom end rot

**Application Method:**
- Side-dress with granular fertilizer 4-6 inches from plant base
- Avoid getting fertilizer on foliage

**Timing:** When first flower clusters appear

---

## 4. FRUITING STAGE (Active Fruit Development to Harvest)

### NPK Ratio: 10-10-10 transitioning to 5-10-10 or 8-32-16 (higher K)

**Key Requirements:**
- **High potassium** is critical for:
  - Fruit size and weight
  - Sugar content and flavor (Brix)
  - Disease resistance
  - Color development
  - Shelf life
- **Moderate phosphorus** for continued root health
- **Moderate nitrogen** - just enough for continued growth

**Specific Rates (from UMN Extension):**
When first fruits start to enlarge, apply alongside the row:
- ½ cup of **46-0-0** (urea), OR
- 1 cup of **27-3-3**, OR
- 3½ cups of **10-3-1**
- Per 100 feet of row

Spread in a 6-inch wide band and scratch into soil surface.

**Recommended Products:**
- **Jack's Classic Tomato Feed** (12-15-30) - very high potassium for fruiting
- **Urban Farm Fertilizers Texas Tomato Food** (5-3-7) - liquid formula with calcium and potassium
- **Neptune's Harvest Tomato and Vegetable Fertilizer** - liquid organic

**Organic Options for High Potassium:**
- Sulphate of potash (0-0-50)
- Kelp meal/seaweed extract
- Wood ash (use sparingly, raises pH)
- Greensand

**Application Method:**
- Foliar feeding with liquid fertilizer every 10-14 days
- Side-dressing every 3-4 weeks
- Diluted fertilizer tea around base of plants

**Timing:** When first fruits start to swell, continue every 2 weeks until harvest

---

## 5. LATE SEASON (Final Ripening, Last Harvest)

### NPK Ratio: 0-0-60 or 2-0-5 (Potassium only, minimal N)

**Key Requirements:**
- **Stop nitrogen completely** - late nitrogen:
  - Encourages succulent new growth vulnerable to frost
  - Delays fruit ripening
  - Interferes with plant winterization (UMD Extension warning)
- **Potassium only** for final fruit ripening and quality

**Key Warning (from UMD Extension):**
"Late summer and early fall fertilization can interfere with plant winterization and encourage succulent late growth that is easily killed in winter."

**Recommended Products:**
- Sulphate of potash (0-0-50) or muriate of potash (0-0-60)
- Kelp/seaweed extract for final feeding
- Diluted high-potassium liquid fertilizer

**Application Method:**
- Light side-dressing or foliar spray
- Minimal amounts at this stage

**Timing:** 2-3 weeks before expected first frost; stop all fertilization at least 2 weeks before frost

---

## CALCIUM REQUIREMENTS (Blossom End Rot Prevention)

### Daily Requirement: 200-600 ppm in nutrient solution; 1.0-1.5% in leaf tissue

**Critical Facts:**
- Blossom end rot (BER) is caused by **calcium deficiency in developing fruit**
- BER is NOT caused by low soil calcium in most cases - it's caused by **irregular watering** that prevents calcium uptake (UMN & RHS Extensions)
- "When soil moisture levels fluctuate during fruit growth, blossom-end rot can develop" (UMN Extension)

**Prevention Methods:**
1. **Consistent watering** - most important factor
2. Add **gypsum** (calcium sulphate) - ¼ cup per planting hole (UMD Extension)
3. Use fertilizers containing calcium:
   - **Calcium nitrate** (15.5-0-0) or (16-0-0) - recommended by Clemson Extension
   - Side-dress 1 lb per 100 sq ft (30 ft of row) 3-4 weeks after planting
   - Espoma Tomato-tone contains **8% calcium**
4. **Do NOT add lime** for calcium - it raises pH too much
5. Crushed eggshells in planting holes (slow release)
6. Foliar calcium sprays during fruit set

**Products:**
- Calcium nitrate (15.5-0-0) - Clemson Extension recommendation
- Espoma Tomato-tone (3-4-6 with 8% calcium)
- CalMag liquid supplements
- Gypsum (calcium sulphate)

---

## MAGNESIUM REQUIREMENTS

### Daily Requirement: 30-50 ppm in nutrient solution; 0.3-0.5% in leaf tissue

**Key Facts:**
- Magnesium is central to chlorophyll molecule (photosynthesis)
- Deficiency shows as interveinal chlorosis on older leaves
- Most soils have adequate magnesium

**Important Warning (UMD Extension):**
"Do not add Epsom salts (magnesium sulfate) to the soil unless soil testing shows a magnesium deficiency."

**Sources:**
- Epsom salts (magnesium sulfate) - only if soil test confirms deficiency
- Dolomitic lime (raises pH - use only if pH also needs adjustment)
- Organic matter/compost
- Kelp/seaweed products contain trace magnesium
- Jack's Classic Tomato Feed (12-15-30) contains magnesium

**Application:**
- If deficiency confirmed: foliar spray 1 tablespoon Epsom salts per gallon of water
- Or soil application 1 tablespoon per gallon of water around base

---

## POTASSIUM REQUIREMENTS (Fruit Quality)

### Daily Requirement: 200-400 ppm in nutrient solution; 2.0-3.5% in leaf tissue

**Key Functions for Fruit Quality:**
- Increases fruit size and weight
- Improves sugar content (Brix) and flavor
- Enhances red color development
- Improves disease resistance
- Extends shelf life and post-harvest quality
- Regulates water balance in plant

**Recommended NPK Ratios for Potassium:**
- Flowering/Fruiting: 5-10-10 or 8-32-16
- Heavy fruiting: 12-15-30 (Jack's Classic)
- Late season: 0-0-50 or 0-0-60 (potash only)

**Potassium Sources:**
- Sulphate of potash (SOP) - 0-0-50, preferred for tomatoes
- Muriate of potash (MOP) - 0-0-60, cheapest but higher chloride
- Kelp meal and seaweed extract
- Wood ash (contains potassium + calcium)
- Greensand (slow release)
- Banana peels (organic garden hack)

**Application Rates:**
- RHS recommends: "Feed every 10-14 days with an organic high potassium liquid fertilizer once the first fruits start to swell"

---

## PHOSPHORUS REQUIREMENTS (Root Development)

### Daily Requirement: 30-60 ppm in nutrient solution; 0.3-0.5% in leaf tissue

**Key Functions:**
- Root development and branching
- Energy transfer (ATP)
- Flower initiation and fruit set
- Seed development
- Early plant establishment

**Warning from UMD Extension:**
"Many Minnesota soils have enough phosphorus. Unless your soil test report specifically recommends additional phosphorus, use a low- or no-phosphorus fertilizer."

**Phosphorus Sources:**
- Bone meal (3-15-0) - organic, slow release
- Rock phosphate (0-3-0) - very slow release
- Superphosphate (0-20-0)
- Soft rock phosphate
- Fish bone meal
- Compost and aged manure

**Application:**
- Incorporate into soil before planting
- Phosphorus is immobile in soil - must be near roots
- Critical at seedling/transplant stage for root establishment

---

## NITROGEN REQUIREMENTS (Vegetative Growth)

### Daily Requirement: 150-250 ppm in nutrient solution; 2.5-4.0% in leaf tissue

**Key Functions:**
- Chlorophyll production (green color)
- Leaf and stem growth
- Protein synthesis
- Overall plant vigor

**Key Warning:**
"Too much nitrogen fertilization will lead to plants that are bushy, leafy, and slow to bear fruit" (UMN Extension)
"Too much nitrogen may also make plants more vulnerable to pest or disease problems" (UMD Extension)

**Nitrogen Sources:**
- **Nitrate-based** (preferred for tomatoes):
  - Calcium nitrate (16-0-0) - also supplies calcium
  - Nitrate of soda (15-0-0)
- **Ammonium-based:**
  - Ammonium sulfate (21-0-0) - also lowers pH
  - Urea (46-0-0) - cheapest, but volatilizes
- **Organic options:**
  - Blood meal (12-0-0)
  - Cottonseed meal (6-2-1)
  - Fish emulsion (5-1-1)
  - Fish meal (8-10% N)
  - Feather meal (12-0-0)

**Application Rate (UMD Extension):**
- Heavy feeders like tomatoes: **3 lbs N per 1,000 sq ft** (equivalent to 4.8 oz per 100 sq ft)
- Using calcium nitrate (16-0-0): 3.2 oz N ÷ 0.16 = 20 oz product per 100 sq ft

---

## COMPLETE FERTILIZER SCHEDULE SUMMARY

| Growth Stage | Timing | NPK Ratio | Application Method | Frequency |
|---|---|---|---|---|
| **Seedling** | At planting | 10-10-10 or 5-10-5 | Water-soluble in water | Once |
| **Vegetative** | 2-3 weeks post-transplant | 10-10-10 (balanced) | Granular side-dress | Once |
| **Flowering** | When flower clusters appear | 5-10-10 or 8-32-16 | Granular side-dress | Every 3-4 weeks |
| **Fruiting** | When first fruits swell | 5-10-10 to 8-32-16 (high K) | Liquid foliar + side-dress | Every 2 weeks |
| **Late Season** | 2-3 weeks before frost | 0-0-50 (K only) | Light side-dress | Once, then stop |

---

## COMMERCIAL TOMATO FERTILIZER PRODUCTS RANKED

### Best Overall: Espoma Tomato-tone (3-4-6)
- NPK: 3-4-6 (balanced, higher K)
- Contains 8% calcium for blossom end rot prevention
- 15 essential nutrients
- Slow-release, won't burn plants
- USDA approved for organic gardening
- Contains Bio-tone beneficial microbes

### Best High-Potassium: Jack's Classic Tomato Feed (12-15-30)
- NPK: 12-15-30 (very high K for fruiting)
- Contains magnesium and calcium
- Professional-grade nutrients
- Fast-acting liquid soluble

### Best Budget Organic: Jobe's Organics (2-5-3)
- NPK: 2-5-3 (phosphorus-rich for roots)
- USDA certified organic, OMRI listed
- Contains Biozome beneficial bacteria
- Improves soil conditions

### Best for Established Plants: Dr. Earth Organic 5 (5-7-3)
- NPK: 5-7-3 (phosphorus-rich)
- Contains Alaskan fishbone, kelp, alfalfa
- 100% organic, no synthetics
- Good for vegetable gardens

### Best Liquid: Urban Farm Texas Tomato Food
- Contains calcium and potassium
- Liquid formula for quick absorption
- Includes mycorrhizae and humic acid

### Best for Seedlings: Miracle-Gro Water Soluble (18-18-18)
- NPK: 18-18-21 (balanced high-analysis)
- Contains 5% magnesium
- Fast-acting, results in 7-14 days
- Use at half strength for seedlings

---

## SOIL pH REQUIREMENT

- **Ideal pH: 6.0-6.5** (Clemson Extension)
- Below 6.0: Add lime (apply 3 months before planting)
- Above 6.5: Add sulfur or acidic organic matter
- Phosphorus availability decreases below pH 5.5 and above 7.5
- Calcium and magnesium availability affected by pH

---

## MICRONUTRIENT REQUIREMENTS FOR TOMATOES

| Micronutrient | Leaf % | Function | Deficiency Symptoms |
|---|---|---|---|
| Iron (Fe) | 0.06-0.15 | Chlorophyll synthesis | Interveinal chlorosis on young leaves |
| Manganese (Mn) | 0.03-0.20 | Enzyme activation | Interveinal chlorosis, brown spots |
| Zinc (Zn) | 0.015-0.060 | Growth hormones | Small, narrow leaves, stunted growth |
| Boron (B) | 0.025-0.050 | Cell wall formation | Hollow stems, poor fruit set |
| Copper (Cu) | 0.005-0.010 | Lignification | Dieback of growing points |
| Molybdenum (Mo) | 0.001-0.005 | Nitrogen metabolism | Leaf curl, yellowing |

**Best Micronutrient Source:** Kelp/seaweed extract foliar spray (contains all trace elements naturally)

---

## KEY WARNINGS FROM UNIVERSITY EXTENSIONS

1. **"More is not better"** - Over-fertilization causes root burn, excessive foliage, and nutrient pollution (UMD)
2. **"Do not fertilize drought-stressed plants"** - Salt damage risk (UMD)
3. **"Late summer fertilization can interfere with plant winterization"** (UMD)
4. **"Too much nitrogen leads to bushy, leafy plants slow to bear fruit"** (UMN)
5. **"Do not use fertilizer containing a weed killer"** - "Weed and Feed" products kill vegetables (UMN)
6. **"Add compost or well-rotted manure before planting"** - Foundation for fertility (RHS, UMN)
7. **"Water consistently"** - Irregular watering causes blossom end rot more than calcium deficiency (RHS)
