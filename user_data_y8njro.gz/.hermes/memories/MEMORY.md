GitHub: mojyjason (Hermes backup repo: mojyjason/Hermesbackup). Has a 12h cron backup job set up (job ID: 5423add7faad).
§
User: Mojtaba. Persian/Farsi speaker. GitHub: github.com/mojyjason
§
Academic researcher writing review articles. Current topic: 'Natural Products from Plant, Animal, and Microbial Sources Against Breast Cancer Cell Lines'. Very strict journal requirements: ISI (SCIE/SCI, NOT ESCI), IF ≥ 2 (prefers 2-3 range), Scopus Q1/Q2 ONLY, ZERO fees (no APC, no page fees, no color fees — will pay nothing). NO Bentham Science. Hybrid journals preferred. Verify IF/Q from SCImago/JCR. Parallel submit to Elsevier, Wiley, Springer, SAGE + alternative publishers. Gets frustrated with inaccurate recommendations.
§
Has Instagram page called 'تربچه' (Torbche) — wants video content with a human-like turnip character.
§
Prefers Persian/Farsi for casual conversation, English for academic/technical work. Environment: cloud server, no GPU, port 22 blocked, uses HTTPS for git.
§
Created 4 cron jobs this session: hermes-backup-12h (backup to GitHub), gaming-news-daily (10 PM Tehran), samsung-news-daily (every 24h), silver-price (every 72h). User prefers Persian responses with emojis and tables.
§
tgju.org is the main source for Iranian market prices (gold, silver, currency). Accessible from this server. Profile pages like /profile/silver_999 have prices in HTML spans. Domestic prices differ 50-100% from international due to sanctions.
§
News digests (gaming, samsung) use Persian translation via deep_translator + cross-source deduplication. Cron jobs run in /opt/venv/bin/python3 - must install packages there with /opt/venv/bin/pip install, not system pip.
§
User's GitHub account (mojyjason) is suspended. Backup cron job fails with 403. User needs to visit https://support.github.com to restore account.