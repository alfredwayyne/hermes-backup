Instagram page: تربچه (Torbche/Turnip) — Farsi page, mascot is cute human-like turnip character. Interested in gaming news (Samsung, general). Tracks silver prices via tgju.org (Iranian market differs from international).
§
Name: Mojtaba (GitHub: mojyjason). Based in Iran. Speaks Persian — respond in Farsi unless asked otherwise. Prefers emojis and structured tables. Physical: oval face, round glasses, full beard, short dark hair.
§
Academic researcher: review on "Natural Products Against Breast Cancer". Journal criteria: ISI SCIE/SCI (NOT ESCI), IF 2-4, Scopus Q1/Q2, ZERO fees (no APC/page/color fees). NO Bentham. Hybrid preferred. Verify IF/Q from SCImago/JCR. Parallel submit to Elsevier, Wiley, Springer, SAGE + others. Gets frustrated with inaccurate recs.
§
Cron jobs: gaming-news-daily (10PM Iran, Farsi translations), samsung-news-daily (24h, Farsi translations), silver-price (72h), hermes-backup-12h. GitHub: mojyjason/Hermesbackup. Has Hermes on desktop, wants Telegram connection.
§
Iranian market prices differ from international (e.g., silver ~61% premium). Uses tgju.org for domestic prices. Very strict about data accuracy — verify everything, never estimate.