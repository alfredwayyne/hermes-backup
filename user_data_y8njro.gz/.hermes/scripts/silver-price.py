#!/usr/bin/env python3
"""
Silver Price Converter
Fetches silver price from tgju.org (Iran) and Yahoo Finance (International).
"""

import json
import urllib.request
import re
import time
from datetime import datetime

def fetch_url(url, timeout=10):
    """Fetch URL content."""
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    }
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.read().decode('utf-8', errors='ignore')
    except Exception as e:
        return None

def get_silver_price_international():
    """Get silver price from Yahoo Finance."""
    try:
        url = "https://query1.finance.yahoo.com/v8/finance/chart/SI=F?interval=1d&range=1d"
        headers = {'User-Agent': 'Mozilla/5.0'}
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
            price = data['chart']['result'][0]['meta']['regularMarketPrice']
            return price
    except Exception as e:
        return None

def get_usd_to_rial():
    """Get USD to IRR exchange rate."""
    try:
        url = "https://api.exchangerate-api.com/v4/latest/USD"
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
            return data['rates'].get('IRR', None)
    except:
        return None

def get_silver_price_iran():
    """Get silver price from tgju.org."""
    try:
        url = "https://www.tgju.org/profile/silver_999"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept-Language': 'fa-IR,fa;q=0.9',
        }
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=15) as resp:
            content = resp.read().decode('utf-8', errors='ignore')
            
            # Find price pattern
            prices = re.findall(r'([\d,]+)', content)
            for p in prices:
                clean = p.replace(',', '')
                if clean.isdigit() and 1000000 < int(clean) < 10000000:
                    return int(clean)
            return None
    except Exception as e:
        return None

def format_number(num):
    """Format number with commas."""
    if num is None:
        return "نامشخص"
    return f"{num:,.0f}"

# Main execution
if __name__ == '__main__':
    print("🥈 در حال دریافت قیمت نقره...", flush=True)
    
    now = datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')
    
    # Get international price
    intl_price = get_silver_price_international()
    
    # Get Iran price
    iran_price = get_silver_price_iran()
    
    # Get exchange rate
    usd_to_rial = get_usd_to_rial()
    
    # Build output
    lines = []
    lines.append("🥈 **قیمت نقره** 🥈")
    lines.append(f"📅 {now}")
    lines.append("")
    
    if intl_price:
        lines.append("**🌍 بین‌المللی:**")
        lines.append(f"• هر اونس: **${intl_price:.2f}**")
        
        if usd_to_rial:
            price_per_gram_rial = (intl_price * usd_to_rial) / 31.1035
            price_per_gram_toman = price_per_gram_rial / 10
            lines.append(f"• هر گرم: **{format_number(price_per_gram_toman)} تومان**")
            lines.append(f"• نرخ دلار: **{format_number(usd_to_rial)} ریال**")
        lines.append("")
    
    if iran_price:
        lines.append("**🇮🇷 بازار ایران (tgju.org):**")
        lines.append(f"• هر گرم نقره ۹۹۹: **{format_number(iran_price)} ریال**")
        lines.append(f"• هر گرم نقره ۹۹۹: **{format_number(iran_price // 10)} تومان**")
        lines.append("")
    
    if intl_price and iran_price and usd_to_rial:
        intl_per_gram = (intl_price * usd_to_rial) / 31.1035 / 10
        iran_per_gram = iran_price / 10
        diff_percent = ((iran_per_gram - intl_per_gram) / intl_per_gram) * 100
        lines.append(f"📊 **اختلاف قیمت:** بازار ایران ~{diff_percent:.0f}% گرون‌تر")
    
    if not intl_price and not iran_price:
        lines.append("⚠️ نتونستم قیمت رو دریافت کنم.")
    
    lines.append("")
    lines.append("🤖 ارسال شده توسط Hermes | هر ۳ روز")
    
    print('\n'.join(lines))
