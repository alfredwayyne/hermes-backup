#!/usr/bin/env python3
"""
Gaming News Daily Digest - Updated v2
Features:
1. Cross-source deduplication
2. Full Persian translation using Google Translate
Run at 10 PM Iran time (18:30 UTC).
"""

import json
import urllib.request
import urllib.parse
import time
import re
from html.parser import HTMLParser
from datetime import datetime
from deep_translator import GoogleTranslator

class TextExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self.result = []
        self.skip = False
    def handle_starttag(self, tag, attrs):
        if tag in ['script', 'style', 'noscript']:
            self.skip = True
    def handle_endtag(self, tag):
        if tag in ['script', 'style', 'noscript']:
            self.skip = False
    def handle_data(self, data):
        if not self.skip:
            text = data.strip()
            if text:
                self.result.append(text)
    def get_text(self):
        return ' '.join(self.result)

def fetch_url(url, timeout=10):
    """Fetch URL content."""
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    }
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.read().decode('utf-8', errors='ignore')
    except Exception as e:
        return None

def search_news(query, max_results=8):
    """Search for news using Google News RSS."""
    url = f"https://news.google.com/rss/search?q={urllib.parse.quote(query)}&hl=en-US&gl=US&ceid=US:en"
    content = fetch_url(url)
    if not content:
        return []
    
    articles = []
    items = re.findall(r'<item>(.*?)</item>', content, re.DOTALL)
    for item in items[:max_results]:
        title = re.search(r'<title>(.*?)</title>', item)
        link = re.search(r'<link>(.*?)</link>', item)
        pubdate = re.search(r'<pubDate>(.*?)</pubDate>', item)
        source = re.search(r'<source[^>]*>(.*?)</source>', item)
        
        if title:
            articles.append({
                'title': title.group(1).strip(),
                'url': link.group(1).strip() if link else '',
                'date': pubdate.group(1).strip() if pubdate else '',
                'source': source.group(1).strip() if source else ''
            })
    return articles

def get_ign_news():
    """Fetch latest from IGN RSS."""
    url = "https://feeds.feedburner.com/ign/all"
    content = fetch_url(url)
    if not content:
        return []
    
    articles = []
    items = re.findall(r'<item>(.*?)</item>', content, re.DOTALL)
    for item in items[:10]:
        title = re.search(r'<title>(.*?)</title>', item)
        link = re.search(r'<link>(.*?)</link>', item)
        pubdate = re.search(r'<pubDate>(.*?)</pubDate>', item)
        desc = re.search(r'<description>(.*?)</description>', item, re.DOTALL)
        
        if title:
            clean_desc = ''
            if desc:
                extractor = TextExtractor()
                extractor.feed(desc.group(1))
                clean_desc = extractor.get_text()[:300]
            
            articles.append({
                'title': title.group(1).strip(),
                'url': link.group(1).strip() if link else '',
                'date': pubdate.group(1).strip() if pubdate else '',
                'source': 'IGN',
                'summary': clean_desc
            })
    return articles

def get_pcgamer_news():
    """Fetch from PC Gamer RSS."""
    url = "https://www.pcgamer.com/rss/"
    content = fetch_url(url)
    if not content:
        return []
    
    articles = []
    items = re.findall(r'<item>(.*?)</item>', content, re.DOTALL)
    for item in items[:8]:
        title = re.search(r'<title>(.*?)</title>', item)
        link = re.search(r'<link>(.*?)</link>', item)
        pubdate = re.search(r'<pubDate>(.*?)</pubDate>', item)
        desc = re.search(r'<description>(.*?)</description>', item, re.DOTALL)
        
        if title:
            clean_desc = ''
            if desc:
                extractor = TextExtractor()
                extractor.feed(desc.group(1))
                clean_desc = extractor.get_text()[:300]
            
            articles.append({
                'title': title.group(1).strip(),
                'url': link.group(1).strip() if link else '',
                'date': pubdate.group(1).strip() if pubdate else '',
                'source': 'PC Gamer',
                'summary': clean_desc
            })
    return articles

def get_gamespot_news():
    """Fetch from GameSpot RSS."""
    url = "https://www.gamespot.com/feeds/most-popular/"
    content = fetch_url(url)
    if not content:
        return []
    
    articles = []
    items = re.findall(r'<item>(.*?)</item>', content, re.DOTALL)
    for item in items[:8]:
        title = re.search(r'<title>(.*?)</title>', item)
        link = re.search(r'<link>(.*?)</link>', item)
        pubdate = re.search(r'<pubDate>(.*?)</pubDate>', item)
        desc = re.search(r'<description>(.*?)</description>', item, re.DOTALL)
        
        if title:
            clean_desc = ''
            if desc:
                extractor = TextExtractor()
                extractor.feed(desc.group(1))
                clean_desc = extractor.get_text()[:300]
            
            articles.append({
                'title': title.group(1).strip(),
                'url': link.group(1).strip() if link else '',
                'date': pubdate.group(1).strip() if pubdate else '',
                'source': 'GameSpot',
                'summary': clean_desc
            })
    return articles

def get_kotaku_news():
    """Fetch from Kotaku RSS."""
    url = "https://kotaku.com/rss"
    content = fetch_url(url)
    if not content:
        return []
    
    articles = []
    items = re.findall(r'<item>(.*?)</item>', content, re.DOTALL)
    for item in items[:8]:
        title = re.search(r'<title>(.*?)</title>', item)
        link = re.search(r'<link>(.*?)</link>', item)
        pubdate = re.search(r'<pubDate>(.*?)</pubDate>', item)
        desc = re.search(r'<description>(.*?)</description>', item, re.DOTALL)
        
        if title:
            clean_desc = ''
            if desc:
                extractor = TextExtractor()
                extractor.feed(desc.group(1))
                clean_desc = extractor.get_text()[:300]
            
            articles.append({
                'title': title.group(1).strip(),
                'url': link.group(1).strip() if link else '',
                'date': pubdate.group(1).strip() if pubdate else '',
                'source': 'Kotaku',
                'summary': clean_desc
            })
    return articles

def get_eurogamer_news():
    """Fetch from Eurogamer RSS."""
    url = "https://www.eurogamer.net/feed"
    content = fetch_url(url)
    if not content:
        return []
    
    articles = []
    items = re.findall(r'<item>(.*?)</item>', content, re.DOTALL)
    for item in items[:8]:
        title = re.search(r'<title>(.*?)</title>', item)
        link = re.search(r'<link>(.*?)</link>', item)
        pubdate = re.search(r'<pubDate>(.*?)</pubDate>', item)
        desc = re.search(r'<description>(.*?)</description>', item, re.DOTALL)
        
        if title:
            clean_desc = ''
            if desc:
                extractor = TextExtractor()
                extractor.feed(desc.group(1))
                clean_desc = extractor.get_text()[:300]
            
            articles.append({
                'title': title.group(1).strip(),
                'url': link.group(1).strip() if link else '',
                'date': pubdate.group(1).strip() if pubdate else '',
                'source': 'Eurogamer',
                'summary': clean_desc
            })
    return articles

def clean_text(text):
    """Remove XML/HTML artifacts from text."""
    text = re.sub(r'<!\[CDATA\[', '', text)
    text = re.sub(r'\]\]>', '', text)
    text = re.sub(r'&#\d+;', '', text)
    text = re.sub(r'&amp;', '&', text)
    text = re.sub(r'&lt;', '<', text)
    text = re.sub(r'&gt;', '>', text)
    text = re.sub(r'&quot;', '"', text)
    text = re.sub(r'<[^>]+>', '', text)
    return text.strip()

def normalize_title(title):
    """Normalize title for comparison."""
    title = title.lower()
    title = re.sub(r'[^\w\s]', '', title)
    title = re.sub(r'\s+', ' ', title)
    title = re.sub(r'^(breaking|new|update|just|report|reveal)', '', title)
    return title.strip()

def are_similar(title1, title2):
    """Check if two titles are similar enough to be duplicates."""
    t1 = normalize_title(title1)
    t2 = normalize_title(title2)
    
    if t1 == t2:
        return True
    if t1 in t2 or t2 in t1:
        return True
    
    words1 = set(t1.split())
    words2 = set(t2.split())
    if len(words1) == 0 or len(words2) == 0:
        return False
    
    overlap = len(words1 & words2)
    min_len = min(len(words1), len(words2))
    
    if overlap / min_len >= 0.7:
        return True
    
    return False

def deduplicate_cross_source(articles):
    """Remove duplicate articles across different sources."""
    if not articles:
        return []
    
    unique = []
    seen_titles = []
    
    for art in articles:
        title = clean_text(art.get('title', ''))
        if not title:
            continue
        
        art['title'] = title
        is_duplicate = False
        
        for seen in seen_titles:
            if are_similar(title, seen['title']):
                if art.get('summary') and not seen.get('summary'):
                    seen_idx = seen_titles.index(seen)
                    unique[seen_idx] = art
                is_duplicate = True
                break
        
        if not is_duplicate:
            seen_titles.append(art)
            unique.append(art)
    
    return unique

def translate_to_persian(text):
    """Translate English text to Persian using Google Translate."""
    if not text or len(text.strip()) < 5:
        return text
    
    try:
        translator = GoogleTranslator(source='en', target='fa')
        # Split long texts to avoid API limits
        if len(text) > 500:
            text = text[:500]
        translated = translator.translate(text)
        return translated if translated else text
    except Exception as e:
        return text

def format_digest(all_articles):
    """Format the gaming news digest with deduplication and Persian translation."""
    now = datetime.utcnow().strftime('%Y-%m-%d')
    
    lines = []
    lines.append(f"🎮 **گیمینگ دیلی دایجست** 🎮")
    lines.append(f"📅 {now}")
    lines.append("")
    
    if not all_articles:
        lines.append("⚠️ امروز خبر جدیدی پیدا نشد. لینک‌های RSS ممکنه تغییر کرده باشن.")
        return '\n'.join(lines)
    
    # Cross-source deduplication
    unique_articles = deduplicate_cross_source(all_articles)
    lines.append(f"📊 **کل اخبار: {len(all_articles)}** | **بی‌تکرار: {len(unique_articles)}**")
    lines.append("")
    
    # Group by source
    by_source = {}
    for art in unique_articles:
        src = art.get('source', 'Unknown')
        if src not in by_source:
            by_source[src] = []
        by_source[src].append(art)
    
    source_emoji = {
        'IGN': '🔥',
        'PC Gamer': '💻',
        'GameSpot': '🎯',
        'Kotaku': '🎭',
        'Eurogamer': '🇪🇺',
        'Google News': '📰',
    }
    
    # Top stories with Persian translation
    lines.append("📌 **اخبار برتر:**")
    lines.append("")
    
    top = unique_articles[:5]
    for i, art in enumerate(top, 1):
        emoji = source_emoji.get(art.get('source', ''), '📰')
        
        # Translate title to Persian
        persian_title = translate_to_persian(art['title'][:100])
        
        lines.append(f"{i}. {emoji} **{persian_title}**")
        if art.get('url'):
            lines.append(f"   🔗 {art['url']}")
        lines.append("")
    
    lines.append("---")
    lines.append("")
    
    # By source with translations
    for source, arts in by_source.items():
        emoji = source_emoji.get(source, '📰')
        lines.append(f"{emoji} **{source}** ({len(arts)} خبر)")
        lines.append("")
        for art in arts[:6]:
            persian_title = translate_to_persian(art['title'][:80])
            lines.append(f"• {persian_title}")
            if art.get('url'):
                lines.append(f"  {art['url']}")
        lines.append("")
    
    # Footer
    lines.append("---")
    lines.append(f"🤖 ارسال شده توسط Hermes | ساعت ۱۰ شب تهران")
    
    return '\n'.join(lines)

# Main execution
if __name__ == '__main__':
    print("🎮 Fetching gaming news...", flush=True)
    
    all_articles = []
    
    # Fetch from multiple sources
    sources = [
        ("IGN", get_ign_news),
        ("PC Gamer", get_pcgamer_news),
        ("GameSpot", get_gamespot_news),
        ("Kotaku", get_kotaku_news),
        ("Eurogamer", get_eurogamer_news),
    ]
    
    for name, func in sources:
        try:
            arts = func()
            all_articles.extend(arts)
            print(f"  ✓ {name}: {len(arts)} articles")
        except Exception as e:
            print(f"  ✗ {name}: {e}")
        time.sleep(1)
    
    # Also search Google News for gaming
    try:
        google_arts = search_news("gaming news today", max_results=10)
        for art in google_arts:
            art['source'] = art.get('source', 'Google News')
        all_articles.extend(google_arts)
        print(f"  ✓ Google News: {len(google_arts)} articles")
    except Exception as e:
        print(f"  ✗ Google News: {e}")
    
    # Deduplicate across sources
    all_articles = deduplicate_cross_source(all_articles)
    print(f"\n  Total unique: {len(all_articles)} articles")
    
    # Format and output
    digest = format_digest(all_articles)
    print("\n" + digest)
