#!/usr/bin/env python3
"""
Samsung News Daily Digest - Updated v2
Features:
1. Cross-source deduplication
2. Persian translation for international news
3. Iranian sources already in Persian
"""

import json
import urllib.request
import urllib.parse
import time
import re
from datetime import datetime
from deep_translator import GoogleTranslator

def fetch_url(url, timeout=10):
    """Fetch URL content."""
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9,fa;q=0.8',
    }
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.read().decode('utf-8', errors='ignore')
    except Exception as e:
        return None

def clean_text(text):
    """Remove XML/HTML artifacts."""
    text = re.sub(r'<!\[CDATA\[', '', text)
    text = re.sub(r'\]\]>', '', text)
    text = re.sub(r'&#\d+;', '', text)
    text = re.sub(r'&amp;', '&', text)
    text = re.sub(r'&lt;', '<', text)
    text = re.sub(r'&gt;', '>', text)
    text = re.sub(r'&quot;', '"', text)
    text = re.sub(r'&#8211;', '–', text)
    text = re.sub(r'&#8212;', '—', text)
    text = re.sub(r'<[^>]+>', '', text)
    return text.strip()

def parse_rss(content, max_items=10, source_name=""):
    """Parse RSS feed and return articles."""
    articles = []
    items = re.findall(r'<item>(.*?)</item>', content, re.DOTALL)
    for item in items[:max_items]:
        title = re.search(r'<title>(.*?)</title>', item)
        link = re.search(r'<link>(.*?)</link>', item)
        pubdate = re.search(r'<pubDate>(.*?)</pubDate>', item)
        desc = re.search(r'<description>(.*?)</description>', item, re.DOTALL)
        
        if title:
            clean_title = clean_text(title.group(1))
            clean_desc = clean_text(desc.group(1))[:200] if desc else ''
            articles.append({
                'title': clean_title,
                'url': link.group(1).strip() if link else '',
                'date': pubdate.group(1).strip() if pubdate else '',
                'source': source_name,
                'summary': clean_desc
            })
    return articles

# ==================== IRANIAN SOURCES ====================

def get_zoomit_samsung():
    """Zoomit.ir - Samsung section."""
    url = "https://www.zoomit.ir/tag/samsung/feed/"
    content = fetch_url(url)
    if content:
        return parse_rss(content, 8, "Zoomit")
    return []

def get_digiato_samsung():
    """Digiato - Samsung."""
    url = "https://digiato.com/feed/?s=samsung"
    content = fetch_url(url)
    if content:
        return parse_rss(content, 8, "Digiato")
    return []

def get_androidiran_samsung():
    """Android Iran - Samsung."""
    url = "https://www.android-iran.com/feed/"
    content = fetch_url(url)
    if content:
        articles = parse_rss(content, 10, "Android Iran")
        return [a for a in articles if any(kw in a['title'].lower() for kw in ['samsung', 'galaxy', 'سامسونگ', 'گلکسی'])]
    return []

def get_yektech_samsung():
    """YekTech - Samsung."""
    url = "https://www.yektech.com/feed/"
    content = fetch_url(url)
    if content:
        articles = parse_rss(content, 10, "YekTech")
        return [a for a in articles if any(kw in a['title'].lower() for kw in ['samsung', 'galaxy', 'سامسونگ', 'گلکسی'])]
    return []

def get_techrasa_samsung():
    """TechRasa - Samsung."""
    url = "https://techrasa.com/feed/"
    content = fetch_url(url)
    if content:
        articles = parse_rss(content, 10, "TechRasa")
        return [a for a in articles if any(kw in a['title'].lower() for kw in ['samsung', 'galaxy', 'سامسونگ', 'گلکسی'])]
    return []

# ==================== INTERNATIONAL SOURCES ====================

def get_sammobile_news():
    """SamMobile - Dedicated Samsung news."""
    url = "https://www.sammobile.com/feed/"
    content = fetch_url(url)
    if content:
        return parse_rss(content, 10, "SamMobile")
    return []

def get_androidauthority_samsung():
    """Android Authority - Samsung."""
    url = "https://www.androidauthority.com/feed/"
    content = fetch_url(url)
    if content:
        articles = parse_rss(content, 15, "Android Authority")
        return [a for a in articles if any(kw in a['title'].lower() for kw in ['samsung', 'galaxy'])]
    return []

def get_gsmarena_samsung():
    """GSMArena - Samsung."""
    url = "https://www.gsmarena.com/rss-news-reviews.php3"
    content = fetch_url(url)
    if content:
        articles = parse_rss(content, 15, "GSMArena")
        return [a for a in articles if any(kw in a['title'].lower() for kw in ['samsung', 'galaxy'])]
    return []

def get_theverge_samsung():
    """The Verge - Samsung."""
    url = "https://www.theverge.com/rss/index.xml"
    content = fetch_url(url)
    if content:
        articles = parse_rss(content, 20, "The Verge")
        return [a for a in articles if any(kw in a['title'].lower() for kw in ['samsung', 'galaxy'])]
    return []

def get_9to5google_samsung():
    """9to5Google - Samsung."""
    url = "https://9to5google.com/feed/"
    content = fetch_url(url)
    if content:
        articles = parse_rss(content, 15, "9to5Google")
        return [a for a in articles if any(kw in a['title'].lower() for kw in ['samsung', 'galaxy'])]
    return []

def get_techcrunch_samsung():
    """TechCrunch - Samsung."""
    url = "https://techcrunch.com/feed/"
    content = fetch_url(url)
    if content:
        articles = parse_rss(content, 20, "TechCrunch")
        return [a for a in articles if any(kw in a['title'].lower() for kw in ['samsung', 'galaxy'])]
    return []

def get_google_news_samsung():
    """Google News - Samsung."""
    url = "https://news.google.com/rss/search?q=samsung+galaxy+phone&hl=en-US&gl=US&ceid=US:en"
    content = fetch_url(url)
    if content:
        return parse_rss(content, 10, "Google News")
    return []

def get_google_news_samsung_fa():
    """Google News - Samsung Persian."""
    url = "https://news.google.com/rss/search?q=%D8%B3%D8%A7%D9%85%D8%B3%D9%88%D9%86%DA%AF+%DA%AF%D9%84%DA%A9%D8%B3%DB%8C&hl=fa&gl=IR&ceid=IR:fa"
    content = fetch_url(url)
    if content:
        return parse_rss(content, 10, "Google News FA")
    return []

# ==================== DEDUPLICATION ====================

def normalize_title(title):
    """Normalize title for comparison."""
    title = title.lower()
    title = re.sub(r'[^\w\s]', '', title)
    title = re.sub(r'\s+', ' ', title)
    return title.strip()

def are_similar(title1, title2):
    """Check if two titles are similar enough to be duplicates."""
    t1 = normalize_title(title1)
    t2 = normalize_title(title2)
    
    if t1 == t2:
        return True
    if t1 in t2 or t2 in t1:
        return True
    
    words1 = set(t1.split())
    words2 = set(t2.split())
    if len(words1) == 0 or len(words2) == 0:
        return False
    
    overlap = len(words1 & words2)
    min_len = min(len(words1), len(words2))
    
    if overlap / min_len >= 0.6:
        return True
    
    return False

def deduplicate_cross_source(articles):
    """Remove duplicate articles across different sources."""
    if not articles:
        return []
    
    unique = []
    seen_titles = []
    
    for art in articles:
        title = clean_text(art.get('title', ''))
        if not title:
            continue
        
        art['title'] = title
        is_duplicate = False
        
        for seen in seen_titles:
            if are_similar(title, seen['title']):
                # Keep the one with summary or from more reputable source
                if art.get('summary') and not seen.get('summary'):
                    seen_idx = seen_titles.index(seen)
                    unique[seen_idx] = art
                is_duplicate = True
                break
        
        if not is_duplicate:
            seen_titles.append(art)
            unique.append(art)
    
    return unique

# ==================== TRANSLATION ====================

def translate_to_persian(text):
    """Translate English text to Persian using Google Translate."""
    if not text or len(text.strip()) < 5:
        return text
    
    # Check if already Persian
    if any('\u0600' <= c <= '\u06FF' for c in text):
        return text
    
    try:
        translator = GoogleTranslator(source='en', target='fa')
        if len(text) > 500:
            text = text[:500]
        translated = translator.translate(text)
        return translated if translated else text
    except Exception as e:
        return text

# ==================== FORMAT ====================

def is_samsung_related(title):
    """Check if article is Samsung related."""
    keywords = ['samsung', 'galaxy', 'one ui', 'exynos', 'oneui', 'bixby', 'tab s', 'samsung pay']
    title_lower = title.lower()
    return any(kw in title_lower for kw in keywords)

def format_digest(all_articles):
    """Format the digest with deduplication and Persian translation."""
    now = datetime.utcnow().strftime('%Y-%m-%d')
    
    lines = []
    lines.append(f"📱 **سامسونگ دیلی دایجست** 📱")
    lines.append(f"📅 {now}")
    lines.append("")
    
    if not all_articles:
        lines.append("⚠️ امروز خبر جدیدی پیدا نشد.")
        return '\n'.join(lines)
    
    # Filter Samsung related
    samsung_articles = [a for a in all_articles if is_samsung_related(a['title'])]
    
    if not samsung_articles:
        samsung_articles = all_articles[:10]
    
    # Cross-source deduplication
    unique_articles = deduplicate_cross_source(samsung_articles)
    lines.append(f"📊 **کل اخبار: {len(samsung_articles)}** | **بی‌تکرار: {len(unique_articles)}**")
    lines.append("")
    
    # Split Iranian and International
    iranian_sources = ["Zoomit", "Digiato", "Android Iran", "YekTech", "TechRasa", "Google News FA"]
    iranian = [a for a in unique_articles if a['source'] in iranian_sources]
    international = [a for a in unique_articles if a['source'] not in iranian_sources]
    
    # Top 5 with Persian translation
    lines.append("📌 **اخبار برتر:**")
    lines.append("")
    for i, art in enumerate(unique_articles[:5], 1):
        src_emoji = "🇮🇷" if art['source'] in iranian_sources else "🌍"
        
        # Translate international news to Persian
        if art['source'] not in iranian_sources:
            persian_title = translate_to_persian(art['title'][:100])
        else:
            persian_title = art['title'][:100]
        
        lines.append(f"{i}. {src_emoji} **{persian_title}**")
        if art.get('url'):
            lines.append(f"   🔗 {art['url']}")
        lines.append("")
    
    lines.append("---")
    lines.append("")
    
    # Iranian news (already in Persian)
    if iranian:
        lines.append("🇮🇷 **اخبار ایرانی:**")
        lines.append("")
        for art in iranian[:8]:
            lines.append(f"• [{art['source']}] {art['title'][:70]}")
            if art.get('url'):
                lines.append(f"  {art['url']}")
        lines.append("")
    
    # International news (translated to Persian)
    if international:
        lines.append("🌍 **اخبار بین‌المللی:**")
        lines.append("")
        for art in international[:8]:
            persian_title = translate_to_persian(art['title'][:70])
            lines.append(f"• [{art['source']}] {persian_title}")
            if art.get('url'):
                lines.append(f"  {art['url']}")
        lines.append("")
    
    lines.append("---")
    lines.append(f"🤖 ارسال شده توسط Hermes | هر ۲۴ ساعت")
    
    return '\n'.join(lines)

# Main
if __name__ == '__main__':
    print("📱 Fetching Samsung news...", flush=True)
    
    all_articles = []
    
    # Iranian sources
    iranian_funcs = [
        ("Zoomit", get_zoomit_samsung),
        ("Digiato", get_digiato_samsung),
        ("Android Iran", get_androidiran_samsung),
        ("YekTech", get_yektech_samsung),
        ("TechRasa", get_techrasa_samsung),
    ]
    
    # International sources
    intl_funcs = [
        ("SamMobile", get_sammobile_news),
        ("Android Authority", get_androidauthority_samsung),
        ("GSMArena", get_gsmarena_samsung),
        ("The Verge", get_theverge_samsung),
        ("9to5Google", get_9to5google_samsung),
        ("TechCrunch", get_techcrunch_samsung),
    ]
    
    # Google News
    news_funcs = [
        ("Google News", get_google_news_samsung),
        ("Google News FA", get_google_news_samsung_fa),
    ]
    
    all_funcs = iranian_funcs + intl_funcs + news_funcs
    
    for name, func in all_funcs:
        try:
            arts = func()
            all_articles.extend(arts)
            print(f"  ✓ {name}: {len(arts)} articles")
        except Exception as e:
            print(f"  ✗ {name}: {e}")
        time.sleep(0.8)
    
    # Deduplicate across sources
    all_articles = deduplicate_cross_source(all_articles)
    print(f"\n  Total unique: {len(all_articles)} articles")
    
    # Format and output
    digest = format_digest(all_articles)
    print("\n" + digest)
