---
name: cron-job-creation
description: "Scheduled cron jobs with Python scripts for monitoring."
---

# Cron Job Creation

Create automated scheduled tasks that fetch data and deliver to Telegram.

## Pattern

1. Write Python script in `~/.hermes/scripts/<name>.py`
2. Test script manually with `python3 ~/.hermes/scripts/<name>.py`
3. Create cron job with `cronjob(action='create', no_agent=True, script='<name>.py', schedule='every Xh')`
4. Script stdout is delivered verbatim to the chat

## Script Template

```python
#!/usr/bin/env python3
import json, urllib.request, time, re
from datetime import datetime

def fetch_url(url, timeout=10):
    headers = {'User-Agent': 'Mozilla/5.0', 'Accept': 'application/json'}
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.read().decode('utf-8', errors='ignore')
    except:
        return None

def clean_text(text):
    text = re.sub(r'<!\[CDATA\[|\]\]>|&#\d+;|&amp;|<[^>]+>', '', text)
    return text.strip()

def parse_rss(content, max_items=10, source_name=""):
    articles = []
    items = re.findall(r'<item>(.*?)</item>', content, re.DOTALL)
    for item in items[:max_items]:
        title = re.search(r'<title>(.*?)</title>', item)
        link = re.search(r'<link>(.*?)</link>', item)
        if title:
            articles.append({
                'title': clean_text(title.group(1)),
                'url': link.group(1).strip() if link else '',
                'source': source_name
            })
    return articles

# Main output goes to stdout (delivered to chat)
print("📱 **Title** 📱")
print(f"📅 {datetime.utcnow().strftime('%Y-%m-%d')}")
```

## Pitfalls

1. Script path must be relative to ~/.hermes/scripts/
2. Always clean XML CDATA from RSS titles
3. Add time.sleep(0.5-1) between API calls
4. **CRITICAL: Cron jobs use /opt/venv/bin/python3, NOT system python3.** If script needs a pip package, install it in the venv: `/opt/venv/bin/pip install <package>`. Testing with `python3 script.py` (system) may succeed but cron will fail with ModuleNotFoundError. Always test with `/opt/venv/bin/python3 script.py` before creating the cron job. Verified this session: deep_translator worked with system python but failed in cron until installed via `/opt/venv/bin/pip install deep-translator`.
5. Yahoo Finance: SI=F for silver, GC=F for gold
5. Free currency API: open.er-api.com/v6/latest/USD
6. PubMed: eutils.ncbi.nlm.nih.gov/entrez/eutils/
7. **Cross-source deduplication** — When aggregating news from multiple sources, implement deduplication to avoid showing the same story from different outlets:
   ```python
   def normalize_title(title):
       title = title.lower()
       title = re.sub(r'[^\w\s]', '', title)
       title = re.sub(r'\s+', ' ', title)
       return title.strip()
   
   def are_similar(t1, t2):
       t1, t2 = normalize_title(t1), normalize_title(t2)
       if t1 == t2 or t1 in t2 or t2 in t1:
           return True
       words1, words2 = set(t1.split()), set(t2.split())
       if not words1 or not words2:
           return False
       overlap = len(words1 & words2) / min(len(words1), len(words2))
       return overlap >= 0.7
   ```
8. **Persian/Farsi output** — For Iranian users, translate to Farsi. Two approaches:

   **Option A: Full translation with deep_translator (PREFERRED for news):**
   ```bash
   pip install deep-translator
   ```
   ```python
   from deep_translator import GoogleTranslator
   
   def translate_to_persian(text):
       if not text or len(text.strip()) < 5:
           return text
       # Skip if already Persian
       if any('\u0600' <= c <= '\u06FF' for c in text):
           return text
       try:
           translator = GoogleTranslator(source='en', target='fa')
           if len(text) > 500:
               text = text[:500]
           translated = translator.translate(text)
           return translated if translated else text
       except:
           return text
   ```
   
   **Option B: Simple keyword replacement (lightweight, no dependencies):**
   ```python
   def simple_translate(title):
       translations = {
           'review': 'نقد و بررسی', 'release': 'انتشار', 'trailer': 'تریلر',
           'playstation': 'پلی‌استیشن', 'xbox': 'ایکس‌باکس', 'nintendo': 'نینتندو',
           'fortnite': 'فورتنایت', 'gta': 'جی‌تی‌ای', 'minecraft': 'ماینکرفت',
       }
       for eng, fa in translations.items():
           if eng in title.lower():
               title = re.sub(re.escape(eng), fa, title, flags=re.IGNORECASE)
       return title
   ```
   
   **When to use which:**
   - Full translation (Option A): News digests, article summaries, anything user-facing
   - Keyword replacement (Option B): Quick labels, minimal text, no pip install allowed

## Schedules

- every 1h, every 12h, every 24h, every 72h
- Cron syntax: 30 18 * * * (6:30 PM UTC = 10:30 PM Tehran)

## Free APIs

| API | URL | Use |
|-----|-----|-----|
| ExchangeRate | open.er-api.com/v6/latest/USD | Currency |
| Yahoo Finance | query1.finance.yahoo.com/v8/finance/chart/SYMBOL | Stocks/Commodities |
| PubMed | eutils.ncbi.nlm.nih.gov/entrez/eutils/ | Papers |
| Google News RSS | news.google.com/rss/search?q=QUERY | News |

## Iranian Market Prices (tgju.org)

For Iranian domestic prices (gold, silver, currency), scrape tgju.org profile pages:

- Silver 999 per gram: `https://www.tgju.org/profile/silver_999`
- Gold coin (mesghal): `https://www.tgju.org/profile/mesghal`
- Dollar rate: `https://www.tgju.org/profile/dollar`

**Scraping pattern:** Prices are in HTML span elements with comma-formatted numbers. Use regex `[\d,]{7,12}` to find price candidates, then filter by reasonable range (e.g., silver 999 is typically 3-5 million Rial per gram).

**Important:** Iranian domestic prices differ significantly from international spot prices (often 50-100% higher) due to sanctions, supply constraints, and currency controls. Always show both prices when relevant.

**Example:**
```python
import re
prices = re.findall(r'class="[^"]*"[^>]*>([\d,]{7,12})<', content)
for p in prices:
    val = int(p.replace(',', ''))
    if 1_000_000 < val < 10_000_000:  # Reasonable range for silver
        print(f"Price: {val:,} Rial = {val//10:,} Toman")
```