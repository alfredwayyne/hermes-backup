---
name: academic-writing
description: "Write review articles and academic papers for any field."
version: 1.0.0
author: Hermes Agent
license: MIT
tags: [academic, writing, review, research, pubmed, arxiv, citations]
---

# Academic Writing

Write review articles, systematic reviews, and academic papers across all disciplines. For ML-specific paper writing, see `research-paper-writing`.

## Workflow

### Phase 1: Discovery
1. **Search literature**: PubMed (biology/medicine), arXiv (physics/CS), Semantic Scholar (all)
2. **Assess impact**: Citation counts, journal impact factor
3. **Read abstracts**: Filter relevant papers
4. **Full text review**: Read key papers in detail

### Phase 2: Structure
1. **Create outline**: Standard review structure (see template below)
2. **Identify themes**: Group papers by topic, method, or finding
3. **Find gaps**: What hasn't been covered? Contradictions?

### Phase 3: Writing
1. **Draft sections**: Introduction → Background → Mechanisms → Clinical → Future
2. **Add citations**: Use PubMed IDs, DOIs, or arXiv IDs
3. **Create tables**: Comparison tables, clinical trial summaries
4. **Design figures**: Schematic diagrams, flowcharts

### Phase 4: Journal Selection
Before submission, identify target journals using this workflow:

1. **Define criteria**: Impact factor range, indexing (SCIE/SCI vs ESCI), Scopus quartile, APC fees, open access requirements
2. **CRITICAL: Check for "Zero Fees" requirement FIRST** — Many users (especially from Iran/Low-income countries) require absolutely ZERO author fees:
   - No APC (Article Processing Charges)
   - No page charges
   - No color figure fees
   - No submission fees
   - No production/proofing fees
   - **EXCLUDE Bentham Science** — they charge hidden fees at the end despite claiming "free subscription"
   - **Preferred publishers for zero fees**: Elsevier, Springer, Wiley, T&F, Thieme (subscription journals)
3. **Search databases** (in priority order):
   - **OpenAlex** (PRIMARY): `curl -s "https://api.openalex.org/sources?search={journal+name}&filter=type:journal"` — most reliable, returns publisher, OA status, APC, IF proxy. See `journal-metrics-research` skill for detailed API docs.
   - **DOAJ** (Directory of Open Access Journals): `curl -s "https://doaj.org/api/search/journals/QUERY"` — works reliably for OA journals
   - **Wikipedia API**: For JCR IF values and SCIE/SCI/ESCI indexing status
   - **Crossref API**: `curl -s "https://api.crossref.org/journals/{ISSN}"` — publisher verification (rate limit: 0.5s between requests)
   - **ScimagoJR**: Journal rankings by category (may be blocked by Cloudflare — check manually if needed)
3. **Verify metrics**: Check JCR (Journal Citation Reports) for IF, Scopus for Q ranking, publisher site for APC
4. **Match scope**: Ensure journal scope covers manuscript topic. **PubMed scope verification** is the most reliable method — search for articles in that specific journal about your topic:
   ```bash
   QUERY=$(python3 -c "import urllib.parse; print(urllib.parse.quote('\"Journal Name\"[Journal] AND (topic keywords) AND review[pt]'))")
   curl -s "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&term=${QUERY}&retmode=json&retmax=5"
   ```
   Journals with 5+ matching reviews are strong candidates; 0 suggests the journal doesn't publish in that niche. See `journal-metrics-research` skill for the full PubMed scope verification workflow.
5. **Check APC policy**: Distinguish between:
   - **No APC**: Subscription journals (hybrid may offer OA option with APC)
   - **OA required**: Some journals mandate OA with APC (e.g., BMC, MDPI)
   - **Free OA**: Some publishers (e.g., Spandidos) charge no fees even for OA
   - **Fee waivers**: Many offer waivers for low-income countries

**Common Pitfalls**:
- DOAJ only lists OA journals; subscription journals won't appear
- ScimagoJR and publisher sites often block automated access (Cloudflare/CAPTCHA)
- APC status changes; always verify on publisher site before submission
- ESCI journals are not SCIE — check Web of Science indexing explicitly
- Impact factors update annually (June); verify current year

### Phase 5: Polish
1. **Check consistency**: Terminology, abbreviations, formatting
2. **Verify citations**: Ensure references match text
3. **Peer review**: Self-check for gaps and errors

## Journal Selection

See `references/journal-search.md` for detailed API documentation, metric explanations, and journal quick-reference lists.

## Literature Search APIs

### PubMed (Biology/Medicine)
```bash
# Search
curl -s "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&term=QUERY&retmax=20&retmode=json"

# Get details
curl -s "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=pubmed&id=ID1,ID2&retmode=json"
```

### Semantic Scholar (All fields)
```bash
# Search with citations
curl -s "https://api.semanticscholar.org/graph/v1/paper/search?query=QUERY&limit=10&fields=title,authors,year,citationCount"

# Get citations OF a paper
curl -s "https://api.semanticscholar.org/graph/v1/paper/ARXIV:ID/citations?fields=title,year,citationCount&limit=10"
```

### arXiv (Physics/CS)
```bash
curl -s "https://export.arxiv.org/api/query?search_query=all:QUERY&max_results=10&sortBy=submittedDate&sortOrder=descending"
```

## Review Article Template

```markdown
# Title

## Abstract
- Background (1-2 sentences)
- Objective (1 sentence)
- Methods (1 sentence)
- Key findings (2-3 sentences)
- Conclusions (1-2 sentences)

## 1. Introduction
- Context and importance
- Historical background
- Scope of review

## 2. [Topic Area 1]
- Subtopic A
- Subtopic B
- Comparison/analysis

## 3. [Topic Area 2]
- ...

## 4. Clinical/Practical Implications
- Current applications
- Guidelines
- Patient outcomes

## 5. Future Directions
- Research gaps
- Emerging technologies
- Unanswered questions

## 6. Conclusions
- Summary of key points
- Take-home message

## References
```

## Pitfalls

- **arXiv is physics/CS only**: Use PubMed for biology/medicine
- **Semantic Scholar rate limits**: 1 req/sec without API key
- **Citation format**: Match target journal style (Vancouver, APA, etc.)
- **File delivery on Telegram**: Always send content inline AND as file attachments — never assume user can access server files
