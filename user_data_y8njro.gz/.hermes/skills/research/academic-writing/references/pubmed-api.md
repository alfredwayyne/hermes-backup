# PubMed E-utilities Quick Reference

## Search for Papers
```bash
curl -s "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&term=TERM&retmax=20&sort=relevance&retmode=json"
```

## Get Paper Details
```bash
curl -s "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=pubmed&id=ID1,ID2,ID3&retmode=json"
```

## Get Abstract
```bash
curl -s "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id=ID&rettype=abstract&retmode=text"
```

## Search Syntax
- `E2F1[pTitle] AND p53[Title]` — Title search
- `review[pt]` — Publication type: review
- `2020:2026[dp]` — Date range
- `human[MeSH Terms]` — Species filter
- `cancer[MeSH]` — MeSH term

## Common Combos
```
# Review articles on a topic
TOPIC AND review[pt]

# Recent papers (last 2 years)
TOPIC AND 2024:2026[dp]

# Specific gene + disease
GENE[Title/Abstract] AND DISEASE[MeSH]

# Clinical trials
TOPIC AND clinical trial[pt]
```

## Rate Limits
- 3 requests/second without API key
- Use `&retmax=` to limit results (default 20, max 10000)
