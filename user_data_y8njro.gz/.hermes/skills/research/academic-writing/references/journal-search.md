# Journal Search Reference

> **For detailed API documentation and verified journal data, also see the `journal-metrics-research` skill** — it has comprehensive notes on which APIs work, rate limits, and a growing database of verified journal ISSNs with OpenAlex IDs.

## APIs and Databases

### OpenAlex API (PRIMARY — most reliable, always works)
Best for journal metadata, publisher info, OA status, and APC data.

```bash
# Search journals by name
curl -s "https://api.openalex.org/sources?search={journal+name}&per_page=5&filter=type:journal"

# Get journal by ISSN
curl -s "https://api.openalex.org/sources/issn:{ISSN}"

# Get detailed data by source ID
curl -s "https://api.openalex.org/sources/{source_id}"
```

**Returns:** display_name, host_organization_name (publisher), summary_stats (2yr_mean_citedness ≈ IF proxy), apc_usd, is_oa, issn, works_count, h_index

**Key fields:**
- `summary_stats.2yr_mean_citedness` — 2-year mean citation rate (IF proxy)
- `apc_usd` — OA publication fee (null = no data, not necessarily free)
- `is_oa` — false = subscription/hybrid, true = fully OA
- `host_organization_name` — publisher name

**Rate limits:** ~$0.0001/request budget. After 50-100 requests, may hit limits. Use `select=` parameter to minimize response size.

### DOAJ (Directory of Open Access Journals)
Most reliable API for OA journal search. Only indexes OA journals.

```bash
# Search journals
curl -s "https://doaj.org/api/search/journals/cancer%20biology?ref=homepage-box"

# Search articles
curl -s "https://doaj.org/api/search/articles/p53%20tumor%20suppressor"

# Get journal by ID
curl -s "https://doaj.org/api/journals/JOURNAL_ID"
```

Response fields:
- `bibjson.title`: Journal name
- `bibjson.publisher.name`: Publisher
- `bibjson.ref.journal`: URL
- `bibjson.subject`: Subject areas
- `bibjson.apc`: APC amount (if any)

### Crossref API (for publisher verification)
```bash
curl -s "https://api.crossref.org/journals/{ISSN}"
```
Returns: title, publisher, ISSN-L. **Rate limit:** 429 after ~20-30 rapid requests. Add 0.5s delays.

### Wikipedia API (for JCR IF, indexing status)
```bash
curl -s "https://en.wikipedia.org/w/api.php?action=parse&page={Page_Name}&prop=wikitext&format=json"
```
Extract from wikitext: `impact_factor` field, `abstracting_and_indexing` section for SCIE/SCI/ESCI status.

### ScimagoJR
Journal rankings by Scopus quartile. **Often blocked by Cloudflare (403 Forbidden).** May work from browser but not from scripts.

### JCR (Journal Citation Reports)
Official source for Impact Factors. Requires institutional access. No public API.

### Publisher Journal Finders
- Elsevier: https://journalfinder.elsevier.com/
- Springer: https://journalsuggester.springer.com/
- Wiley: https://journalfinder.wiley.com/

## What Does NOT Work from Scripts
- Google/DuckDuckGo/Bing search (captcha blocks)
- SCImagoJR (403 Forbidden)
- bioxbio.com (404 errors)
- letPub (returns template values, not actual IF data)
- Resurchify (empty/inaccessible)

## Key Metrics Explained

### Impact Factor (IF)
- Annual metric from Clarivate Analytics (JCR)
- Calculated as: citations in year Y to papers published in years Y-1 and Y-2 / papers published in years Y-1 and Y-2
- Updated every June
- Higher = more influential (but field-dependent)

### Scopus Quartile (Q1-Q4)
- Based on SCImago Journal Rank (SJR)
- Q1: Top 25% in subject category
- Q2: 25-50%
- Q3: 50-75%
- Q4: Bottom 25%
- Check at: https://www.scimagojr.com/

### Indexing
- **SCIE** (Science Citation Index Expanded): Premium Web of Science index
- **SCI**: Science Citation Index (older, same prestige)
- **SSCI**: Social Sciences Citation Index
- **ESCI** (Emerging Sources Citation Index): Newer, lower prestige
- **EI** (Engineering Index): Engineering focus
- Verify at: https://mjl.clarivate.com/

## APC (Article Processing Charge) Verification

### No APC Journals
- Subscription-based journals (author pays nothing for publication)
- Hybrid journals: OA is optional; subscription author pays nothing
- Some societies fund OA (e.g., FEBS for Molecular Oncology)

### OA-Required Journals
- BMC/Springer Nature: ~$2,000-3,000
- MDPI: ~$1,800-2,900
- Frontiers: ~$1,000-2,500
- PLOS: ~$1,500-2,000

### Waivers
- Most OA publishers offer fee waivers for:
  - Low-income countries (check World Bank list)
  - No-funding situations (apply during submission)
  - Editorial discretion

## Common Cancer/Molecular Biology Journals (Quick Reference)

### High IF (10+)
- Nature Reviews Cancer (IF ~78) - Very competitive
- Cancer Cell (IF ~50) - Original research
- Cell Death & Differentiation (IF ~13) - Cell death mechanisms
- Trends in Molecular Medicine (IF ~12) - Reviews
- Cancer Treatment Reviews (IF ~11) - Treatment reviews
- Seminars in Cancer Biology (IF ~17) - Reviews

### Medium IF (5-10)
- Oncogene (IF ~8) - Tumor suppressors/oncogenes
- Cancer Letters (IF ~9) - Cancer biology
- Cancer Research (IF ~11) - AACR journal
- Clinical Cancer Research (IF ~11) - Translational
- Biochemical Pharmacology (IF ~5) - Drug mechanisms
- BBA Reviews on Cancer (IF ~5) - Reviews

### Lower IF (2-5)
- Molecular Oncology (IF ~4) - FEBS/Wiley
- Cancer and Metastasis Reviews (IF ~5) - Reviews
- Current Cancer Drug Targets (IF ~3) - Drug targets
- Cancer Science (IF ~5) - Japanese Cancer Association

## Workflow Summary

1. **Define requirements** (IF range, indexing, quartile, APC budget)
2. **Search DOAJ** for OA journals in your field
3. **Check ScimagoJR** for quartile rankings
4. **Verify IF** via JCR or publisher site
5. **Confirm APC** on publisher's author information page
6. **Match scope** by reading aims & scope and recent issues
7. **List 3-5 target journals** ranked by preference
8. **Check submission guidelines** (word limits, reference format, figure requirements)
