---
name: journal-metrics-research
description: "Research journal metrics via accessible APIs."
tags: [research, academia, journals, metrics]
trigger: "Use when researching academic journal metrics — Impact Factor, ISI/SCIE/ESCI indexing, Scopus CiteScore Q ranking, APC fees, publisher info, or whether a journal accepts review articles."
---

# Journal Metrics Research

> **MANDATORY FIRST STEP:** Load this skill BEFORE attempting any journal metrics research. The reference files (`references/natural-products-cancer-journals.md`, `references/verified-journal-issns.md`) contain pre-verified data for dozens of common journals — check them first to avoid redundant API calls.

Research specific metrics for academic journals using accessible APIs. Most journal websites and search engines block headless/programmatic access — use the APIs below instead.

## Priority API Access Order

### 1. OpenAlex API (PRIMARY — most data, always works)

Base: `https://api.openalex.org`

**Search journals by name (preferred — works well):**
```
curl -s "https://api.openalex.org/journals?search={journal+name}&per_page=5&select=display_name,host_organization_name,is_oa,apc_usd,summary_stats,issn,works_count"
```

**Get journal by ISSN (preferred — more reliable than name search):**
```
curl -s "https://api.openalex.org/sources/issn:{ISSN}"
```

**Also works:** `https://api.openalex.org/sources?search={name}&per_page=5`

Both `/journals` and `/sources` endpoints return similar data. `/journals` is more targeted.

**Returns:** display_name, host_organization_name (publisher), summary_stats (2yr_mean_citedness ≈ IF, h_index, i10_index), apc_usd, is_oa, topics, homepage_url, issn, first_publication_year, works_count

**Key metric:** `summary_stats.2yr_mean_citedness` is a proxy for Impact Factor (OpenAlex's own 2-year mean citation rate, close to JCR IF). Cross-reference with JCR values from Wikipedia when available.

**Rate limits:** OpenAlex has a daily USD budget (~$0.0001/request). **In practice, the budget depletes faster than expected** — as few as 25 requests can exhaust it in a session. After hitting the limit, the error is `{"error":"Rate limit exceeded","message":"Insufficient budget"}` and the reset is at midnight UTC. Plan batch searches accordingly — use `select=` parameter to minimize response size, and batch independent queries. If rate-limited, switch to Wikipedia API or Crossref for remaining journals.

### 2. Wikipedia API (for JCR IF, indexing status, history)

**Option A — REST Summary Endpoint (simplest, fastest — PREFERRED):**
```
curl -s "https://en.wikipedia.org/api/rest_v1/page/summary/{Page_Name}"
```
Returns clean JSON with `title`, `extract` (plain text paragraph), and metadata. **Best for quick journal lookups** — minimal parsing needed. The extract contains journal description, publisher, editor, and sometimes JCR IF. Works for ~70% of journals that have Wikipedia pages.

**Pitfall:** If the page name doesn't match exactly, you get a redirect to "Bentham Science Publishers" or other parent article. Use `Wikipedia Page Name` column from `references/verified-journal-issns.md` or try alternate names.

**Option B — Extract API (returns full article text):**
```
curl -s "https://en.wikipedia.org/w/api.php?action=query&titles={Page_Name}&prop=extracts&explaintext=1&format=json"
```
Returns plain text of the full article. Search for "impact factor", "SCIE", "Scopus" keywords with regex. Good for batch IF extraction from the full article text.

**Option C — Parse API (returns structured wikitext):**
```
curl -s "https://en.wikipedia.org/api.php?action=parse&page={Page_Name}&prop=wikitext&format=json"
```

**Option D — Direct HTML scrape (works well for batch IF extraction):**
Fetch `https://en.wikipedia.org/wiki/{Page_Name}` and extract from the infobox HTML:
```python
import re
text = re.sub(r'<[^>]+>', ' ', html)  # Strip HTML tags
if_match = re.search(r'Impact factor\s+(\d+\.?\d*)', text)
has_sci = 'SCIE' in text or 'Science Citation Index' in text
has_esci = 'ESCI' in text or 'Emerging Sources' in text
```
**This approach is faster than the API for batch processing** — fetches full page in one request, regex extracts IF and indexing status from the infobox. Works for ~70% of journals that have Wikipedia pages. Not all journals have Wikipedia articles (e.g., "Pharmaceutical Biology", "Journal of Natural Medicines" — use OpenAlex/WOS for these).

**Extract from wikitext:**
- `impact_factor` or `impact` field in infobox
- `abstracting_and_indexing` section → SCIE/SCI/ESCI/Scopus status
- JCR IF values cited in article text

**Rate limit:** ~200 req/min in theory, but **hits limits much sooner in practice** (~20-30 rapid requests). Add 1-2s delay between requests. The API returns `"error":{"code":"ratelimited"}` when exceeded. Wait 5-10s and retry.

**Rate limit recovery:** If rate-limited, wait 5-10 seconds, then resume. The limit resets quickly (unlike OpenAlex which resets at midnight UTC).

### 3. Crossref API (for publisher verification)

```
curl -s "https://api.crossref.org/journals/{ISSN}"
```

Returns: title, publisher, ISSN-L

### 4. DOAJ API (open access journals only)

```
curl -s "https://doaj.org/api/search/journals/{query}"
```

Limited to DOAJ-listed OA journals.

### 5. LetPub API (Chinese journal database, rate-limited but accurate)

**Search journals:** `https://www.letpub.com.cn/index.php?page=journalapp&view=search&search_field=journal_name&searchname={journal+name}`

**Extract IF:** Regex on HTML: `color:#FF5722;\s*font-weight:bold[^>]*>(\d+\.?\d*)`

**Detail page:** `https://www.letpub.com.cn/index.php?page=journalapp&view=detail&journalid={id}` (ID found in search results: `journalid=(\d+)`)

**Rate limit:** ~25-30 requests per session, then IP blocked for 10+ minutes. Add `time.sleep(1.5)` between requests. Error page title: "您请求页面的速度过快". Use only when other sources are exhausted.

**Returns:** Most recent JCR IF (updated annually), plus Chinese CAS zone rankings. More current than OpenAlex for IF values.

## JSON Parsing Pitfalls

OpenAlex API responses sometimes contain control characters (Unicode escapes like `\u0026`) that break standard `json.loads()`. Two workarounds:

1. **Regex extraction (reliable fallback):** Extract individual fields with regex instead of parsing full JSON:
   ```python
   display_name = re.search(r'"display_name"\s*:\s*"([^"]*)"', raw)
   citedness = re.search(r'"2yr_mean_citedness"\s*:\s*([\d.eE+-]+)', raw)
   apc = re.search(r'"apc_usd"\s*:\s*(\d+|null)', raw)
   ```

2. **Clean before parsing:** Strip control characters: `re.sub(r'[\x00-\x1f\x7f-\x9f]', '', text)` then parse.

## Common Pitfall: Don't Scrape Blocked Sites First

**DO NOT start by curling SCImago, Resurchify, Academic Accelerator, Bentham Science (eurekaselect.com), Taylor & Francis (tandfonline.com), or Google/Bing.** They ALL return Cloudflare challenges, empty pages, or captchas from curl/scripts. **Every wasted curl on a blocked site costs a tool call that could have been an API hit.** Instead:

## Common Pitfall: "Hybrid" Word on Publisher Pages ≠ Hybrid Publishing Model

When checking if a journal is hybrid (subscription + optional OA), do NOT search for the word "hybrid" on publisher websites. It will return false positives:
- **Frontiers:** "Hybrid Scanning" is a SECTION NAME within Frontiers in Pharmacology, not publishing model info. All Frontiers journals are 100% Gold OA.
- **Other publishers:** "Hybrid" may appear in section names, article titles, or navigation elements unrelated to publishing model.

**Correct approach to determine hybrid status:**
1. Check OpenAlex `is_oa` field: `false` = subscription/hybrid, `true` = full OA
2. Check OpenAlex `is_in_doaj` field: if `true`, it's a DOAJ-listed OA journal
3. Check Crossref publisher: known hybrid publishers (Elsevier, Springer, Wiley) are hybrid by default
4. For Frontiers specifically: always Gold OA, never hybrid, period.

1. Check the skill's own reference files first — they already contain verified data for common journals
2. Use OpenAlex API for IF/proxy, publisher, OA status, APC
3. Use Wikipedia API for JCR IF, SCIE/ESCI status
4. Use Crossref API for publisher/ISSN verification
5. Note "verify manually on SCImago" for exact Q rank — it cannot be automated

**OpenAlex rate limits:** Budget ~25-50 requests per session in practice (daily USD budget, resets at midnight UTC). Use `select=` to minimize response size. If rate-limited, switch to Wikipedia API or Crossref for remaining journals.

## Wikipedia Category Scraping (Publisher Discovery)

**When you need to find ALL journals from a specific publisher** (not just known ones), scrape the Wikipedia category page:

```
curl -s "https://en.wikipedia.org/wiki/Category:Publisher_Name_academic_journals"
```

Extract journal names with regex:
```python
pattern = r'<li><a href="/wiki/[^"]*" title="([^"]*)">([^<]*)</a>'
matches = re.findall(pattern, html)
```

Then filter by relevant keywords (pharm, drug, cancer, medic, etc.) and look up each via Wikipedia API for IF/publisher/SCIE data.

**When this works:** Publisher has a Wikipedia category page (~200+ journals for major publishers like T&F, Elsevier, Wiley, Springer).
**When this fails:** Publisher doesn't have a Wikipedia category, or the page uses a different structure.
**Rate limits:** Same as Wikipedia API (~20-30 rapid requests before throttling). Add delays.

**This is the ONLY reliable method when all web searches (Google, DuckDuckGo, Bing) and publisher websites (tandfonline.com, sagepub.com, etc.) are blocked by Cloudflare/captchas.** It was the breakthrough technique in sessions where every other approach failed.

**Example categories:**
- `Category:Taylor_%26_Francis_academic_journals` — 200+ journals
- `Category:Elsevier_academic_journals` — 2000+ journals
- `Category:Springer_science_journals` — large
- `Category:Wiley_academic_journals` — large

## OpenAlex Publisher-Lineage Journal Discovery

**When you need to find ALL journals from a specific publisher** (not just known ones), use OpenAlex's publisher lineage filter. This is the most reliable technique when the publisher doesn't have a Wikipedia category page.

### Step 1: Find the publisher's OpenAlex ID
```python
import urllib.request, urllib.parse, json
url = "https://api.openalex.org/publishers?search=Wolters%20Kluwer&per_page=3"
req = urllib.request.Request(url, headers={"User-Agent": "HermesBot/1.0"})
data = json.loads(urllib.request.urlopen(req, timeout=15).read().decode())
for r in data.get("results", []):
    print(f"{r['display_name']} | ID: {r['id']} | Works: {r['works_count']}")
```
Returns publisher IDs like `P4310318547` (Wolters Kluwer) and `P4310315860` (Wolters Kluwer Health).

### Step 2: Search for articles from that publisher with topic keywords
```python
# Filter by publisher lineage in works endpoint
wk_id = "P4310318547"  # Wolters Kluwer
q = urllib.parse.quote("breast cancer natural products")
url = f"https://api.openalex.org/works?search={q}&filter=primary_location.source.host_organization_lineage:{wk_id}&per_page=50&select=primary_location"
```

Extract unique journal names from `primary_location.source.display_name` across all results. Multiple queries with different topic keywords yield broader coverage.

### Step 3: Get detailed metadata for each discovered journal
```python
source_id = "S158028025"  # OpenAlex source ID for Anti-Cancer Drugs
url = f"https://api.openalex.org/sources/{source_id}?select=id,display_name,issn_l,is_oa,is_in_doaj,host_organization_name,type,summary_stats"
```
Returns: display_name, issn_l, publisher, OA status, IF proxy (2yr_mean_citedness), etc.

**Pitfall:** OpenAlex `publisher_lineage` filter returns 0 results for some publishers (confirmed for Bentham Science). If filtering returns nothing, search by journal name or ISSN instead.

**This technique was the breakthrough for discovering Wolters Kluwer / LWW / Medknow journals** when every other approach (Google, Bing, DuckDuckGo, OVID website scraping) failed due to bot blocking or JavaScript rendering.

## Batch Search Methodology (Finding Journals by Criteria)

When the user asks for journals matching specific criteria (IF range, Q ranking, APC status):

1. **Search known journals individually** — OpenAlex name search works better than trying to filter by IF range across all journals (the filter syntax is unreliable).
2. **Collect results into a list** — Extract display_name, citedness, publisher, OA status, APC for each.
3. **Filter client-side** — After collecting ~30-50 results, filter by IF range, then verify remaining criteria.
4. **Verify indexing separately** — OpenAlex doesn't directly report SCIE/SCI. Use Wikipedia wikitext or publisher websites for this.
5. **Present as tiered table** — Group by match quality (best fit, alternatives, reference).

**Pitfall:** Don't try OpenAlex's `filter=summary_stats.2yr_mean_citedness:2.0..3.5` — the filter syntax often returns 0 results. Search individual journals instead.

### User Exclusion Lists

When the user provides a list of journals they've been rejected from or excluded, **track these and exclude them from all results**. Common reasons for exclusion:
- Previous rejection (editorial or peer review)
- Too high or too low IF for their target range
- OA-only when they need subscription (or vice versa)
- Wrong scope/topic fit
- Publisher restrictions (e.g., "NOT Bentham Science")
- Specific journal not relevant to their subfield

**Implementation:** Before presenting results, filter out all excluded journals. Note the exclusions in your output so the user knows you respected their criteria. When searching, skip API calls for excluded journals to save rate limit budget.

### "Zero Fees" Journal Search

When the user wants journals with absolutely ZERO author fees (no APC, no page charges, no color fees, no submission fees):

**Key principle:** Subscription-based (non-OA) journals typically charge authors NOTHING. The APC model is primarily for Open Access journals.

1. **Start with the reference files** — `references/natural-products-cancer-journals.md` already has verified subscription journals listed.
2. **Check OpenAlex `is_oa` field** — `false` = subscription = typically zero fees for authors.
3. **Verify via publisher websites** — Some subscription journals charge optional fees for:
   - Color figures in print (increasingly irrelevant as most are online-only)
   - Extra page charges (if paper exceeds page limit)
   - Early online publication
   - Reprints
4. **Confirm "hybrid" status** — A hybrid journal offers BOTH subscription (free) AND OA (paid) routes. Authors can publish for free via subscription.
5. **Beware of journal flips** — Journals can transition from hybrid to full OA (e.g., Pharmaceutical Biology flipped in ~2025). Always re-verify current OA status.

**Common "zero fee" publishers (subscription journals):**
- Elsevier subscription journals — no author fees
- Springer subscription journals — no author fees
- Wiley subscription journals — no author fees
- Taylor & Francis subscription journals — no author fees
- Thieme subscription journals — no author fees
- ACS subscription journals — no author fees
- Bentham Science subscription journals — no author fees (but verify Scopus status)
- Spandidos Publishing — fully OA but charges NO fees (unusual)
- SAGE subscription journals — no author fees; SAGE Choice hybrid OA may be free with institutional Read & Publish agreement

**Present results as:** Tier 1 (highest IF, zero fees), Tier 2 (lower IF but still meets criteria), with explicit confirmation that each journal charges ZERO fees.

## Pitfall: execute_code Sandbox Isolation

**The `execute_code` tool runs in a sandboxed Python environment that does NOT share packages installed via `terminal()`.** If you `pip install duckduckgo-search` in a `terminal()` call, importing it in `execute_code` will fail with `ModuleNotFoundError`. 

**Workaround:** Run all Python code that needs pip-installed packages via `terminal()` using heredoc syntax (`python3 << 'PYEOF' ... PYEOF`), not `execute_code`. Reserve `execute_code` for tasks using only stdlib or packages pre-installed in the sandbox.

**DuckDuckGo search package rename:** The `duckduckgo_search` package was renamed to `ddgs`. Install with `pip install ddgs`. The old import `from duckduckgo_search import DDGS` still works but shows a deprecation warning. Use `from ddgs import DDGS` instead.

## What Does NOT Work from Headless

- **DuckDuckGo/Bing/Brave search:** All block with captchas or return JS-heavy pages from curl/scripts. Brave Search returns HTML but snippets are noisy and hard to parse — IF/Q values extracted are unreliable mixtures of sidebar filters and unrelated content
- **SAGE journals (journals.sagepub.com):** Behind Cloudflare challenge — returns JS challenge pages. Use `sage.cnpereading.com` instead (see SAGE Publisher Section).
- **SCImago (scimagojr.com):** Behind Cloudflare challenge — returns 403 Forbidden for all programmatic requests, including curl with User-Agent headers
- **Taylor & Francis (tandfonline.com):** Behind Cloudflare challenge
- **Elsevier Scopus API:** Requires API key (authentication_error without one)
- **Clarivate/JCR:** No public API, requires institutional access
- **Springer Link pages:** Return empty content (JS-rendered) — BUT the main journal page (springer.com/journal/{ID}) sometimes returns useful data including IF, APC status, and review policies
- **bioxbio.com:** Returns 404 for all journal lookups
- **letPub (letpub.com.cn):** **WORKS but has strict rate limiting (~25-30 requests per session, then blocks by IP for ~10+ minutes).** Returns actual IF values via search endpoint (regex: `color:#FF5722;font-weight:bold[^>]*>(\d+\.?\d*)`). Rate limit message: "请求页面的速度过快". Use sparingly — batch queries, add 1.5s+ delays between requests. Good for getting the latest JCR IF quickly when OpenAlex/Wikipedia are insufficient.
- **Resurchify:** Returns empty/inaccessible pages
- **SearXNG instances:** Often rate-limited or behind anti-bot challenges
- **Bentham Science (eurekaselect.com):** Returns 403 Forbidden for all programmatic requests

## Publisher-Specific Notes

### Taylor & Francis (tandfonline.com)

**⚠️ tandfonline.com is behind Cloudflare** — all programmatic requests return JS challenge pages. Use Wikipedia API, OpenAlex, and Wikipedia Category Scraping instead.

**T&F Hybrid Model:** Most T&F journals are hybrid (subscription + optional OA). Subscription-mode publication is FREE (no APC). OA route has APC ($2,000-$3,500 typical).

**⚠️ Journals can flip from hybrid to full OA.** Example: Pharmaceutical Biology was hybrid until ~2025, then flipped to full OA with mandatory $2,557 APC. ALWAYS verify current OA status via OpenAlex `is_oa` + `is_in_doaj` fields.

**Wikipedia Category:** `Category:Taylor_%26_Francis_academic_journals` — contains 200+ journals. Use Wikipedia Category Scraping technique above to discover all T&F journals systematically.

**Verified T&F Journals — Natural Products / Cancer / Pharmacology (IF 2–4 range):**

| Journal | ISSN | IF (JCR) | SCIE | Scopus Q | APC Status | Reviews | Notes |
|---------|------|----------|------|----------|------------|---------|-------|
| **Pharmaceutical Biology** | 1388-0209 | ~3.0 | Likely SCIE | Q2 | ⚠️ **FLIPPED TO FULL OA** — $2,557 mandatory APC | ✅ | Was hybrid; now Gold OA. NO LONGER FREE. |
| **Natural Product Research** | 1478-6419 | ~4.3 (2024 JCR) | SCIE | Q1-Q2 | Hybrid (free subscription) | ✅ | IF jumped from ~2.2 to ~4.3 in 2024 JCR |
| **Expert Opinion on Drug Metabolism & Toxicology** | 1742-5255 | ~3.4 | SCIE | Q1-Q2 | Hybrid (free subscription) | ✅ (review-focused) | Expert Opinion series = review-focused |
| **Expert Opinion on Biological Therapy** | 1471-2598 | ~4.0 | Likely SCIE | Q1-Q2 | Hybrid (free subscription) | ✅ (review-focused) | IF near upper boundary |
| **Drug and Chemical Toxicology** | 0148-0545 | ~3.0-3.4 | Likely SCIE | Q1-Q2 | Hybrid (free subscription) | ✅ | Toxicology angle |
| **Xenobiotica** | 0049-8254 | ~2.2 | SCI | Q2 | Hybrid (free subscription) | ✅ | Xenobiotic metabolism |
| **Pharmaceutical Development and Technology** | 1083-7450 | ~3.0-3.9 | Likely SCIE | Q1-Q2 | Hybrid (free subscription) | ✅ | Drug development focus |
| **Biomarkers** | N/A | ~2.0 | Likely SCIE | Q2 | Hybrid | ✅ | Biomarker focus |
| **Current Medical Research and Opinion** | 0300-7995 | ~2.3 | Likely SCIE | Q2 | Hybrid (some OA free) | ✅ | General medical research |

**T&F Journals EXCLUDED (IF outside 2–4 range):**

| Journal | IF | Reason |
|---------|-----|--------|
| Expert Opinion on Drug Discovery | ~7.0 | Too high |
| Expert Opinion on Drug Delivery | ~6.6 | Too high |
| Expert Opinion on Therapeutic Targets | ~4.6 | Too high |
| Expert Opinion on Investigational Drugs | ~6.5 | Too high |
| Journal of Drug Targeting | ~4.5 | Above range |
| Cell Cycle | ~7.7 | Too high |
| Gut Microbes | ~15.3 | Too high |
| Critical Reviews in Toxicology | ~5.3 | Too high |
| Human Vaccines & Immunotherapeutics | ~4.5 | Above range |
| Acta Oncologica | ~4.3 | Above range |

**Key T&F Insight for Natural Products + Cancer:** Pharmaceutical Biology is the BEST scope match (pharmacognosy, natural products, biological evaluation) but has FLIPPED TO FULL OA with mandatory APC. For free publication, **Natural Product Research** (IF ~4.3, hybrid) or **Expert Opinion on Drug Metabolism & Toxicology** (IF ~3.4, review-focused) are the top alternatives.

### Frontiers (frontiersin.org) — Gold OA Only, Never Hybrid

**CRITICAL: ALL Frontiers journals are 100% Gold Open Access.** Frontiers does NOT offer hybrid publishing. There are NO subscription or hybrid options at any Frontiers journal.

**"Hybrid" false positive pitfall:** Searching for "hybrid" on Frontiers website returns section names (e.g., "Hybrid Scanning" — a section within Frontiers in Pharmacology), NOT publishing model information. Do not use the word "hybrid" on a Frontiers page to determine journal type.

**Frontiers about pages work for metric extraction.** Unlike most publisher sites, `https://www.frontiersin.org/journals/{slug}/about` returns server-rendered HTML that can be scraped with regex:
```python
import urllib.request, re
url = "https://www.frontiersin.org/journals/pharmacology/about"
req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
content = urllib.request.urlopen(req, timeout=10).read().decode('utf-8', errors='ignore')
# Extract IF: look for "(number) Impact Factor" pattern
if_match = re.search(r'(\d+\.?\d*)\s*Impact\s*Factor', content, re.IGNORECASE)
# Extract ISSN from JSON-LD
issn_match = re.search(r'"issn"\s*:\s*\["(\d{4}-\d{4})"', content)
```

**Frontiers APC:** ~EUR 2,500 per article (varies by journal and article type). Financial discounts available.

**Verified Frontiers IF values (from about pages, August 2026):**

| Journal | ISSN | IF | CiteScore | Scopus Q |
|---------|------|-----|-----------|----------|
| Frontiers in Pharmacology | 1663-9812 | 5.4 | 9.5 | Q2 |
| Frontiers in Drug Discovery | 2674-0338 | 5.8 | — | Q2 |
| Frontiers in Plant Science | 1664-462X | 5.9 | — | Q2 |
| Frontiers in Microbiology | 1664-302X | 5.8 | — | Q2 |
| Frontiers in Bioeng. & Biotech. | 2296-4185 | 5.8 | — | Q2 |
| Frontiers in Cell & Dev. Bio. | 2296-634X | 5.3 | — | Q2 |
| Frontiers in Chemistry | 2296-2646 | 5.3 | — | Q2 |
| Frontiers in Molecular Biosciences | 2296-889X | 4.4 | — | Q2 |
| Frontiers in Medicine | 2296-858X | 3.6 | — | Q1-Q2 |
| Frontiers in Oncology | 2234-943X | 3.4 | — | Q2 |
| Frontiers in Molecular Medicine | 2674-0095 | N/A | — | Q1-Q2 |

All Frontiers journals are SCIE-indexed. All accept reviews. All have mandatory APCs. None are hybrid.

**Publisher website exceptions (sometimes work):**
- **Frontiers (frontiersin.org)** — About pages (`/journals/{slug}/about`) return server-rendered HTML. Regex extract: `(\d+\.?\d*)\s*Impact\s*Factor` for IF, `"issn"\s*:\s*\["(\d{4}-\d{4})"'` for ISSN from JSON-LD. Also check for Q1/Q4, SCIE/SCI mentions. Works reliably for all ~100+ Frontiers journals.
- **Springer main journal pages** (`springer.com/journal/{ID}`) — returns useful text including IF, APC status, review policies. Example: found "Publication fee eliminated as of Jan 2025" for Journal of Natural Medicines.
- **DOAJ API** — works for OA journal verification
- **SAGE cnpereading** (`sage.cnpereading.com/home/{CODE}`) — returns full journal pages with embedded JSON data. Extract IF, APC, OA status via regex on escaped JSON. See SAGE Publisher Section for extraction code. Journal codes: SMO, CIX, TUB, MEF, COJ, CPM, CHP, PHA, PMD, EBM.

## Batch Journal Search Workflow

When searching for journals meeting multiple criteria (e.g., IF range, topic, no APC):

1. **Start with OpenAlex ISSN lookup** (preferred) or concept/topic search to discover candidate journals:
   ```
   # Preferred: ISSN-based (most reliable)
   curl -s "https://api.openalex.org/sources/issn:{ISSN}"
   
   # Fallback: topic search
   curl -s "https://api.openalex.org/sources?search={topic关键词}&per_page=20&filter=type:journal"
   ```

2. **Get detailed data for each candidate** via source ID:
   ```
   curl -s "https://api.openalex.org/sources/{source_id}"
   ```
   Extract: `display_name`, `issn_l`, `host_organization_name`, `is_oa`, `apc_usd`, `summary_stats`

3. **Cross-verify publishers via Crossref** (batch, with 1s delays to avoid 429):
   ```
   curl -s "https://api.crossref.org/journals/{ISSN}"
   ```

4. **For IF values:** Use OpenAlex `summary_stats.2yr_mean_citedness` as proxy, or Wikipedia wikitext extraction for exact JCR IF.

5. **For Scopus Q:** Not reliably available from free APIs. Use OpenAlex citedness relative to field, or note as "verify manually."

**Rate limiting:** Crossref returns 429 after ~20-30 rapid requests. Add `time.sleep(0.5)` between requests in scripts.

## OpenAlex search quirks:** The `/sources?search={name}` endpoint returns empty for MANY specific journal names (e.g., "Journal of the Science of Food and Agriculture", "Food Chemistry"). This is a known issue. **Always prefer ISSN-based lookup** (`/sources/issn:{ISSN}`) over name search when you have the ISSN. If you only have a name, try both the search endpoint AND searching by shorter/alternative name variants. When both fail, use Crossref API for ISSN lookup, then OpenAlex ISSN endpoint.

**Also:** The `publisher_lineage` filter returns 0 results for some publishers (confirmed for Bentham Science). If filtering by publisher returns nothing, search by journal name or ISSN instead.

## ISI Status Determination

OpenAlex doesn't directly report SCIE/SCI/ESCI. Use Wikipedia wikitext for this:
- Look in `abstracting_and_indexing` section
- "Science Citation Index" → SCI
- "Science Citation Index Expanded" → SCIE
- "Emerging Sources Citation Index" → ESCI

## Scopus Q Ranking

Not available from free APIs. Estimate from:
1. OpenAlex `2yr_mean_citedness` relative to field median
2. Wikipedia articles sometimes cite SCImago Q rankings
3. For exact Q rank, use SCImago website manually

## APC (Article Processing Charge)

OpenAlex provides `apc_usd` — the OA publication fee. **Critical distinction:**
- `apc_usd: null` → No OA fee data in OpenAlex (may still have OA option)
- `apc_usd: 2880` → This is the OA APC. Subscription-mode authors typically pay NOTHING.
- `is_oa: false` → Hybrid or subscription journal. Authors can publish without paying APC.
- `is_oa: true` → Fully OA journal. May charge APC, but some (e.g., Spandidos Publishing) charge NO fees.

**To determine if authors pay nothing:**
1. Check `is_oa` field: `false` = subscription model = free for authors
2. If `is_oa: true`, check publisher: Spandidos journals are free despite being OA
3. Some subscription journals have OA options with APC — the subscription path is still free
4. "No APC" in OpenAlex means no OA fee data, not necessarily free OA

**⚠️ Journals can flip from hybrid to full OA.** Example: Pharmaceutical Biology (Taylor & Francis) was hybrid until ~2025, then flipped to full OA with mandatory $2,557 APC (confirmed is_oa=True, in DOAJ=True as of Aug 2026). Always re-verify OA status via OpenAlex `is_oa` + `is_in_doaj` fields rather than relying on historical knowledge.

## Review Articles

Not directly available from APIs. Check:
1. Journal website "Aims & Scope" or "Guide for Authors"
2. Wikipedia article on the journal
3. Some journals (e.g., "Critical Reviews in...") publish exclusively reviews
4. **PubMed scope verification** (see below) — most reliable evidence

## PubMed Scope Verification

**Critical technique:** Verify a journal actually publishes in your topic area by searching PubMed for articles in that journal about your topic. A journal's "Aims & Scope" may claim broad coverage, but PubMed evidence of actual published articles proves real editorial acceptance.

```bash
# Search for reviews in a specific journal about a specific topic
QUERY=$(python3 -c "import urllib.parse; print(urllib.parse.quote('\"Journal Name\"[Journal] AND (natural products[MeSH]) AND (breast cancer[MeSH]) AND review[pt]'))")
curl -s "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&term=${QUERY}&retmode=json&retmax=5"
```

**What to count:** Number of reviews on your specific topic. Journals with 5+ matching reviews are strong candidates; 0 suggests the journal doesn't publish in that niche.

**Example result interpretation:**
- 92 reviews → ideal topic fit (e.g., Journal of Ethnopharmacology for natural products+cancer)
- 20+ reviews → strong fit
- 5-10 reviews → reasonable fit
- 0 reviews → likely out of scope for this journal

**Workflow:**
1. Search: `"<Journal>"[Journal] AND (topic keywords) AND review[pt]`
2. Count results
3. Fetch one example article via `esummary` to confirm relevance
4. Rank journals by count of matching reviews

## Output Format

Present results as a structured table with columns:
| Journal | Impact Factor | ISI Status | Scopus Q Rank | APC | Publisher | Reviews? |

Always note the data source and year for each IF value.

## Alternative Publishers (Beyond Major Publishers)

When users ask for journals from publishers NOT in the major list (Elsevier, Wiley, Springer, T&F, SAGE, ACS, OUP, RSC, Frontiers, MDPI), check these.

### Pitfall: Most Alternative Publishers Are NOT Hybrid

**Systematic verification (August 2026) found that ONLY Bentham Science has genuine hybrid journals meeting IF ≥ 2.0 criteria.** All other alternative publishers are either Gold OA, predatory, book-only, or absorbed by major publishers. See `references/alternative-publishers-landscape.md` for the full breakdown.

### ⚠️ Bentham Science (Hybrid, Subscription Free) — CAUTION: Multiple Issues

**CRITICAL WARNINGS:**
1. **Citation manipulation:** Several Bentham Science journals were flagged by Scopus in 2023-2024 for citation manipulation. Verify current Scopus/JCR status before submitting.
2. **Hidden fees at the end:** Users report Bentham charges unexpected fees during production/proofing stage, even for subscription route. The "free subscription" claim is misleading — charges appear later in the process. **EXCLUDE Bentham entirely if user wants zero fees.**
3. **User exclusion:** If user says "Bentham" or "نه Bentham" — skip all Bentham journals immediately. Do not suggest them as alternatives.

- All subscription journals are HYBRID with free subscription route
- 120+ subscription journals + ~40 Gold OA (under "Bentham Open" brand — avoid)
- See `references/bentham-science-journals.md` for full list
- **Best for:** Medicinal chemistry, drug targets, cancer drug targets
- **Key journals:** Current Drug Targets (IF ~3.5-4.0), Mini-Reviews in Medicinal Chemistry (IF ~3.4-3.8), Current Cancer Drug Targets (IF ~3.0), The Natural Products Journal (IF ~1.5-2.1)
- **⚠️ Avoid Bentham Open** (predatory concerns) — use Bentham Science (subscription) only
- **Pitfall:** OpenAlex `publisher_lineage` filter returns 0 results for Bentham. Search by journal name or ISSN instead: `curl -s "https://api.openalex.org/sources?search=current+drug+targets&per_page=5"`

### Spandidos Publishing (OA, No APC)
- OA journals with NO APC (unusual for OA)
- Oncology Reports, Molecular Medicine Reports, Experimental and Therapeutic Medicine
- Good for cancer biology

### Thieme (Drug Research)
**Thieme Medical Publishers** — reputable publisher:
- **Drug Research** (formerly Arzneimittel-Forschung) — IF ~3.10, Q2
- Good for pharmacology studies including natural product drug research

### SAGE Publishing (journals.sagepub.com / sage.cnpereading.com) — Hybrid + Gold OA

**⚠️ `journals.sagepub.com` is behind Cloudflare** — all programmatic requests return JS challenge pages. **Use `sage.cnpereading.com` instead** (SAGE's reading platform) — it works and contains the same data.

**SAGE Acquisitions:**
- **Mary Ann Liebert, Inc.** acquired December 2024 — Liebert journals are now under SAGE umbrella (e.g., Journal of Medicinal Food, Journal of Current Oncology)
- **Future Science Group** acquired 2022 — Future journals now under SAGE brand
- **IOS Press** partnership — some journals (e.g., Tumor Biology) are hosted on SAGE platform but published by IOS Press

**Extracting Metrics from sage.cnpereading.com:**

The pages are server-rendered React apps with embedded JSON data. Fetch the page, then extract with regex:

```python
import re
# Fetch: curl -sL "https://sage.cnpereading.com/home/{CODE}" -o page.html
# Impact Factor (escaped JSON in script tags):
if_match = re.search(r'impactFactor\\?":\s*\\?"?(\d+\.?\d*)\\?"?', html)
# 5-Year IF:
fiveif_match = re.search(r'impactFactorFive\\?":\s*\\?"?(\d+\.?\d*)\\?"?', html)
# APC (in HTML body text):
apc_match = re.search(r'APC for this journal[^$]*\$(\d[\d,]*)', html)
# Open Access type:
is_oa = 'fullyGoldOpenAccessJournal' in html
# ISSN:
eissn = re.search(r'"eissn"\\?":\s*\\?"(\d{4}-?\d{3}[\dX])', html)
pissn = re.search(r'"pissn"\\?":\s*\\?"(\d{4}-?\d{3}[\dX])', html)
```

**Journal codes** (3-letter codes used in URLs): SMO, CIX, TUB, MEF, COJ, CPM, CHP, PHA, PMD, EBM

**⚠️ CRITICAL: Many SAGE medical journals are ESCI, not SCIE.** Verify indexing status carefully — ESCI journals now receive JCR IFs since 2023, but some institutions don't count ESCI as equivalent to SCIE.

**SAGE Choice (Hybrid OA):** For ~900+ SAGE **subscription** journals, authors can publish OA for **free** via Sage Choice if their institution has a Read & Publish agreement. This is a key path for zero-fee OA publishing. Check institutional agreements at `https://www.sagepub.com/journals/information-for-authors/publishing-options/hybrid-open-access-sage-choice`

**⚠️ Journal Status Changes (verified August 2026):**
- **Tumor Biology** — moved to IOS Press January 2021. Listed on SAGE platform but published by IOS Press. Verify current status before submitting.
- **Experimental Biology and Medicine** — no longer published by SAGE. Moved to SEBM.
- **Journal of Herbal Pharmacotherapy** — published by Taylor & Francis, NOT SAGE (despite similar name).

**Verified SAGE Journals — Natural Products / Cancer / Pharmacology:**

| Journal | Code | IF (JCR 2025) | 5-Yr IF | WoS Core | Scopus Q | APC | OA Type | Reviews | Scope Fit |
|---------|------|--------------|---------|----------|----------|-----|---------|---------|-----------|
| SAGE Open Medicine | SMO | 2.2 | 3.0 | ESCI | Q2 | $2,250 | Gold OA | ✅ | Broad medicine |
| J. Evidence-Based Integrative Medicine | CHP | 3.4 | 3.9 | ESCI | Q1-Q2 | $2,250 | Gold OA | ✅ | Integrative medicine |
| Journal of Current Oncology | COJ | 3.8 | — | Verify | — | Verify | Gold OA | ✅ | Cancer biology |
| Cancer Informatics | CIX | 2.1 | 2.3 | ESCI | Q2 | $3,000 | Gold OA | ✅ | Bioinformatics (weak fit) |
| Journal of Medicinal Food | MEF | 1.8 | 2.1 | SCIE (historical) | Q3 | $49 submit | Gold OA | ✅ | Medicinal foods |
| J. Integrative & Complementary Medicine | CPM | 1.9 | 2.1 | ESCI | Q2-Q3 | Verify | Gold OA | ✅ | Complementary medicine |
| J. Pharmacology & Pharmacotherapeutics | PHA | 1.0 | 0.8 | ESCI | Q3-Q4 | Verify | Gold OA | ✅ | Pharmacology |
| Perspectives in Medicinal Chemistry | PMD | N/A | — | — | — | $1,848 | Gold OA | ✅ | Medicinal chemistry |

**Key takeaways for SAGE journals:**
1. Most relevant SAGE medical journals charge APCs ($1,848–$3,000)
2. Many are ESCI, not SCIE — verify before submitting
3. SAGE Choice (hybrid) allows free OA in subscription journals with institutional agreements
4. For zero fees without institutional agreement: submit to subscription route (non-OA) in a SAGE subscription journal

### Wolters Kluwer / Lippincott Williams & Wilkins / Medknow (OVID Platform)

**⚠️ OVID website (ovid.com) is fully JavaScript-rendered (Next.js)** — all programmatic requests return shell HTML with no content. The LWW website (journals.lww.com) redirects to ovid.com. **Do NOT attempt to scrape either site.**

**Publisher structure:** Wolters Kluwer Health → Lippincott Williams & Wilkins (LWW) + Medknow Publications. All three imprints publish journals on the OVID platform. Medknow journals tend to be OA; LWW journals tend to be subscription/hybrid.

**Discovery technique:** Use OpenAlex publisher-lineage filtering (see above). Two publisher IDs:
- `P4310318547` — Wolters Kluwer (main, includes LWW)
- `P4310320448` — Medknow

**Verified Wolters Kluwer Journals — Oncology / Cancer / Natural Products / Pharmacology (from OpenAlex, August 2026):**

| Journal | Imprint | ISSN | IF (OpenAlex 2yr) | OA | DOAJ | Reviews? | Relevance |
|---------|---------|------|-------------------|----|------|----------|-----------|
| **European Journal of Cancer Prevention** | LWW | 0959-8278 | 2.58 | No | No | Yes | Cancer prevention, dietary/natural agents |
| **Current Opinion in Oncology** | LWW | 1040-8746 | 2.63 | No | No | Yes (invited) | Review-focused; signaling pathways in oncology |
| **Anti-Cancer Drugs** | LWW | 0959-4973 | 1.97 | No | No | Yes | Natural product anti-cancer mechanisms & signaling |
| **The Cancer Journal** | LWW | 1528-9117 | 1.95 | No | No | Yes | Cancer biology, prevention, integrative approaches |
| **American J. Clinical Oncology** | LWW | 0277-3732 | 1.45 | No | No | Yes | Clinical oncology |
| **Journal of Clinical Oncology** | LWW | 0732-183X | 1.63 | No | No | Yes | Premier clinical oncology (ASCOPubs) |
| **Medicine** | WK | 0025-7974 | 1.88 | Yes | Yes | Yes | Broad scope; accepts all topics incl. NP+cancer+signaling |
| **Asian Pacific J. Tropical Biomedicine** | Medknow | 2221-1691 | 1.81 | Yes | Yes | Yes | Natural products, ethnopharmacology, cancer biology |
| **Pharmacognosy Reviews** | Medknow | 0973-6581 | 1.63 | No | No | Yes (primarily reviews) | Natural products pharmacology, cancer signaling |
| **Indian Journal of Pharmacology** | Medknow | 0253-7613 | 1.20 | No | No | Yes | Pharmacology incl. natural product mechanisms |
| **World J. Traditional Chinese Medicine** | Medknow | 2311-8571 | 1.22 | Yes | Yes | Yes | Herbal/traditional medicine, some cancer content |
| **Indian J. Pharmaceutical Sciences** | Medknow | 0250-474X | 0.25 | Yes | No | Yes | Pharmaceutical sciences incl. natural products |
| **Journal of Carcinogenesis** | Medknow | 0974-6773 | 0.01 | Yes | No | Yes | Carcinogenesis mechanisms |
| **Pharmacognosy Research** | Medknow | 0974-8490 | 0.59 | No | No | Yes | Pharmacognosy/natural products |

**WK Publisher Notes:**
- **Free OA (no APC):** Medicine, Asian Pacific J. Tropical Biomedicine, World J. TCM, Indian J. Pharm. Sci., Journal of Carcinogenesis, Matrix Science Pharma, Journal of Natural Science Biology and Medicine
- **Subscription (no author fees):** Anti-Cancer Drugs, European J. Cancer Prevention, Current Opinion in Oncology, The Cancer Journal, American J. Clinical Oncology, Pharmacognosy Reviews, Indian J. Pharmacology
- **All accept reviews** — even broad-scope OA journals like Medicine readily accept review articles
- **SCIE/SCI status:** LWW oncology journals are generally SCIE. Medknow journals vary — some are Scopus-only. Verify via Wikipedia wikitext or SCImago manually.
- **Scopus Q rankings:** Not reliably available from free APIs for WK journals. Verify manually on SCImago.

### Future Science Group (Hybrid) — ACQUIRED BY SAGE IN 2022

**Future Science Group** was acquired by SAGE Publishing in 2022. Now operates under SAGE brand.
- Hybrid journals in pharmacology and oncology
- Free subscription route available
- **Best journals:**
  - **Future Medicinal Chemistry** (IF ~3.24, Q1) — BEST MATCH for NP + cancer review
  - **Future Oncology** (IF ~2.61, Q2) — Good for cancer treatment focus
  - **Future Science OA** (IF ~2.82, Q2) — ⚠️ Not SCIE (ESCI only), full OA not hybrid
- Drug Discovery Today: Disease Targets → now part of Elsevier
- **No longer a viable independent alternative publisher** (now part of SAGE)

## Reference Files

- `references/verified-journal-issns.md` — ISSN mappings, JCR values, and verified cancer/pharmacology/natural products journal data for biology/medical journals
- `references/natural-products-cancer-journals.md` — Comprehensive natural products + cancer journal data (IF, ISSN, APC, reviews, Scopus Q)
- `references/bentham-science-journals.md` — Complete Bentham Science journal reference (hybrid model, all relevant journals, ISSN mappings, themed issue strategy)
- `references/alternative-publishers-landscape.md` — Systematic verification of 20+ alternative publishers (Bentham, e-Century, Dove, Hindawi, Nova, Pan Stanford, Future Science, Libertas, OMICS, Austin, InTechOpen, BMC, SciELO) with hybrid vs Gold OA vs predatory status
- `references/additional-verified-journals.md` — Supplementary journal data from verification sessions (Drug and Chemical Toxicology, Molecular Biology Reports, Cytotechnology, updated IF values)
- `references/sage-journals-data.md` — SAGE Publishing journals: IF, APC, indexing, cnpereading extraction patterns, journal codes, status notes (August 2026)
- `references/wolters-kluwer-ovid-journals.md` — Wolters Kluwer/LWW/Medknow journals on OVID platform: verified ISSN, IF, OA status, publisher IDs, journal codes, discovery technique (August 2026)
