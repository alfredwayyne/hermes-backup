# SAGE Publishing Journals — Verified Data

Verified from sage.cnpereading.com + DuckDuckGo searches, August 2026.

## Key Findings

1. **`journals.sagepub.com` is behind Cloudflare** — use `sage.cnpereading.com` instead
2. Many SAGE medical journals are **ESCI, not SCIE** — verify before submitting
3. SAGE acquired **Mary Ann Liebert** (Dec 2024) and **Future Science Group** (2022)
4. **SAGE Choice** allows free OA in ~900+ subscription journals with institutional agreements
5. **Tumor Biology** moved to IOS Press (Jan 2021) — no longer truly SAGE
6. **Experimental Biology and Medicine** — no longer published by SAGE

## Verified SAGE Journals (IF from sage.cnpereading.com, JCR 2025)

| Journal | Code | IF | 5-Yr IF | WoS | APC | OA | Reviews | Topic Fit |
|---------|------|-----|---------|-----|-----|----|---------|-----------|
| SAGE Open Medicine | SMO | 2.2 | 3.0 | ESCI | $2,250 | Gold OA | ✅ | Broad medicine |
| J. Evidence-Based Integrative Medicine | CHP | 3.4 | 3.9 | ESCI | $2,250 | Gold OA | ✅ | Integrative medicine |
| Journal of Current Oncology | COJ | 3.8 | — | Verify | Verify | Gold OA | ✅ | Cancer biology |
| Cancer Informatics | CIX | 2.1 | 2.3 | ESCI | $3,000 | Gold OA | ✅ | Bioinformatics |
| Journal of Medicinal Food | MEF | 1.8 | 2.1 | SCIE (hist.) | $49 submit | Gold OA | ✅ | Medicinal foods |
| J. Integrative & Complementary Medicine | CPM | 1.9 | 2.1 | ESCI | Verify | Gold OA | ✅ | Complementary |
| J. Pharmacology & Pharmacotherapeutics | PHA | 1.0 | 0.8 | ESCI | Verify | Gold OA | ✅ | Pharmacology |
| Perspectives in Medicinal Chemistry | PMD | N/A | — | — | $1,848 | Gold OA | ✅ | Med chemistry |
| Tumor Biology | TUB | ~1.2 | — | SCIE | Verify | Gold OA | ✅ | Cancer (IOS Press) |

## Journal Codes for sage.cnpereading.com URLs

Format: `https://sage.cnpereading.com/home/{CODE}`

- SMO = SAGE Open Medicine
- CIX = Cancer Informatics
- TUB = Tumor Biology
- MEF = Journal of Medicinal Food
- COJ = Journal of Current Oncology
- CPM = Journal of Integrative and Complementary Medicine
- CHP = Journal of Evidence-Based Integrative Medicine
- PHA = Journal of Pharmacology and Pharmacotherapeutics
- PMD = Perspectives in Medicinal Chemistry
- EBM = Experimental Biology and Medicine (no longer SAGE)

## Extraction Regex Patterns

From sage.cnpereading.com HTML (escaped JSON in React hydration scripts):

```python
import re

# Impact Factor
if_match = re.search(r'impactFactor\\?":\s*\\?"?(\d+\.?\d*)\\?"?', html)

# 5-Year IF
fiveif_match = re.search(r'impactFactorFive\\?":\s*\\?"?(\d+\.?\d*)\\?"?', html)

# APC (in body text)
apc_match = re.search(r'APC for this journal[^$]*\$(\d[\d,]*)', html)

# Open Access
is_oa = 'fullyGoldOpenAccessJournal' in html

# ISSN
eissn = re.search(r'"eissn"\\?":\s*\\?"(\d{4}-?\d{3}[\dX])', html)
pissn = re.search(r'"pissn"\\?":\s*\\?"(\d{4}-?\d{3}[\dX])', html)
```

## SAGE Journal Status Notes

- **Tumor Biology** — moved to IOS Press Jan 2021. Still listed on SAGE platform. ISSN: 1423-0380 (eISSN), 1010-4283 (pISSN). Published by IOS Press + ISOBM.
- **Experimental Biology and Medicine** — "no longer published by Sage" per SAGE website. Now published by SEBM.
- **Journal of Herbal Pharmacotherapy** — Taylor & Francis, NOT SAGE.
- **Journal of Medicinal Food** — Mary Ann Liebert (now SAGE subsidiary since Dec 2024). $49 submission fee. IF dropped to 1.8 (JCR 2025) from 2.5 (JCR 2024 with inflation).
- **SAGE Open Medicine** — Broadest scope, accepts all medical topics including reviews. IF 2.2, Q2.
- **J. Evidence-Based Integrative Medicine** — Best IF among SAGE integrative medicine journals. IF 3.4.
