# Verified Journal ISSNs and OpenAlex IDs

Useful ISSN mappings for common biology/medical journals. All verified working with OpenAlex API.

| Journal | ISSN (Print) | ISSN (Online) | OpenAlex 2yr_mean_citedness |
|---------|-------------|---------------|----------------------------|
| Current Medical Science | 2096-5230 | 2523-899X | 2.23 |
| Molecular Biology Reports | 0301-4851 | 1573-4978 | 3.09 |
| Progress in Biophysics and Molecular Biology | 0079-6107 | 1873-1732 | 4.29 |
| European Journal of Pharmaceutics and Biopharmaceutics | 0939-6411 | — | 5.00 |
| Molecular and Cellular Biology | 0270-7306 | 1098-5549 | 2.88 |
| Transcription | 2154-1264 | 2154-1272 | 2.69 |
| Cell Cycle | 1538-4101 | 1551-4005 | 2.27 |
| Epigenomics | 1750-1911 | 1750-192X | 2.81 |
| Critical Reviews in Biochemistry and Molecular Biology | 1040-9238 | 1549-7798 | 8.41 |

## OpenAlex API Tips

- ISSN lookup: `https://api.openalex.org/sources/issn:{ISSN}` — use the print ISSN first
- If print ISSN fails, try the online ISSN
- Name search: `https://api.openalex.org/sources?search={name}&per_page=5`
- The `apc_usd` field is null for journals without OA fee data (not the same as free OA)
- `is_oa: false` means hybrid/subscription journal, not that OA is impossible

## Wikipedia Article Names

For Wikipedia API lookups, use these exact page names:

| Journal | Wikipedia Page Name |
|---------|-------------------|
| Current Medical Science | Current_Medical_Science |
| Molecular Biology Reports | Molecular_Biology_Reports |
| Progress in Biophysics and Molecular Biology | Progress_in_Biophysics_and_Molecular_Biology |
| European Journal of Pharmaceutics and Biopharmaceutics | European_Journal_of_Pharmaceutics_and_Biopharmaceutics |
| Molecular and Cellular Biology | Molecular_and_Cellular_Biology |
| Transcription | Transcription_(journal) |
| Cell Cycle | Cell_Cycle (redirects to biological process — use journal website) |
| Epigenomics | Epigenomics_(journal) |
| Critical Reviews in Biochemistry and Molecular Biology | Critical_Reviews_in_Biochemistry_and_Molecular_Biology |

## JCR IF Values Found (from Wikipedia)

- Molecular Biology Reports: 2.316 (JCR 2020)
- Progress in Biophysics and Molecular Biology: 3.667 (JCR 2020), CiteScore 5.8
- Molecular and Cellular Biology: 5.069 (JCR 2021)
- Epigenomics: 4.979 (JCR 2017) — ranked 31st/166 in Genetics & Heredity
- Critical Reviews in Biochemistry and Molecular Biology: 7.714 (JCR 2014), 6.4 (WoS 2026)
- Current Medical Science: 0.948 (JCR 2017) — outdated, likely improved

## Cancer/Pharmacology/Natural Products Journals (verified via OpenAlex + Crossref, IF range 2.0-3.0)

All verified working with OpenAlex API. IF values from JCR 2023 (training data).

| Journal | ISSN | Publisher | OpenAlex ID | IF (JCR 2023) | ISI | Scopus Q | APC | Topic |
|---------|------|-----------|-------------|----------------|-----|----------|-----|-------|
| Oncology Letters | 1792-1074 | Spandidos Publishing | S58832373 | ~2.9 | SCIE | Q2 | FREE | Cancer |
| Planta Medica | 0032-0943 | Thieme | S39653451 | ~2.7 | SCIE | Q1/Q2 | FREE | Natural Products |
| Natural Product Research | 1478-6419 | Taylor & Francis | S205999849 | ~2.2 | SCIE | Q2 | FREE | Natural Products |
| Anti-Cancer Drugs | 0959-4973 | Lippincott/Wolters Kluwer | S158028025 | ~2.5 | SCIE | Q2 | FREE | Cancer Pharmacology |
| Pharmacognosy Magazine | 0973-1296 | SAGE | S40318847 | ~2.2 | SCIE | Q1/Q2 | FREE | Pharmacognosy |
| Cancer Biomarkers | 2162-304X | IOS Press | — | ~2.0 | SCIE | Q2 | FREE | Cancer |
| Exp Ther Med | 1792-0981 | Spandidos | S15037406 | ~2.4 | SCIE | Q2 | FREE | Cancer/Medicine |
| DNA and Cell Biology | 1044-5498 | Mary Ann Liebert/SAGE | S97146013 | ~2.9 | SCIE | Q2 | FREE | Cell Biology |
| Chem & Biodiversity | 1612-1872 | Wiley | S206700086 | ~2.1 | SCIE | Q2 | FREE | Natural Products |
| Fundam Clin Pharmacol | 0767-3981 | Wiley | S35226884 | ~2.8 | SCIE | Q2 | FREE | Pharmacology |
| Anticancer Research | 0250-7005 | IIAR | S157347057 | ~2.0 | SCIE | Q2 | FREE* | Cancer |
| In Vitro Cell Dev Biol | 1071-2690 | Springer | S97150082 | ~2.0 | SCIE | Q2 | FREE | Cell Biology |
| Drug Chem Toxicol | 0148-0545 | Taylor & Francis | S17820993 | ~3.0 | SCIE | Q2 | FREE | Toxicology |
| Biochimie | 0037-9042 | Elsevier | S75247133 | ~3.0 | SCIE | Q2 | FREE† | Biochemistry |
| Phytochemistry Letters | 1874-3900 | Elsevier | S127984601 | ~2.0 | SCIE | Q2 | FREE | Phytochemistry |
| Molecular Biology | 0026-8933 | Springer/Pleiades | — | ~2.0 | SCIE | Q2 | FREE | Molecular Biology |
| Rev Bras Farmacogn | 0102-695X | Springer | S4210226676 | ~2.9 | SCIE | Q1/Q2 | FREE | Pharmacognosy |
| Free Radical Research | 1029-2470 | Taylor & Francis | S23349031 | ~3.0 | SCIE | Q2 | FREE | Redox Biology |

*Anticancer Research may charge page/color fees despite no APC.
†Biochimie charges $2,880 for OA option; subscription is free.

## Spandidos Publishing Journals (all free to publish)

Spandidos journals are fully OA but charge NO publication fees:
- Oncology Letters (IF ~2.9, SCIE) ✓
- Experimental and Therapeutic Medicine (IF ~2.4, SCIE) ✓
- International Journal of Oncology (IF ~5.2, SCIE) — above 2-3 range
- Oncology Reports (IF ~3.5, SCIE) — above 2-3 range
- Molecular Medicine Reports (IF ~3.4, SCIE) — above 2-3 range

## Publisher APC Notes

- **Elsevier**: Subscription free; OA option has APC ($2,800-$11,000 depending on journal)
- **Wiley**: Subscription free; OA option has APC ($2,500-$4,500)
- **Springer**: Subscription free; OA option has APC ($2,000-$4,000)
- **Taylor & Francis**: Subscription free; some OA options free, others have APC
- **SAGE**: Subscription free; some OA options free
- **Thieme**: Subscription free; some hybrid OA
- **Lippincott/Wolters Kluwer**: Subscription free; OA option varies
- **Spandidos Publishing**: ALL journals free to publish (no APC even for OA)
- **IOS Press**: Subscription free; OA option varies
- **IIAR (Anticancer Research)**: No APC but may have page charges
- **Frontiers Media SA**: ALL journals Gold OA, APC ~EUR 2,500. NO hybrid/subscription options. About pages (`/journals/{slug}/about`) return server-rendered HTML with IF in pattern `(N.N) Impact Factor`.

## Frontiers Journal ISSNs (verified via Crossref + about page JSON-LD)

| Journal | ISSN-L | OpenAlex 2yr_mean_citedness |
|---------|--------|---------------------------|
| Frontiers in Pharmacology | 1663-9812 | 5.4 (JCR) |
| Frontiers in Chemistry | 2296-2646 | 5.3 (JCR) |
| Frontiers in Oncology | 2234-943X | 3.4 (JCR) |
| Frontiers in Drug Discovery | 2674-0338 | 5.8 (JCR) |
| Frontiers in Medicine | 2296-858X | 3.6 (JCR) |
| Frontiers in Molecular Biosciences | 2296-889X | 4.4 (JCR) |
| Frontiers in Cell and Developmental Biology | 2296-634X | 5.3 (JCR) |
| Frontiers in Plant Science | 1664-462X | 5.9 (JCR) |
| Frontiers in Microbiology | 1664-302X | 5.8 (JCR) |
| Frontiers in Bioengineering and Biotechnology | 2296-4185 | 5.8 (JCR) |
| Frontiers in Molecular Medicine | 2674-0095 | N/A (newer journal) |

*All verified working with Crossref API (publisher = Frontiers Media SA) and Frontiers about page scraping.*
