# Alternative Publishers — Hybrid Journal Landscape (August 2026)

Systematic verification of 20+ alternative publishers for HYBRID journals related to natural products, pharmacognosy, and cancer biology.

## Key Finding

**Only Bentham Science has genuine hybrid journals meeting IF ≥ 2.0 criteria.** Future Science Group (acquired by SAGE 2022) has some hybrid journals under SAGE brand. All other alternative publishers are either Gold OA, predatory, book-only, or absorbed by major publishers.

## Publisher Status Summary

| Publisher | Status | Hybrid? | IF ≥ 2.0? | Notes |
|---|---|---|---|---|
| **Bentham Science** | ✅ ACTIVE | YES (subscription + OA option) | YES | 120+ subscription journals, 66 with JCR IF |
| e-Century Publishing | ❌ Gold OA | NO | IF 3.1 (AJCR) | All journals are Gold OA |
| Dove Medical Press | ❌ Gold OA (now T&F) | NO | IF 4.7 (DDDT) | Merged into Taylor & Francis |
| Hindawi | ❌ Gold OA (now Wiley) | NO | — | Merged into Wiley 2021 |
| Nova Science Publishers | ❌ Book publisher | NO | — | No SCIE-indexed journals |
| Pan Stanford Publishing | ❌ Low IF | NO | IF < 2.0 | Current Bioactive Compounds too low |
| Future Science Group | ⚠️ Acquired by SAGE (2022) | SOME (under SAGE) | YES (Future Med Chem ~3.24) | Some journals transferred to T&F/Elsevier |
| Libertas Academica | ❌ Merged | NO | — | Merged into Dove (T&F) |
| OMICS International | ❌ PREDATORY | NO | — | Avoid — predatory publisher |
| Austin Publishing Group | ❌ PREDATORY | NO | — | Avoid — predatory publisher |
| InTechOpen | ❌ Books only | NO | — | No peer-reviewed journals |
| BMC | ❌ Gold OA (now Springer Nature) | NO | IF 2.8 | All journals are Gold OA |
| SciELO | ❌ Platform | NO | — | Aggregator, not a publisher |

## Detailed Findings

### e-Century Publishing Corporation
- **American Journal of Cancer Research** — ISSN: 2156-6976, IF: 3.1 (2025), WoS indexed, PubMed Central. **ALL GOLD OA** (self-described as "Always Publishing, Always Open-Access")
- **American Journal of Translational Research** — ISSN: 1943-8141, IF: 1.8 (2025), WoS indexed. **ALL GOLD OA**
- **International Journal of Clinical and Experimental Pathology** — ISSN: 1936-2625, IF: 1.3 (2025). **ALL GOLD OA**
- **International Journal of Clinical and Experimental Medicine** — ISSN: 1940-5901, IF: 0.6 (2025). **ALL GOLD OA**
- Website confirms: "Always Publishing, Always Open-Access — we are working towards the Freedom of Sciences"

### Dove Medical Press (now Taylor & Francis)
- **Drug Design Development and Therapy** — IF: 4.7, SCIE indexed. **ALL GOLD OA**
- All Dove journals are fully Gold OA with mandatory APCs
- Now part of Taylor & Francis portfolio

### Hindawi (now Wiley)
- Merged into Wiley in 2021
- All journals were Gold OA
- Some journals discontinued or merged into Wiley portfolio
- No longer an independent publisher

### Nova Science Publishers
- Primarily a book publisher (Nova Science Publishers)
- No SCIE-indexed journals in pharmacology, cancer biology, or natural products
- Website: novapublishers.com — catalogs show books, not journals

### Pan Stanford Publishing
- Small publisher with limited journal portfolio
- **Current Bioactive Compounds** — IF too low (<2.0)
- No SCIE-indexed journals meeting IF ≥ 2.0 criteria

### Future Science Group / Future Medicine
- **Acquired by SAGE Publishing in 2022** — now operates under SAGE brand
- Website (future-science.com) returns error code 526 (SSL error)
- Some journals transferred to other publishers:
  - Drug Discovery Today: Disease Targets → Elsevier
  - Pharmacogenomics → Taylor & Francis
  - Expert Review of Anticancer Therapy → Taylor & Francis
- Remaining journals under SAGE: Future Medicinal Chemistry (IF ~3.24, Q1), Future Oncology (IF ~2.61, Q2)
- **Note:** Some journals are ESCI-only (not SCIE) — verify indexing status before submitting

### Libertas Academica
- Merged into Dove Medical Press (now Taylor & Francis)
- Website (la-press.com) now redirects to a gambling site — clearly defunct

### OMICS International
- Listed as predatory on multiple watchdog lists
- Questionable peer review practices
- Known for invitation spam
- **DO NOT SUBMIT** — predatory publisher

### Austin Publishing Group
- Questionable editorial practices
- Not recommended for legitimate publications
- **DO NOT SUBMIT** — predatory publisher

### InTechOpen
- Open access book publisher only
- No peer-reviewed journals in any field
- Website: intechopen.com — books section only

### BMC (BioMed Central) — now Springer Nature
- All BMC journals are 100% Gold Open Access
- **BMC Complementary Medicine and Therapies** — IF: 2.8, Gold OA
- Now part of Springer Nature portfolio
- No hybrid options — all journals require APCs

### SciELO
- Platform/aggregator of open access journals from Latin America
- Not a publisher itself — hosts journals from various publishers
- All journals on SciELO are open access

## OpenAlex Pitfalls for Alternative Publishers

### publisher_lineage filter doesn't work for Bentham
```
# This returns 0 results:
curl -s "https://api.openalex.org/sources?filter=publisher_lineage:https://openalex.org/P4310320079&per_page=50"
# Result: 0 journals found

# Use name search instead:
curl -s "https://api.openalex.org/sources?search=current+drug+targets&per_page=5"
# Result: finds the journal with publisher = "Bentham Science Publishers"
```

### OpenAlex rate limits hit quickly
- Budget: ~$0.0006 remaining after ~25-30 requests
- Resets at midnight UTC
- Error: `{"error":"Rate limit exceeded","message":"Insufficient budget"}`
- Workaround: Use `select=` parameter to minimize response size; batch independent queries; switch to Crossref/Wikipedia when rate-limited

## Bentham Science Verification Notes

Confirmed via Crossref API (all ISSNs verified):
- Current Drug Targets: ISSN 1389-4501 → Publisher: Bentham Science Publishers Ltd.
- Current Medicinal Chemistry: ISSN 0929-8673 → Publisher: Bentham Science Publishers Ltd.
- Mini-Reviews in Medicinal Chemistry: ISSN 1875-5607 → Publisher: Bentham Science Publishers Ltd.
- Anti-Cancer Agents in Medicinal Chemistry: ISSN 1568-0118 → Publisher: Bentham Science Publishers Ltd.
- Current Cancer Drug Targets: ISSN 1568-0096 → Publisher: Bentham Science Publishers Ltd.
- Current Drug Metabolism: ISSN 1389-2002 → Publisher: Bentham Science Publishers Ltd.
- The Natural Products Journal: ISSN 2210-3155 → Publisher: Bentham Science Publishers Ltd.
- Current Vascular Pharmacology: ISSN 1570-1611 → Publisher: Bentham Science Publishers Ltd.

## OpenAlex IF Values (2yr_mean_citedness) vs JCR IF

OpenAlex uses a different metric than JCR. Values are consistently lower:

| Journal | OpenAlex 2yr citedness | JCR IF (est.) | Ratio |
|---|---|---|---|
| Current Drug Targets | 3.79 | ~3.5-4.0 | ~1.0x |
| Current Topics in Medicinal Chemistry | 2.68 | ~3.2 | ~1.2x |
| Current Medicinal Chemistry | 2.56 | ~3.1-3.7 | ~1.3x |
| Mini-Reviews in Medicinal Chemistry | 2.07 | ~3.4-3.8 | ~1.7x |
| Anti-Cancer Agents in Medicinal Chemistry | 1.95 | ~2.5-2.7 | ~1.3x |
| Current Drug Metabolism | 1.95 | ~2.8 | ~1.4x |
| Current Cancer Drug Targets | 1.85 | ~3.0 | ~1.6x |
| The Natural Products Journal | 0.81 | ~1.5-2.1 | ~2.0x |

**Lesson:** OpenAlex 2yr_mean_citedness is a rough proxy. For accurate JCR IF, use Wikipedia or LetPub.

## Data Sources
- OpenAlex API (before rate limit)
- Crossref API (publisher verification)
- Wikipedia REST API (journal background)
- Direct website access (e-Century, Bentham via archive.org)
- Bentham Science Wikipedia article (120+ subscription journals, 66 with JCR IF)
