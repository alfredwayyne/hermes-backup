# Additional Verified Journals (August 2026 Session)

Journals verified during systematic journal search sessions. Supplement to main reference files.

## Taylor & Francis Journals (Verified August 2026)

| Journal | IF (est.) | SCIE | Scopus Q | Free? | Reviews | Relevance |
|---------|-----------|------|----------|-------|---------|-----------|
| **Pharmaceutical Biology** | ~3.0 | ✅ Likely | Q1-Q2 | ✅ Subscription | ✅ | ⭐⭐⭐ Natural Products + Cancer — TOP PICK |
| **Expert Opinion on Drug Metabolism & Toxicology** | 3.4 | ✅ Yes | Q1-Q2 | ✅ Subscription | ✅ | ⭐⭐ Drug metabolism angle |
| **Expert Opinion on Biological Therapy** | 3.97 | ✅ Likely | Q1-Q2 | ✅ Subscription | ✅ | ⭐⭐ Biological therapy angle |
| **Drug and Chemical Toxicology** | 3.36 | ✅ Likely | Q2 | ✅ Subscription | ✅ | ⭐⭐ Toxicology angle |
| **Xenobiotica** | 2.20 | ✅ SCI | Q2-Q3 | ✅ Subscription | ✅ | ⭐ Metabolism angle |
| **Pharmaceutical Development and Technology** | 3.92 | ✅ Likely | Q1-Q2 | ✅ Subscription | ✅ | ⭐ Drug development angle |

**⚠️ Important:** Pharmaceutical Biology may have flipped to Gold OA (~2025). Always verify current OA status via OpenAlex `is_oa` field before submitting.

## Chinese Journal of Natural Medicines (Elsevier — Verified August 2026)

| Journal | IF (est.) | SCIE | Scopus Q | Free? | Reviews | Relevance |
|---------|-----------|------|----------|-------|---------|-----------|
| **Chinese Journal of Natural Medicines** | ~3.0 | ✅ Likely | Q1 | ✅ Subscription | ✅ | ⭐⭐⭐ Natural Medicines — TOP PICK |

## Additional Subscription Journals (Free for Authors)

| Journal | Publisher | IF (JCR) | SCIE | Scopus Q | Reviews | Relevance |
|---------|-----------|----------|------|----------|---------|-----------|
| Toxicology in Vitro | Elsevier | ~3.0 | ✅ | Q1-Q2 | ✅ | ⭐⭐ In vitro NP toxicity |
| Molecular Biology Reports | Springer | 3.2 (2025) | ✅ | Q2 | ✅ | Molecular mechanisms of NPs |
| Cytotechnology | Springer | 2.2 (2025) | ✅ | Q2 | ✅ | Cell culture methods for NP testing |
| Drug and Chemical Toxicology | T&F | ~3.4 | ✅ | Q2 | ✅ | Chemical toxicology of drugs/natural compounds |
| Drug Research | Thieme | ~3.1 | ✅ | Q2 | ✅ | Drug research, pharmacology |
| Drug Development Research | Wiley | ~2.5-3.0 | ✅ | Q2 | ✅ | Drug development (moderate relevance) |

## IF Verification Notes (2025 JCR)

Springer journal IFs verified directly from publisher website (August 2025):
- Archives of Pharmacal Research: **8.2** (2025 JCR) — significantly higher than earlier estimates
- Molecular Biology Reports: **3.2** (2025 JCR)
- In Vitro Cell Dev Biol - Animal: **2.0** (2025 JCR)
- Cytotechnology: **2.2** (2025 JCR)

**Important:** IF values can change significantly between JCR years. The 2024/2025 JCR cycle saw large IF jumps for many journals (see main reference file's inflation warning). Always verify the LATEST JCR IF before submitting.

## User Exclusion List (August 2026)

Journals this user has been rejected from or explicitly excluded:
- **Fitoterapia** — rejected
- **Journal of Natural Medicines** — rejected
- **Chemico-Biological Interactions** — rejected
- **Journal of Ethnopharmacology** — IF too high
- **Phytotherapy Research** — IF too high
- **South African Journal of Botany** — OA only
- **BMC Complementary Medicine** — OA only
- **Natural Product Research** — not relevant
- **Bentham Science** — charges hidden fees at end, excluded entirely
