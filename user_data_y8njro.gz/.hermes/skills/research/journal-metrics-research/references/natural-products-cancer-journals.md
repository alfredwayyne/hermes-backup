# Natural Products, Pharmacognosy & Cancer Therapy Journals — Verified Data

Verified from OpenAlex API + training data knowledge, updated August 2026.

## HYBRID JOURNALS: Natural Products / Pharmacognosy (IF >= 2.0)

All confirmed HYBRID (OpenAlex is_oa=False, is_in_doaj=False). Optional APC for OA path only.

| Journal | Publisher | ISSN | IF (OpenAlex) | IF (JCR est.) | Scopus Q | APC (opt.) | Reviews |
|---------|-----------|------|---------------|---------------|----------|------------|---------|
| Phytomedicine | Elsevier | 0944-7113 | 8.42 | ~6.7 | Q1 | $3,390 | ✅ |
| Journal of Ethnopharmacology | Elsevier | 0378-8741 | 5.17 | ~5.4 | Q1 | $3,500 | ✅ |
| Phytotherapy Research | Wiley | 0951-418X | ~5.5 | ~6.1 | Q1 | $3,200 (opt) | ✅ |
| Natural Product Reports | RSC | 0265-0568 | 8.02 | ~11.4 | Q1 | Contact RSC | ✅ (review-only) |
| Phytochemistry Reviews | Springer | 1568-7767 | 6.33 | ~3.8 | Q1 | $4,390 | ✅ (review-only) |
| Chemico-Biological Interactions | Elsevier | 0009-2797 | ~4.5 | ~5.1 | Q1/Q2 | $3,500 (opt) | ✅ |
| Journal of Natural Products | ACS | 0163-3864 | 3.42 | ~4.8 | Q1 | ACS hybrid | ✅ |
| Phytochemistry | Elsevier | 0031-9422 | 2.93 | ~3.5 | Q1-Q2 | $4,150 | ✅ |
| Natural Product Research | Taylor & Francis | 1478-6419 | 1.40 | ~2.2 | Q2-Q3 | None | ✅ |

## SUBSCRIPTION JOURNALS: Zero Author Fees (Natural Products / Pharmacognosy)

**These journals charge ZERO fees for subscription-mode publication.** No APC, no page charges, no color figure fees. Authors retain copyright.

| Journal | Publisher | ISSN | IF (JCR 2023) | Scopus Q | Reviews | Notes |
|---------|-----------|------|---------------|----------|---------|-------|
| Phytotherapy Research | Wiley | 0951-418X | ~6.1 | Q1 | ✅ | Highest IF among free journals |
| Journal of Ethnopharmacology | Elsevier | 0378-8741 | ~5.4 | Q1 | ✅ | Official journal of Int'l Soc. Ethnopharmacology |
| Chemico-Biological Interactions | Elsevier | 0009-2797 | ~5.1 | Q1/Q2 | ✅ | Good for mechanistic studies |
| South African J. Botany | Elsevier | 0254-6299 | ~3.0 | Q1 | ✅ | Botanical/natural products |
| Journal of Natural Medicines | Springer | 1340-3443 | ~2.6 | Q2 | ✅ | Fee eliminated Jan 2025 |
| Planta Medica | Thieme | 0032-0943 | ~2.5 | Q1/Q2 | ✅ | Official journal of GA |
| Bioorganic & Med. Chemistry Letters | Elsevier | 0960-894X | ~2.5 | Q2 | ✅ | Fast publication, SAR studies |
| Fitoterapia | Elsevier | 0367-326X | ~2.3 | Q2 | ✅ | Medicinal plants, pharmacognosy |
| Natural Product Research | T&F | 1478-6419 | ~2.2 | Q2 | ✅ | Chemistry, isolation, characterization |

## HYBRID JOURNALS: Bentham Science (Subscription Free, IF ≥ 2.0) — EXCLUDE IF USER WANTS ZERO FEES

**⚠️ CRITICAL: Exclude Bentham entirely if user requires zero fees.** Users report hidden charges during production/proofing stage. The "free subscription" claim is misleading.

All confirmed HYBRID (subscription free, OA has APC). Verified SCIE. Accept reviews.

| Journal | ISSN | IF (OpenAlex) | IF (JCR 2023) | Scopus Q | Reviews? | Topic Relevance |
|---------|------|---------------|---------------|----------|----------|----------------|
| **Current Drug Targets** | 1389-4501 | 3.79 | ~3.79 | Q1 | ✅ themed issues | Drug targets in cancer, natural product targets |
| **Current Organic Chemistry** | 1385-2728 | 2.85 | ~2.85 | Q2 | ✅ | Organic chemistry, natural product chemistry |
| **Current Diabetes Reviews** | 1573-3998 | 3.01 | ~3.01 | Q2 | ✅ | Diabetes, metabolic diseases |
| **Current Topics in Medicinal Chemistry** | 1568-0266 | 2.68 | ~2.68 | Q2 | ✅ themed issues | Themed review collections |
| **Current Pharmaceutical Design** | 1381-6128 | 2.69 | ~2.69 | Q2 | ✅ themed issues | Pharmacology, drug design |
| **Current Medicinal Chemistry** | 0929-8673 | 2.56 | ~2.56 | Q2 | ✅ | Medicinal chemistry, rational drug design |
| **Current Neuropharmacology** | 1570-159X | 2.59 | ~2.59 | Q2 | ✅ | Neuropharmacology |
| **Current Vascular Pharmacology** | 1570-1611 | 2.14 | ~2.14 | Q3 | ✅ | Vascular pharmacology |
| **Mini-Reviews in Medicinal Chemistry** | 1389-5575 | 2.07 | ~2.07 | Q2 | ✅ ONLY reviews | Mini-reviews on all aspects of medicinal chemistry |

**⚠️ Bentham citation manipulation warning:** Several Bentham journals were flagged by Scopus in 2023-2024 for citation manipulation. Verify current status before submitting.

## HYBRID JOURNALS: Future Science Group (Acquired by SAGE 2022)

| Journal | ISSN | IF (OpenAlex) | IF (JCR 2023) | Scopus Q | Reviews? | Topic Relevance |
|---------|------|---------------|---------------|----------|----------|----------------|
| **Future Medicinal Chemistry** | 1756-8919 | 3.24 | ~3.24 | Q1 | ✅ | Medicinal chemistry, drug discovery |
| **Future Oncology** | 1479-6694 | 2.61 | ~2.61 | Q2 | ✅ | Oncology, cancer treatment |

**⚠️ Future Science OA** (IF ~2.82, Q2) — Not SCIE (ESCI only), full OA not hybrid.

## HYBRID JOURNALS: Thieme (Drug Research)

| Journal | ISSN | IF (OpenAlex) | IF (JCR 2023) | Scopus Q | Reviews? | Topic Relevance |
|---------|------|---------------|---------------|----------|----------|----------------|
| **Drug Research** | 2194-9379 | 3.10 | ~3.10 | Q2 | ✅ | Drug research, pharmacology |

## ❌ Drugs of the R&D — NOT RECOMMENDED

| Journal | Status | Reason |
|---------|--------|--------|
| Drugs under Experimental and Clinical Research | ❌ Not indexed | IF 0.00, not in SCIE or Scopus |

## HYBRID JOURNALS: Medicinal Chemistry / Drug Discovery (IF >= 2.0)

| Journal | Publisher | ISSN | IF (OpenAlex) | IF (JCR est.) | Scopus Q | APC (opt.) | Reviews |
|---------|-----------|------|---------------|---------------|----------|------------|---------|
| Eur. J. Med. Chemistry | Elsevier | 0223-5234 | 5.86 | ~6.0 | Q1 | $4,710 | ✅ |
| Bioorg. & Med. Chemistry | Elsevier | 0968-0896 | 2.91 | ~3.3 | Q1-Q2 | $3,690 | ✅ |
| Mini-Rev. Med. Chemistry | Bentham | 1875-5607 | 2.05 | ~2.8 | Q2-Q3 | None | ✅ (review-only) |

## HYBRID JOURNALS: Food Science / Toxicology (IF >= 2.0, Natural Product Relevance)

| Journal | Publisher | ISSN | IF (OpenAlex) | IF (JCR est.) | Scopus Q | APC (opt.) | Reviews |
|---------|-----------|------|---------------|---------------|----------|------------|---------|
| Food Chemistry | Elsevier | 0308-8146 | 9.36 | ~8.8 | Q1 | $4,300 | ✅ |
| Int. J. Biol. Macromolecules | Elsevier | 0141-8130 | 8.44 | ~7.7 | Q1 | $3,920 | ✅ |
| J. Sci. Food and Agriculture | Wiley | 0022-5142 | 3.71 | ~4.1 | Q1 | $4,400 | ✅ |
| Food and Chemical Toxicology | Elsevier | 0278-6915 | 2.86 | ~4.3 | Q1 | $4,160 | ✅ |
| J. Medicinal Food | Mary Ann Liebert | 1096-620X | 2.12 | ~2.5 | Q2 | Contact | ✅ |

## HYBRID JOURNALS: Cancer Biology (IF >= 2.0)

| Journal | Publisher | ISSN | IF (OpenAlex) | IF (JCR est.) | Scopus Q | APC (opt.) | Reviews |
|---------|-----------|------|---------------|---------------|----------|------------|---------|
| Leukemia | Springer Nature | 0887-6924 | 6.40 | ~12.8 | Q1 | $4,790 | ✅ |
| Br. J. Cancer | Springer Nature | 0007-0920 | 6.31 | ~8.2 | Q1 | $4,690 | ✅ |
| Eur. J. Cancer | Elsevier | 0959-8049 | 2.65 | ~8.2 | Q1 | $3,800 | ✅ |

## Free OA Journals (No APC, SCIE indexed)

| Journal | IF (OpenAlex) | IF (JCR est.) | Publisher | Scopus Q | ISSN |
|---------|--------------|---------------|-----------|----------|------|
| Oncology Reports | 2.90 | ~2.9 | Spandidos Publishing | Q2 | 1021-335X |
| Oncology Letters | 2.05 | ~2.0 | Spandidos Publishing | Q2 | 1791-3007 |
| Molecular and Clinical Oncology | 2.43 | ~2.4 | Spandidos Publishing | Q2 | 2307-0928 |

**Spandidos Publishing** — All journals are FULLY open access with NO publication fees whatsoever.

## Subscription Journals (Free for subscription publication, SCIE indexed)

| Journal | IF (OpenAlex) | IF (JCR est.) | Publisher | Scopus Q | ISSN |
|---------|--------------|---------------|-----------|----------|------|
| Archives of Pharmacal Research | 7.42* | **8.2** (2025 JCR) ✓ | Springer Nature | Q1 | 0253-6269 |
| Chinese Journal of Natural Medicines | 3.80 | ~3.0-4.0 | Elsevier | Q1-Q2 | 1672-3651 |
| Drug Development Research | 3.44 | ~2.5-3.0 | Wiley | Q2 | 0272-4391 |
| Toxicology in Vitro | 3.05 | ~3.0 | Elsevier | Q1-Q2 | 0887-2333 |
| J. Biochemical and Molecular Toxicology | 2.74 | ~3.0 | Wiley | Q2 | 0887-2082 |
| Archiv der Pharmazie | 3.65 | ~3.0-4.0 | Wiley | Q1-Q2 | 0365-6233 |
| Pharmacological Reports | 3.85 | ~3.0-3.5 | Elsevier | Q1-Q2 | 1734-1140 |
| Pharmacology Biochemistry and Behavior | 2.77 | ~2.5-3.0 | Elsevier | Q1-Q2 | 0091-3057 |
| Pharmaceutical Research | 3.57 | ~3.0-3.5 | Springer | Q1-Q2 | 0724-8741 |
| Plant Foods for Human Nutrition | 3.32 | ~2.5-3.5 | Springer | Q1-Q2 | 0033-5134 |
| Fitoterapia | 2.72 | ~2.7 | Elsevier | Q1/Q2 | 0367-326X |
| Planta Medica | 0.56* | ~2.5-2.6 | Thieme Medical | Q1/Q2 | 0032-0943 |
| Journal of Natural Medicines | 0.56* | **2.6** ✓ | Springer Nature | Q2/Q3 | 1340-3443 |
| Journal of Herbal Medicine | 2.25 | ~2.3 | Elsevier | Q2/Q3 | 2210-8033 |
| Cancer Chemotherapy and Pharmacology | 2.17 | ~2.2 | Springer Nature | Q2/Q3 | 0345-5351 |
| Anti-Cancer Drugs | 1.94 | ~2.0 | Wolters Kluwer | Q2 | 0959-4973 |
| **Current Pharmaceutical Design** | 2.68 | **2.208** ✓ | Bentham Science | Q1-Q2 | 1381-6128 |
| **Current Cancer Drug Targets** | 2.68 | **2.912** ✓ | Bentham Science | Q1-Q2 | 1568-0096 |
| **Integrative Cancer Therapies** | — | **2.657** ✓ | SAGE Publications | Q2 | 1534-7354 |

*Note: OpenAlex 2yr_mean_citedness for Planta Medica and Journal of Natural Medicines was anomalously low (~0.56) — likely a data issue. JCR values are more reliable.*

**Journal of Natural Medicines (Springer) — VERIFIED AUGUST 2026:**
- IF 2.6 (JCR 2023, confirmed via Springer page)
- SCIE indexed ✓ (confirmed via Springer page + WOS)
- **NO APC** — Publication fee eliminated as of Jan 2025; subscription route is free
- Accepts: Reviews, Mini-Reviews, Original Papers, Notes, Rapid Communications
- Topics: herbal medicines, natural products, phytochemistry
- **Strong candidate for natural products + cancer review**

**Current Pharmaceutical Design (Bentham Science) — VERIFIED AUGUST 2026:**
- IF 2.208 (JCR 2023, confirmed via Wikipedia)
- SCIE indexed ✓
- Subscription publishing is free (Bentham model: OA has APC, subscription is free)
- Bentham journals accept review articles
- Topics: drug design, pharmacology — relevant to drug discovery from natural products

**Current Cancer Drug Targets (Bentham Science) — VERIFIED AUGUST 2026:**
- IF 2.912 (JCR 2023, confirmed via Wikipedia)
- SCIE indexed ✓
- Subscription publishing is free (same Bentham model)
- Accepts reviews
- Topics: cancer drug targets — directly relevant to breast cancer research

## Additional Verified Journals (PubMed scope verification)

| Journal | Publisher | IF (Wikipedia JCR) | ISI Status | Scopus Q | Reviews Found |
|---------|-----------|-------------------|------------|----------|---------------|
| Pharmaceutical Biology | Taylor & Francis | ~2.0-2.8 | SCIE | Q1-Q2 | 20 NP+cancer |
| Chinese J. Integrative Medicine | Springer | 1.978 (2020) | SCIE | Q2 | 27 NP+cancer |
| South African J. Botany | Elsevier | 3.1 (2022) | SCIE | Q1-Q2 | Botanical |

## Discontinued/Dropped Journals (DO NOT SUBMIT)

| Journal | Status | Notes |
|---------|--------|-------|
| Evidence-Based CAM | Discontinued Sept 2024 | Delisted by Clarivate, acquired by Wiley/Hindawi |
| Asian Pacific J. Cancer Prevention | Dropped from JCR 2015 | IF was 2.514 in 2014, no current IF |

## JOURNALS CHECKED BUT EXCLUDED (August 2026)

| Journal | Reason for Exclusion |
|---------|---------------------|
| Pharmaceutical Biology (T&F) | **FLIPPED TO FULL OA** — is_oa=True, in DOAJ=True, APC $2,557 mandatory. No longer hybrid. |
| Chemistry of Natural Compounds (Springer) | IF ~0.94 → Below 2.0 threshold |
| Russian J. Bioorganic Chemistry (Springer) | IF ~1.3 → Below 2.0 threshold |
| African J. Pharmacy and Pharmacology | **Pure OA** (is_oa=True). Not hybrid. |
| J. Ethnobiology and Ethnomedicine (BMC) | **Pure OA** (BMC journal). Not hybrid. |
| Rev. Bras. Farmacognosia (Springer) | IF ~1.41 → Below 2.0 threshold |
| J. Herbs, Spices & Medicinal Plants (T&F) | IF ~1.25 → Below 2.0 threshold |
| Pharmacognosy Reviews (Medknow) | IF ~1.84 → Below 2.0 threshold |
| Evidence-Based CAM | Discontinued Sept 2024 |
| Asian Pacific J. Cancer Prevention | Dropped from JCR 2015 |
| Phytochemistry Letters (Elsevier) | IF 4.072 → Above 3.0 range |
| Journal of Ethnopharmacology (Elsevier) | IF 4.360 → Above 3.0 range |
| Biochemical Systematics and Ecology (Elsevier) | IF 1.462 → Below 2.0 |
| South African Journal of Botany (Elsevier) | IF 3.1 → Above 3.0 range |
| Industrial Crops and Products (Elsevier) | IF ~6.4 → Above 3.0 range |
| Frontiers in Pharmacology | **GOLD OA** — IF 5.4, all Frontiers journals are 100% Gold OA with ~EUR 2,500 APC. No hybrid option. |
| Molecules (MDPI) | IF ~4.6 → Above 3.0 range + **GOLD OA** with APC |
| Plants (MDPI) | IF ~4.6 → Above 3.0 range + has APC |
| Biology (MDPI) | IF 5.168 → Above 3.0 range + has APC |
| Pharmacognosy Magazine (SAGE) | IF unclear (~0.8 citedness), likely below 2.0 |
| International Journal of Green Pharmacy | Not indexed, no impact metrics |
| Avicenna Journal of Phytomedicine | H-index 2, not indexed |
| Iranian Journal of Pharmaceutical Research | H-index 38, not SCIE |
| Research in Pharmaceutical Sciences | Not indexed in Scopus/WOS |
| Bangladesh Journal of Pharmacology | IF 1.6 → Below 2.0 |
| Chinese J. Integrative Medicine | IF 1.978 → Below 2.0 |
| Chemistry of Natural Compounds | IF 0.809 → Below 2.0 |

## GOLD OA JOURNALS: Frontiers (IF >= 2.0, all have APC, none are hybrid)

**Frontiers is 100% Gold Open Access.** All journals require APCs (~EUR 2,500). No hybrid or subscription options exist.

| Journal | ISSN | IF | CiteScore | Scopus Q | APC | Reviews | Relevance |
|---------|------|-----|-----------|----------|-----|---------|-----------|
| Frontiers in Pharmacology | 1663-9812 | 5.4 | 9.5 | Q2 | ~EUR 2,500 | ✅ | NP + Cancer (Ethnopharmacology section) |
| Frontiers in Drug Discovery | 2674-0338 | 5.8 | — | Q2 | ~EUR 2,500 | ✅ | Anti-Cancer Drugs section |
| Frontiers in Plant Science | 1664-462X | 5.9 | — | Q2 | ~EUR 2,500 | ✅ | Medicinal & Aromatic Plants |
| Frontiers in Oncology | 2234-943X | 3.4 | — | Q2 | ~EUR 2,500 | ✅ | Cancer Cell Biology |
| Frontiers in Microbiology | 1664-302X | 5.8 | — | Q2 | ~EUR 2,500 | ✅ | Microbial Natural Products |
| Frontiers in Bioeng. & Biotech. | 2296-4185 | 5.8 | — | Q2 | ~EUR 2,500 | ✅ | Synthetic Biology |
| Frontiers in Chemistry | 2296-2646 | 5.3 | — | Q2 | ~EUR 2,500 | ✅ | Phytochemistry |
| Frontiers in Cell & Dev. Bio. | 2296-634X | 5.3 | — | Q2 | ~EUR 2,500 | ✅ | Cancer Cell Biology |
| Frontiers in Molecular Biosciences | 2296-889X | 4.4 | — | Q2 | ~EUR 2,500 | ✅ | Molecular Diagnostics |
| Frontiers in Medicine | 2296-858X | 3.6 | — | Q1-Q2 | ~EUR 2,500 | ✅ | Pharmacology & Molecular Therapy |
| Frontiers in Molecular Medicine | 2674-0095 | N/A | — | Q1-Q2 | ~EUR 2,500 | ✅ | Molecular Medicine |

*All Frontiers journals verified via Crossref (publisher = Frontiers Media SA) and about page scraping (IF, ISSN from JSON-LD).*

## Publisher Notes

- **Elsevier:** Subscription free; OA option $2,400-$4,710
- **Springer:** Subscription free; OA option $2,000-$4,390
- **RSC:** Subscription free; contact for OA pricing
- **ACS:** Subscription free; hybrid OA available
- **Wiley:** Subscription free; OA option $2,500-$4,400
- **Taylor & Francis:** Subscription free; some OA free, others have APC
- **Thieme:** Subscription free; hybrid OA
- **Bentham:** Subscription free; some hybrid OA
- **Mary Ann Liebert:** Subscription free; hybrid OA
- **Spandidos Publishing:** ALL journals fully OA, ZERO fees
- **Frontiers Media SA:** ALL journals fully Gold OA, APC ~EUR 2,500. NO hybrid or subscription options. "Hybrid" mentions on Frontiers pages refer to section names (e.g., "Hybrid Scanning"), NOT publishing model.

## ⚠️ 2024 JCR IF Inflation Warning (August 2026)

**Many journals have seen massive IF jumps in the 2024 JCR cycle.** IFs verified via LetPub (2024 JCR) vs earlier data:

| Journal | IF (JCR 2023 est.) | IF (JCR 2024 via LetPub) | Change |
|---------|-------------------|------------------------|--------|
| Anticancer Research | ~2.0 | **5.7** | +185% |
| Journal of Medicinal Food | ~2.5 | **5.1** | +104% |
| South African J. Botany | ~3.1 | **5.5** | +77% |
| Phytotherapy Research | ~3.0 | **7.3** | +143% |
| Journal of Integrative Medicine | ~2.8 | **6.9** | +146% |
| Complementary Medicine Research | ~2.4 | **5.0** | +108% |
| Journal of Herbal Medicine | ~2.3 | **5.0** | +117% |
| Pharmacological Reports | ~2.8 | **6.3** | +125% |
| Natural Product Research | ~2.2 | **4.3** | +95% |
| Natural Product Communications | ~1.4 | **5.3** | +279% |

**Implication:** The IF ranges in the tables above reflect JCR 2023 values. Journals that appeared to be in the 2.0-3.0 range in 2023 may now be well above 3.0. When selecting journals for submission, always verify the LATEST JCR IF before submitting.

## Verification Sources

- **Crossref API:** Publisher name confirmed for all journals
- **PubMed/NCBI:** Indexing status verified; article counts and review counts
- **Wikipedia API:** JCR IF values, Scopus Q rankings, indexing status
- **OpenAlex API:** OA status, IF proxy, APC pricing
- **LetPub (letpub.com.cn):** Most current JCR IF values (2024+), but rate-limited (~25-30 requests/session)

## Limitations

- OpenAlex IF values may differ from JCR by 10-30%
- Scopus Q rankings not available from free APIs; verify manually on SCImago
- Planta Medica IF anomalous in OpenAlex; use JCR value (~2.5)
- Always verify exact current IF from JCR before submission
