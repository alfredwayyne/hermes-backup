# Wolters Kluwer / LWW / Medknow Journals — Verified Data (OVID Platform)

Verified via CrossRef API (publisher confirmation) + OpenAlex API (metrics), August 2026.

## Publisher Structure

- **Wolters Kluwer Health** — parent
  - **Lippincott Williams & Wilkins (LWW)** — subscription/hybrid medical journals
  - **Medknow Publications** — Gold OA medical journals (many free, no APC)
- **OVID Platform** — journal hosting/delivery platform (ovid.com). NOT scrapable (Next.js JS-rendered).
- **LWW website** (journals.lww.com) redirects to ovid.com.

## OpenAlex Publisher IDs

- `P4310318547` — Wolters Kluwer (main, includes LWW)
- `P4310320448` — Medknow
- `P4310315860` — Wolters Kluwer Health

## LWW Journals (Subscription/Hybrid)

| Journal | ISSN | IF (OpenAlex) | OA | DOAJ | Works | Total Cited |
|---------|------|---------------|----|------|-------|-------------|
| European J. Cancer Prevention | 0959-8278 | 2.58 | No | No | 3,402 | 75,669 |
| Current Opinion in Oncology | 1040-8746 | 2.63 | No | No | 3,872 | 95,490 |
| Anti-Cancer Drugs | 0959-4973 | 1.97 | No | No | 5,042 | 107,815 |
| The Cancer Journal | 1528-9117 | 1.95 | No | No | 1,936 | 58,962 |
| American J. Clinical Oncology | 0277-3732 | 1.45 | No | No | 6,181 | 140,510 |
| Journal of Clinical Oncology | 0732-183X | 1.63 | No | No | 174,152 | 4,482,257 |
| Chinese Medical Journal | 0366-6999 | 4.56 | No | No | — | — |
| Medicine | 0025-7974 | 1.88 | Yes | Yes | 51,281 | 859,889 |
| Therapeutic Drug Monitoring | 0163-4356 | — | No | No | — | — |
| Pharmacogenetics | 0960-314X | — | No | No | — | — |

## Medknow Journals (Gold OA)

| Journal | ISSN | IF (OpenAlex) | OA | DOAJ | Works | Total Cited |
|---------|------|---------------|----|------|-------|-------------|
| Pharmacognosy Reviews | 0973-6581 | 1.63 | No | No | 496 | 36,221 |
| Asian Pacific J. Tropical Biomedicine | 2221-1691 | 1.81 | Yes | Yes | 2,344 | 78,760 |
| Indian Journal of Pharmacology | 0253-7613 | 1.20 | No | No | 3,609 | 59,406 |
| World J. Traditional Chinese Medicine | 2311-8571 | 1.22 | Yes | Yes | 546 | 3,624 |
| Indian J. Pharmaceutical Sciences | 0250-474X | 0.25 | Yes | No | 5,412 | 53,995 |
| Journal of Natural Science Biology and Medicine | 0976-9668 | 0.00 | Yes | No | 914 | 17,570 |
| Matrix Science Pharma | 2521-0432 | 0.89 | Yes | No | 132 | 751 |
| Journal of Carcinogenesis | 0974-6773 | 0.01 | Yes | No | 1,494 | 11,896 |
| Pharmacognosy Research | 0974-8490 | 0.59 | No | No | 1,378 | 19,223 |
| Brain Circulation | 2394-8108 | 2.82 | Yes | Yes | — | — |
| International J. Preventive Medicine | 2008-7802 | 1.49 | Yes | Yes | — | — |
| Asia-Pacific J. Oncology Nursing | 2347-5625 | 2.19 | Yes | Yes | — | — |
| Journal of Acute Disease | 2221-6189 | 0.60 | Yes | Yes | — | — |

## OVID-Specific Journal Codes

These codes map to OVID journal URLs (https://www.ovid.com/journals/{code}):

| Code | Journal | Status |
|------|---------|--------|
| ahm | Acupuncture and Herbal Medicine | Active |
| ajco | American J. Clinical Oncology | Active |
| coonc | Current Opinion in Oncology | Active |
| rehabonc | Rehabilitation Oncology | Active |
| jpho | J. Pediatric Hematology/Oncology | Active |
| canc | Cancer | Active (redirects) |
| med | Medicine | Active (redirects to Mediastinum) |
| pharm | Pharmacotherapy | Active |

## Key Takeaways for WK/OVID

1. **Best for NP + cancer + signaling:** Medicine (broad OA, free), European J. Cancer Prevention (subscription, IF 2.58), Anti-Cancer Drugs (subscription, IF 1.97)
2. **Free publication:** All Medknow OA journals + LWW subscription journals
3. **All accept reviews** including review-focused Current Opinion in Oncology
4. **SCIE verification needed:** Medknow journals vary; LWW oncology journals generally SCIE
5. **OVID platform is NOT scrapable** — use CrossRef/OpenAlex APIs instead
