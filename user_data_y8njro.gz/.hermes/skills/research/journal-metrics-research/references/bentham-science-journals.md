# Bentham Science Journals — Complete Reference

## Publisher Overview

**Bentham Science Publishers** (est. 1994, Sharjah, UAE):
- 120+ subscription-based journals ("Bentham Science")
- ~40 open access journals ("Bentham Open" — **avoid, predatory concerns**)
- 66 journals have JCR Impact Factors (as of 2023)
- Member of COPE (Committee on Publication Ethics)
- Indexed in Scopus, Chemical Abstracts, MEDLINE, EMBASE

## ⚠️ CRITICAL WARNING: Citation Manipulation Concerns (2023-2024)

**Several Bentham Science journals were flagged by Scopus in 2023-2024 for citation manipulation.** This is a significant concern:
- Some journals may have been temporarily suspended or had metrics suppressed
- Verify current Scopus/JCR status before submitting
- Check SCImago (scimagojr.com) for current Q rankings
- Consider journals from other publishers if citation integrity is a concern

## Bentham Hybrid Model (Critical to Understand)

**ALL Bentham subscription journals are HYBRID:**
- **Subscription route = FREE (no APC)** — authors publish at no cost
- **OA option = PAID** — APC typically $2,800–$3,500 USD (varies by journal)
- OpenAlex field: `is_oa: false` for subscription journals
- The `apc_usd` field in OpenAlex shows the OA option APC (not required)

**Bentham Open journals are DIFFERENT:**
- Fully OA, require APC
- Beall's list (defunct) flagged Bentham Open as "potential predatory"
- Has had peer review scandals (SCIgen fake paper accepted in 2009, 2013)
- **DO NOT target Bentham Open journals** — use Bentham Science (subscription) journals only

## Relevant Bentham Science Journals (for Natural Products + Cancer Review)

All are HYBRID (subscription free). Verified SCIE. Accept reviews.

### Tier 1: Best Match (IF ≥ 2.5, Q1-Q2, directly relevant)

| Journal | ISSN | IF (JCR 2023) | ISI | Scopus Q | Reviews? | Topic Relevance |
|---------|------|---------------|-----|----------|----------|----------------|
| **Current Drug Targets** | 1389-4501 | ~3.79 | SCIE | Q1 | ✅ themed issues | Drug targets in cancer, natural product targets |
| **Mini-Reviews in Medicinal Chemistry** | 1389-5575 | ~2.07 | SCIE | Q2 | ✅ ONLY reviews | Mini-reviews on all aspects of medicinal chemistry |
| **Current Medicinal Chemistry** | 0929-8673 | ~2.56 | SCIE | Q2 | ✅ | Medicinal chemistry, rational drug design |
| **Current Topics in Medicinal Chemistry** | 1568-0266 | ~2.68 | SCIE | Q2 | ✅ themed issues | Themed review collections |
| **Current Organic Chemistry** | 1385-2728 | ~2.85 | SCIE | Q2 | ✅ | Organic chemistry, natural product chemistry |

### Tier 2: Good Match (IF ≥ 2.0, Q2-Q3, relevant)

| Journal | ISSN | IF (JCR 2023) | ISI | Scopus Q | Reviews? | Topic Relevance |
|---------|------|---------------|-----|----------|----------|----------------|
| **Current Diabetes Reviews** | 1573-3998 | ~3.01 | SCIE | Q2 | ✅ | Diabetes, metabolic diseases |
| **Current Neuropharmacology** | 1570-159X | ~2.59 | SCIE | Q2 | ✅ | Neuropharmacology |
| **Current Vascular Pharmacology** | 1570-1611 | ~2.14 | SCIE | Q3 | ✅ | Vascular pharmacology |

### Tier 3: Lower Match (IF ~1.8-2.0, Q3)

| Journal | ISSN | IF (JCR 2023) | ISI | Scopus Q | Reviews? | Topic Relevance |
|---------|------|---------------|-----|----------|----------|----------------|
| **Current Pharmaceutical Design** | 1381-6128 | ~2.69 | SCIE | Q2 | ✅ themed issues | Pharmacology, drug design |
| **Current Cancer Drug Targets** | 1568-0096 | ~1.85 | SCIE | Q3 | ✅ | Molecular cancer drug targets |
| **Anti-Cancer Agents in Medicinal Chemistry** | 1568-0118 | ~1.95 | SCIE | Q3 | ✅ | Anti-cancer agent discovery |
| **Current Drug Metabolism** | 1389-2002 | ~1.95 | SCIE | Q3 | ✅ | Drug metabolism of bioactive compounds |
| **Current Gene Therapy** | 1566-5232 | ~3.85 | SCIE | Q2 | ✅ | Gene therapy (less relevant) |

### Tier 4: Not Recommended

| Journal | Reason |
|---------|--------|
| The Natural Products Journal | IF ~0.81, not SCIE (ESCI only), Q4 |
| Current Neuropharmacology | High IF but neuropharmacology focus, off-topic for cancer |

## Bentham Themed Issue Strategy

Many Bentham journals run **themed/collection issues** — a themed issue on "Natural Products Against Breast Cancer" would be ideal. To propose one:
1. Contact the Editor-in-Chief of the target journal
2. Propose a collection of 5-10 mini-reviews on subtopics
3. Each article is typically 3-10 pages (mini-review format)
4. This is the most common Bentham submission pathway for reviews

## ISSN Reference for OpenAlex Lookups

| Journal | ISSN (Print) | ISSN (Online) |
|---------|-------------|---------------|
| Current Drug Targets | 1389-4501 | 1873-5592 |
| Mini-Reviews in Medicinal Chemistry | 1389-5575 | 1875-5607 |
| Current Medicinal Chemistry | 0929-8673 | 1875-533X |
| Current Topics in Medicinal Chemistry | 1568-0266 | 1873-4294 |
| Current Cancer Drug Targets | 1568-0096 | 1873-5576 |
| Current Drug Metabolism | 1389-2002 | 1875-5453 |
| Anti-Cancer Agents in Medicinal Chemistry | 1568-0118 | 1871-5206 |
| Current Gene Therapy | 1566-5232 | 1875-5631 |
| Current Pharmaceutical Design | 1381-6128 | 1873-4286 |
| Current Organic Chemistry | 1385-2728 | 1875-5348 |
| The Natural Products Journal | 2210-3155 | 2210-3163 |
| Current Neuropharmacology | 1570-159X | 1875-6190 |
| Current Vascular Pharmacology | 1570-1611 | 1875-6212 |
| Current Diabetes Reviews | 1573-3998 | 1875-6417 |

## Wikipedia Page Names (for REST API lookups)

| Journal | Wikipedia Page Name |
|---------|-------------------|
| Current Drug Targets | Current_Drug_Targets |
| Mini-Reviews in Medicinal Chemistry | Mini-Reviews_in_Medicinal_Chemistry |
| Current Medicinal Chemistry | Current_Medicinal_Chemistry |
| Current Topics in Medicinal Chemistry | Current_Topics_in_Medicinal_Chemistry |
| Current Cancer Drug Targets | Current_Cancer_Drug_Targets |
| Current Drug Metabolism | Current_Drug_Metabolism |
| Anti-Cancer Agents in Medicinal Chemistry | Anti-Cancer_Agents_in_Medicinal_Chemistry |
| Current Gene Therapy | Current_Gene_Therapy |
| Current Pharmaceutical Design | Current_Pharmaceutical_Design |
| Current Organic Chemistry | Current_Organic_Chemistry |
| Current Neuropharmacology | Current_Neuropharmacology |
| Current Vascular Pharmacology | Current_Vascular_Pharmacology |
| Current Diabetes Reviews | Current_Diabetes_Reviews |

## OpenAlex ISSNs for Verification

Use `curl -s "https://api.openalex.org/sources/issn:{ISSN}"` to verify each journal.
Note: OpenAlex rate limits are aggressive (~25-50 requests/day). Budget accordingly.

## Alternative Publisher: Future Science Group (Hybrid)

**Future Science Group** (acquired by SAGE Publishing in 2022):
- Hybrid journals in pharmacology and oncology
- Free subscription route available
- Key journals:
  - **Future Medicinal Chemistry** (IF ~3.24, Q1) — BEST MATCH for NP + cancer review
  - **Future Oncology** (IF ~2.61, Q2) — Good for cancer treatment focus
  - **Future Science OA** (IF ~2.82, Q2) — ⚠️ Not SCIE (ESCI only), full OA not hybrid

## Alternative Publisher: Thieme (Drug Research)

**Thieme Medical Publishers**:
- **Drug Research** (formerly Arzneimittel-Forschung) — IF ~3.10, Q2
- Published by reputable Thieme publisher
- Good for pharmacology studies including natural product drug research
