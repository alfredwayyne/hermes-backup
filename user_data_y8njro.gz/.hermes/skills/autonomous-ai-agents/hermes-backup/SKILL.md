---
name: hermes-backup
description: "Backup and restore Hermes data to Git repos on a schedule."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [backup, disaster-recovery, github, cron, git]
    related_skills: [hermes-agent]
---

# Hermes Backup & Disaster Recovery

Automated backup of Hermes Agent's critical data to a Git repository, with restore guidance.

## What to Back Up

| Path | Contents | Priority |
|------|----------|----------|
| `~/.hermes/memories/` | User and agent memory files | Critical |
| `~/.hermes/skills/` | All installed skills (bundled + custom) | Critical |
| `~/.hermes/config.yaml` | Agent configuration | High |
| `~/.hermes/SOUL.md` | Agent personality/soul | High |
| `~/.hermes/cron/` | Cron job definitions, executions DB | High |
| `~/.hermes/channel_directory.json` | Platform channel routing | Medium |
| `~/.hermes/profiles/` | Multi-profile data (if any) | Medium |

## What to EXCLUDE

| Path | Reason |
|------|--------|
| `~/.hermes/.env` | Contains API keys, secrets — never back up plaintext credentials |
| `~/.hermes/auth.json` | OAuth tokens, credential pools |
| `~/.hermes/state.db` | Session database (large, regenerable) |
| `~/.hermes/logs/` | Transient log data |
| `~/.hermes/cache/`, `*_cache.json` | Regenerable caches |
| `~/.hermes/gateway.*` | Runtime state files |
| `~/.hermes/*.lock` | Lock files |

## Setup Procedure

### 1. Create the backup script

```bash
# Script lives at ~/.hermes/scripts/hermes-backup.sh
# The cronjob tool requires scripts in ~/.hermes/scripts/ with relative path reference
```

See `scripts/hermes-backup.sh` for the complete template, and `references/cronjob-setup.md` for cronjob configuration details.

### 2. Configure Git credentials

When SSH (port 22) is blocked, use HTTPS with a Personal Access Token (PAT):

```bash
git config --global user.name "Hermes Backup"
git config --global user.email "hermes@backup.local"
git clone https://<TOKEN>@github.com/<user>/<repo>.git /data/Hermesbackup
```

**Security note:** Tokens in git remote URLs persist in `.git/config`. For production use, prefer `git credential store` or a credential helper.

### 3. Set up the cron job

Use `no_agent=True` — this is a pure script execution, no LLM reasoning needed:

```
cronjob(action='create', 
        name='hermes-backup-12h',
        schedule='every 12h',
        script='hermes-backup.sh',  # relative to ~/.hermes/scripts/
        no_agent=True,
        deliver='origin')
```

The script's stdout is delivered as the notification message. Design it to stay silent when there's nothing to report.

## Pitfalls

1. **Script path must be relative** — The cronjob tool requires `script` to be a filename relative to `~/.hermes/scripts/`, not an absolute path. Absolute paths are rejected with: `"Script path must be relative to ~/.hermes/scripts/"`.

2. **`no_agent=True` requires `script`** — When `no_agent=True`, you MUST provide a `script` parameter. The `prompt` and `skills` parameters are ignored.

3. **Empty stdout = silent delivery** — If the backup script produces no stdout, the cron job sends nothing. The script should always output a status line (e.g., "Backup complete" or "No changes").

4. **Git push may fail on first run** — If the remote repo has different default branch (main vs master), the push command should try both: `git push origin main 2>&1 || git push origin master 2>&1`.

5. **`find -maxdepth` for clean slate** — When re-backing-up, clean previous files before copying: `find . -maxdepth 1 -not -name '.git' -not -name '.' -not -name '..' -exec rm -rf {} +`. This avoids stale files accumulating.

6. **Empty directories** — `cp -r dir/* dest/` fails silently if source is empty. Always redirect with `2>/dev/null || true`.

## Restore Procedure

To restore from a backup:

```bash
git clone https://<TOKEN>@github.com/<user>/<repo>.git ~/hermes-restore
# Copy back the needed directories:
cp -r ~/hermes-restore/memories/* ~/.hermes/memories/
cp -r ~/hermes-restore/skills/* ~/.hermes/skills/
cp ~/hermes-restore/config/config.yaml ~/.hermes/config.yaml
cp ~/hermes-restore/config/SOUL.md ~/.hermes/SOUL.md
# Restart Hermes gateway after restore
```

## Customization

- **Backup frequency**: Change `schedule` in the cronjob (e.g., `'0 9 * * *'` for daily at 9am)
- **Add directories**: Edit the backup script to include additional paths
- **Exclude sensitive skills**: Add exclusion logic to the skills copy step
- **Multi-repo**: Duplicate the script with different `BACKUP_DIR` for separate repos
