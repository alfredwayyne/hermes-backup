# Cronjob Configuration for Backups

## Key Parameters

| Parameter | Value | Notes |
|-----------|-------|-------|
| `action` | `create` | Creates a new recurring job |
| `name` | `hermes-backup-12h` | Human-readable identifier |
| `schedule` | `every 12h` | ISO duration or cron expression |
| `script` | `hermes-backup.sh` | **Relative** to `~/.hermes/scripts/` |
| `no_agent` | `true` | Pure script, no LLM — saves tokens |
| `deliver` | `origin` | Sends result back to originating chat |

## `no_agent=True` Semantics

- `script` parameter is **required** (prompt and skills are ignored)
- stdout is delivered verbatim as the notification message
- **Empty stdout = SILENT** — nothing is sent to the user
- Non-zero exit / timeout sends an error alert
- The agent loop is completely skipped — no tokens consumed

## Schedule Formats

| Format | Example | Meaning |
|--------|---------|---------|
| Duration | `every 12h` | Every 12 hours from creation time |
| Duration | `30m` | Every 30 minutes |
| Cron expr | `0 9 * * *` | Daily at 9:00 AM |
| ISO timestamp | `2026-06-01T09:00:00` | One-shot at specific time |

## Verification Commands

```bash
# List all cron jobs
cronjob(action='list')

# Manually trigger a test run
cronjob(action='run', job_id='<job_id>')

# Pause/resume
cronjob(action='pause', job_id='<job_id>')
cronjob(action='resume', job_id='<job_id>')
```
