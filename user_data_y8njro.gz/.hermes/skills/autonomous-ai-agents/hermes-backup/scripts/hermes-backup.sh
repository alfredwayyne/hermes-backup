#!/bin/bash
# Hermes Agent Backup Script
# Backs up memory, skills, config, and critical files to GitHub
# Place at: ~/.hermes/scripts/hermes-backup.sh

set -euo pipefail

HERMES_HOME="${HERMES_HOME:-$HOME/.hermes}"
BACKUP_DIR="/data/Hermesbackup"
DATE=$(date '+%Y-%m-%d_%H-%M-%S')
LOG_FILE="/data/hermes-backup.log"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"; }

log "=== Starting Hermes backup ==="

# Ensure backup dir exists and is a git repo
if [ ! -d "$BACKUP_DIR/.git" ]; then
    log "ERROR: Backup directory $BACKUP_DIR is not a git repo"
    exit 1
fi

cd "$BACKUP_DIR"

# Clean previous backup files (except .git) to avoid stale files
find . -maxdepth 1 -not -name '.git' -not -name '.' -not -name '..' -exec rm -rf {} +

# --- Backup: Memory files ---
log "Backing up memories..."
mkdir -p memories
if [ -d "$HERMES_HOME/memories" ]; then
    cp -r "$HERMES_HOME/memories/"* memories/ 2>/dev/null || true
fi
if [ -f "$HERMES_HOME/memories/user.md" ]; then
    cp "$HERMES_HOME/memories/user.md" memories/ 2>/dev/null || true
fi

# --- Backup: Skills ---
log "Backing up skills..."
mkdir -p skills
if [ -d "$HERMES_HOME/skills" ]; then
    cp -r "$HERMES_HOME/skills/"* skills/ 2>/dev/null || true
fi

# --- Backup: Config ---
log "Backing up config..."
mkdir -p config
cp "$HERMES_HOME/config.yaml" config/ 2>/dev/null || log "WARN: No config.yaml found"
cp "$HERMES_HOME/SOUL.md" config/ 2>/dev/null || log "WARN: No SOUL.md found"

# --- Backup: Cron jobs ---
log "Backing up cron jobs..."
mkdir -p cron
if [ -d "$HERMES_HOME/cron" ]; then
    for f in "$HERMES_HOME/cron"/*.json "$HERMES_HOME/cron"/*.yaml "$HERMES_HOME/cron"/*.yml; do
        [ -f "$f" ] && cp "$f" cron/ 2>/dev/null || true
    done
    cp "$HERMES_HOME/cron/executions.db" cron/ 2>/dev/null || true
fi

# --- Backup: Platform configs ---
log "Backing up platform configs..."
mkdir -p platforms
cp "$HERMES_HOME/channel_directory.json" platforms/ 2>/dev/null || true

# --- Backup: Profiles (if any) ---
if [ -d "$HERMES_HOME/profiles" ] && [ "$(ls -A "$HERMES_HOME/profiles" 2>/dev/null)" ]; then
    log "Backing up profiles..."
    cp -r "$HERMES_HOME/profiles" profiles/ 2>/dev/null || true
fi

# --- Create metadata ---
cat > backup-meta.json <<EOF
{
  "backup_date": "$DATE",
  "hermes_home": "$HERMES_HOME",
  "hostname": "$(hostname)",
  "contents": ["memories/", "skills/", "config/", "cron/", "platforms/"]
}
EOF

# --- Git commit and push ---
log "Committing and pushing..."
git add -A
if git diff --cached --quiet; then
    log "No changes to backup. Skipping commit."
    log "=== Backup complete (no changes) ==="
    exit 0
fi

git commit -m "🤖 Hermes backup: $DATE" --quiet
git push origin main --quiet 2>&1 || git push origin master --quiet 2>&1

log "=== Backup complete ==="
